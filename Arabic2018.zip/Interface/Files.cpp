







//˵��: Files.cpp --- File Operations.
//��������: [1]���̱�����resurce, ���ж���IDS_FILTER�ȵ��ַ�����Դ
//          [2]���̱�����cpp�ļ����/����hThisInstance,hThisWnd, ���ж���IDS_FILTER�ȵ��ַ�����Դ 
//             ���㲻��ҲҪ����.  

#define _FILES_CPP_  

// ..\..\�����ļ� 


#include <Windows.h>
//#include "RcNotePadW.h"
//#include "resource.h"
#include "Files.h"

 

#define eInfo(a) MessageBox(NULL,(a),"error",0)


#include <shlobj.h> 
#include <malloc.h>  //����








#pragma warning(disable:4996)
#define  _CONST_CORRECT_OVERLOADS  
#define  _CONST_RETURN   // non-const behavior for both C++ overloads

#define WORD wchar_t 





WORD szFiles[MAX_PATH]; //����buffer.

////  <0. ��������..  ////

//bread: _O_RDS=_O_RDONLY|...; //_O_RDWR,_O_RDONLY, _O_WRONLY,...;
int GetFileID(LPCTSTR szName, int _O_RDS)//=-1;
{//׼���ļ���BOOL bOk;  
if(szName==NULL) {MessageBox(NULL,"NULL Name!","",0); return 0;}

if(_O_RDS==-1) _O_RDS=_O_RDWR;
int hFile=open(szName,_O_BINARY|_O_CREAT|_O_RDS,_S_IREAD | _S_IWRITE);//fileno(fwrz); // SD
if(hFile==-1) MessageBox(NULL,strerror(errno),szName,MB_OK); 
//delete[] szFile;//delete szDict;
return hFile;
}

int GetFileID(LPCWSTR szName, int _O_RDS)//=-1;
{//׼���ļ���BOOL bOk;  
if(szName==NULL) {MessageBox(NULL,"NULL Name!","",0); return 0;}
if(_O_RDS==-1) _O_RDS=_O_RDWR;

int hFile=_wopen(szName,_O_BINARY|_O_CREAT|_O_RDS,_S_IREAD | _S_IWRITE);//fileno(fwrz); // SD
if(hFile==-1) MessageBox(NULL,strerror(errno),"GetFileID",MB_OK); 

return hFile;
}

HANDLE GetFileHandle(LPCTSTR szName)
{
DWORD dwAccess=GENERIC_READ|GENERIC_WRITE; 
DWORD dwShare=FILE_SHARE_READ|FILE_SHARE_WRITE ;  //0;//
LPSECURITY_ATTRIBUTES pAtt=NULL;
DWORD dwCreate=OPEN_ALWAYS;
DWORD dwFlags=FILE_ATTRIBUTE_NORMAL;
HANDLE hTemplate=NULL;
return CreateFile(szName, dwAccess,dwShare,pAtt,dwCreate,dwFlags,hTemplate);   //Winbase.h
}

HANDLE GetFileHandle(LPCWSTR szName)
{
DWORD dwAccess=GENERIC_READ|GENERIC_WRITE; 
DWORD dwShare=FILE_SHARE_READ|FILE_SHARE_WRITE ;  //0;//
LPSECURITY_ATTRIBUTES pAtt=NULL;
DWORD dwCreate=OPEN_ALWAYS;
DWORD dwFlags=FILE_ATTRIBUTE_NORMAL;
HANDLE hTemplate=NULL;
//WINBASEAPI HANDLE WINAPI CreateFileW(LPCWSTR lpFileName,DWORD dwDesiredAccess,DWORD dwShareMode,LPSECURITY_ATTRIBUTES lpSecurityAttributes,DWORD dwCreationDisposition,DWORD dwFlagsAndAttributes,HANDLE hTemplateFile);
return CreateFileW(szName, dwAccess,dwShare,pAtt,dwCreate,dwFlags,hTemplate);   //Winbase.h
}


//[2005-6-18 11:05:50]//
//Files.cpp
int GetFileExtension(LPCWSTR szFile)
{//Note: _strnicmp: Compare characters of two strings without regard to case.
int iT=FILE_EXTENSION_UNKNOWN; //FILE_EXTENSION_UNKNOWN;
const WORD*ph=wcsrchr(szFile,'.');
if(!ph) return iT;
//ph=ToLower(ph);//wsprintf(szType,ph+1);//szType=ToLower(szType); //Not Necessary!
WORD wExt[]={'.','t','x','t',0,0,0};
if(wcsnicmp(ph,wExt,4)==0) iT=FILE_EXTENSION_TXT;
wExt[0]='.'; wExt[1]='i';wExt[2]='c';wExt[3]='o';wExt[4]=0;
if(wcsnicmp(ph,wExt,4)==0) iT=FILE_EXTENSION_ICO;
wExt[0]='.'; wExt[1]='b';wExt[2]='m';wExt[3]='p';wExt[4]=0;
if(wcsnicmp(ph,wExt,4)==0) iT=FILE_EXTENSION_BMP;
wExt[0]='.'; wExt[1]='r';wExt[2]='t';wExt[3]='f';wExt[4]=0;
if(wcsnicmp(ph,wExt,4)==0) iT=FILE_EXTENSION_RTF;
wExt[0]='.'; wExt[1]='d';wExt[2]='o';wExt[3]='c';wExt[4]=0;
if(wcsnicmp(ph,wExt,4)==0) iT=FILE_EXTENSION_DOC;
wExt[0]='.'; wExt[1]='e';wExt[2]='x';wExt[3]='e';wExt[4]=0;
if(wcsnicmp(ph,wExt,4)==0) iT=FILE_EXTENSION_EXE;
wExt[0]='.'; wExt[1]='d';wExt[2]='l';wExt[3]='l';wExt[4]=0;
if(wcsnicmp(ph,wExt,4)==0) iT=FILE_EXTENSION_DLL;
wExt[0]='.'; wExt[1]='r';wExt[2]='a';wExt[3]='g';wExt[4]=0;
if(wcsnicmp(ph,wExt,4)==0) iT=FILE_EXTENSION_RAG;
wExt[0]='.'; wExt[1]='w';wExt[2]='r';wExt[3]='z';wExt[4]=0;
if(wcsnicmp(ph,wExt,4)==0) iT=FILE_EXTENSION_WRZ;

////(int)iT);
return iT;
}

int GetFileExtension(LPCTSTR szFile)
{//Note: _strnicmp: Compare characters of two strings without regard to case.
int iT=FILE_EXTENSION_UNKNOWN;
const char*ph=strrchr(szFile,'.');
if(!ph) return iT;

//ph=ToLower(ph);
if(strnicmp(ph,".txt",4)==0) iT=FILE_EXTENSION_TXT;
else if(strnicmp(ph,".ico",4)==0) iT=FILE_EXTENSION_ICO;
else if(strnicmp(ph,".bmp",4)==0) iT=FILE_EXTENSION_BMP;
else if(strnicmp(ph,".rtf",4)==0) iT=FILE_EXTENSION_RTF;
else if(strnicmp(ph,".doc",4)==0) iT=FILE_EXTENSION_DOC;
else if(strnicmp(ph,".exe",4)==0) iT=FILE_EXTENSION_EXE;
else if(strnicmp(ph,".dll",4)==0) iT=FILE_EXTENSION_DLL;
else if(strnicmp(ph,".rag",4)==0) iT=FILE_EXTENSION_RAG;
else if(strnicmp(ph,".wrz",4)==0) iT=FILE_EXTENSION_WRZ;

////iT);
return iT;
}







////  ..0. ��������>  ////






////  <1. ���ļ���������..  ////

//2007��10��11��//

//ib,��ʼ�ֽ�������, ie, �����ֽ�������;
//��ʵ�ض��� [ib,ie] ��������;
//��free()�ͷ��ڴ档

char* readfile(const WORD*szFile, int ib, int ie)
{ 
int io=_wopen(szFile,_O_BINARY|_O_RDONLY,_S_IREAD);
if(io==-1) {MessageBox(NULL,strerror(errno),0,MB_OK); return NULL;}


DWORD isize=filelength(io);  
if(ib<0) ib=0;
if(ie<0) ie=isize-1;
if(ib>ie) ib=ie;
int ic=ie-ib+1; 

char* pr=(char*) malloc(ic+20);pr[0]=0; //+20, for safety;

read(io,pr,ic);

pr[ic]=0; pr[ic+1]=0;

close(io);
return pr;
}






//readfile, ����_wopen��ȡchar����[ib,ie];
//ib,��ʼ�ֽ�������, ie, �����ֽ�������;
//���ض�ȡ���ֽ���;
//���szBuf=NULL,�򷵻������ڴ��С[bytes];

inline int readfile(int io,LPVOID szBuf,int ib,int ie) 
{
if(io==-1) {MessageBox(NULL,"�ļ������Ч!","readfile",0); return 0;}

DWORD isize=filelength(io);  
if(ib<0) ib=0;
if(ie<0) ie=isize-1;
if(ib>ie) ib=ie;

int ic=ie-ib+1;
if(szBuf==NULL) {return ic;}


////Read File;
if(ib>0) lseek(io,ib,SEEK_SET);

int ir=read(io,szBuf,ic); 
if(ir!=ic)MessageBox(NULL,strerror(errno),"read",0);


*( (char*)szBuf+ic  ) =0;
*( (char*)szBuf+ic+1) =0;



return ir;
}


int readfile(LPCTSTR szFile,LPVOID szBuf,int ib,int ie) 
{
if(szFile==NULL) return 0; 

int io=open(szFile,_O_BINARY|_O_RDONLY,_S_IREAD);
if(io==-1) {MessageBox(NULL,strerror(errno),"open",0); return 0;}

int ir=readfile(io,szBuf,ib,ie);


close(io);
return ir;
}


int readfile(LPCWSTR szFile,LPVOID szBuf,int ib,int ie) 
{
if(szFile==NULL) return 0; 

int io=_wopen(szFile,_O_BINARY|_O_RDONLY,_S_IREAD);
if(io==-1) {MessageBox(NULL,strerror(errno),"open",0); return 0;}

int ir=readfile(io,szBuf,ib,ie);

close(io);
return ir;
}



//Readfile, ����CreateFile��ȡic,=-1,�ֽڣ���ʼλ��istart=0;
//���ض�ȡ���ֽ���;

inline DWORD ReadFile(HANDLE hFile,LPVOID szBuf,DWORD ic,int istart) 
{
if(istart<0) istart=0;
if(hFile==INVALID_HANDLE_VALUE) {MessageBox(NULL,"�ļ������Ч!","ReadFile",0); return 0;}


////Read File;
if(ic<=0)ic=GetFileSize(hFile,NULL)-istart;
if(ic<=0) {MessageBox(NULL,"����istart�����ļ�����!","GetFileSize",0);return 0;}

if(szBuf==NULL) {return ic;}

if(istart!=0) SetFilePointer(hFile,istart,NULL,FILE_BEGIN);

DWORD dwRead; //number of bytes read
//LPOVERLAPPED lpOverlapped=NULL;    //overlapped buffer
BOOL bOk=ReadFile(hFile,szBuf,ic,&dwRead,NULL); 
if(dwRead!=ic)eInfo("ReadFile");

return dwRead;
}

//���szBuf=NULL,�򷵻������С;

DWORD ReadFile(LPCTSTR szFile,LPVOID szBuf,DWORD ic,int istart) 
{
if(szFile==NULL) return 0; if(istart<0) istart=0;
//FileOpen(szFile);
DWORD dwAccess=GENERIC_READ|GENERIC_WRITE; 
DWORD dwShare=0;//FILE_SHARE_READ|FILE_SHARE_WRITE ;  
LPSECURITY_ATTRIBUTES pAtt=NULL; HANDLE hTemplate=NULL;
DWORD dwCreate=OPEN_ALWAYS; 
DWORD dwFlags=FILE_ATTRIBUTE_NORMAL;

HANDLE hFile=CreateFile(szFile, dwAccess,dwShare,pAtt,dwCreate,dwFlags,hTemplate);  
if(hFile==INVALID_HANDLE_VALUE) {eInfo("CreateFile"); return 0;}

DWORD dwRead=ReadFile(hFile,szBuf,ic,istart) ;

CloseHandle(hFile);
return dwRead;
}

DWORD ReadFile(LPCWSTR szFile,LPVOID szBuf,DWORD ic,int istart) 
{
if(szFile==NULL) return 0; if(istart<0) istart=0;
//FileOpen(szFile);
DWORD dwAccess=GENERIC_READ|GENERIC_WRITE; 
DWORD dwShare=0;//FILE_SHARE_READ|FILE_SHARE_WRITE ;  
LPSECURITY_ATTRIBUTES pAtt=NULL; HANDLE hTemplate=NULL;
DWORD dwCreate=OPEN_ALWAYS; 
DWORD dwFlags=FILE_ATTRIBUTE_NORMAL;

HANDLE hFile=CreateFileW(szFile, dwAccess,dwShare,pAtt,dwCreate,dwFlags,hTemplate);  
if(hFile==INVALID_HANDLE_VALUE) {eInfo("CreateFile"); return 0;}

DWORD dwRead=ReadFile(hFile,szBuf,ic,istart) ;

CloseHandle(hFile);
return dwRead;
}







// readline: ��1��. ������'\n'��"\r\n"Ϊ���������־ 
// ����: ��char�Ĵ���, �ֽ���, �ļ�ָ���ƶ��Ĳ���;
// ע��: ����ȡ���ַ�, Ӧ����'\n', �����ʽ������,

int readline(int io,char*szp, int iB){   // iB=65536, �������� 
*szp=0; int ip=0; int ir=0;
char ch=0;   
while(!_eof(io)){  if(ip>iB) break; // �ܿ���ѭ��
  read(io,&ch,1); ir++;
  if(ch=='\n')break;  // ���������־ 

  if(ch=='\r') { // ���������"\r\n"Ϊ������־ 	  
    read(io,&ch,1); ir++;  if(ch!='\n') OutputDebugString("\\r without \\n ! ");
    break;
    }  
	  
  szp[ip]=ch; szp[++ip]=0;   //spliceҲ�ڼ�¼֮��;   
  }
return ir;
}












// readline[]: ��1��;
// ����: ��char�Ĵ���, �ֽ���, �ļ�ָ���ƶ��Ĳ���;
// ע��: ����ȡ���ַ�.//Ӧ����'\n', �����ʽ������,
// �����Ѿ��ﵽ����ip>MAX_PATH*100,
// �����Ѿ��ﵽ�ļ�β��;

int readline(int io,char*szp, const char splice){ //='\', =backslash, ��б�߷���;

*szp=0; int ip=0; int ir=0;
char ch=0,cho=0;  //cho,ǰһ���ַ�;
while(!_eof(io)){
  read(io,&ch,1); ir++;

  if(ch=='\r') {	  
    read(io,&ch,1); ir++;
    if(ch!='\n' && ch!='\r'){OutputDebugString("\\r without \\n, or vice versa !");break;}  
	  
    if(cho!=splice && splice!=0) break; //"\r\n"֮ǰ����'\',�˳�;
  }else{
    szp[ip]=ch; szp[++ip]=0;   //spliceҲ�ڼ�¼֮��;   
  }
    
  cho=ch;

  if(ip>102400) break; //�ܿ���ѭ��
  }
return ir;
}



// readline: ��1��... Unicode;
// ����: ��WORD�Ĵ���*2, �ֽ���, �ļ�ָ���ƶ��ľ�ȷ���� 
// �����ַ�������"\r\n";

int readline(int io,wchar_t*szp){ // *szp=0; int ip=0; int ir=0;
WORD c=0;  int ir=0, ip=0; 

while(!_eof(io)) {
  read(io,&c,2); ir+=2;    
  if(c=='\r' || c=='\n') {
    read(io,&c,2); ir+=2;
    if(c!='\n' && c!='\r') OutputDebugString("\\r without \\n, or vice versa !"); 
    break;  
  }else if(c!=0xFEFF){
    szp[ip]=c;szp[++ip]=0;      
  }

if(ip>4096) break; //�ܿ���ѭ��;
} // while  
return ir;
}


//readsect[]: ��1��... Ansi;
//����: ��char�Ĵ���, �ֽ���, �ļ�ָ���ƶ��Ĳ���;
//�����ַ���<4096,4K;
//�����ַ��������ڱ�־szHead,szTail,��'<',"/>";
int readsect(int io,char*szp)
{
if(szp==NULL) return 0;
if(io==-1) return 0; 

DWORD ir=0,ip=0;  

char c=0;   *szp=0;

while(!_eof(io)) {read(io,&c,1); ir++; if(c=='<') break;}//��λ��'<'��

if(c!='<') return ir;

szp[ip++]=c; szp[ip]=0;

while(!_eof(io)) //while(!_eof(io)),1;//��2��ɨ�裻
  {
  read(io,&c,1); ir++; 
  if(ip<4096) 
    {
    szp[ip++]=c;
    szp[ip]=0;
    }
  
  if(c=='>') break;
  }
return ir;
}


////  ..1. ���ļ���������>  ////


////  <2. д�ļ���������..  ////

//��д������
BOOL SaveFile(LPCTSTR szFile,const char* szSave,BOOL bAppend)
{
BOOL br=FALSE;
HANDLE hFile=GetFileHandle(szFile);
if(hFile==INVALID_HANDLE_VALUE){eInfo("SaveFile-FileOpen");return FALSE;}

if(bAppend)
  {
  DWORD dwf=GetFileSize(hFile,NULL);
  SetFilePointer(hFile,dwf,NULL,FILE_BEGIN);  
  }
int iL=strlen(szSave); DWORD dwWritten;
WriteFile(hFile,szSave,iL,&dwWritten,NULL); 
if(dwWritten!=iL){eInfo("SaveFile-WriteFile");CloseHandle(hFile);return FALSE;}
else br=TRUE;

SetEndOfFile(hFile);

CloseHandle(hFile);
return br;
}


BOOL SaveFile(LPCWSTR szFile,LPCWSTR szSave,BOOL bAppend)
{ 
BOOL br=FALSE;
HANDLE hFile=GetFileHandle(szFile);
if(hFile==INVALID_HANDLE_VALUE){eInfo("SaveFile-FileOpen");return FALSE;}


WORD ws=UNICODEFLAG;DWORD dwWritten;////  [2005��8��25�� 15ʱ16��] ////
WriteFile(hFile,&ws,2,&dwWritten,NULL); 
if(dwWritten!=2){eInfo("SaveFile-WriteFile");CloseHandle(hFile);return FALSE;}


if(bAppend)
  {
  DWORD dwf=GetFileSize(hFile,NULL);
  SetFilePointer(hFile,dwf,NULL,FILE_BEGIN);  
  }
int iL=wcslen(szSave)*2; 
WriteFile(hFile,szSave,iL,&dwWritten,NULL); 
if(dwWritten!=iL){eInfo("SaveFile-WriteFile");CloseHandle(hFile);return FALSE;}
else br=TRUE;

SetEndOfFile(hFile);//if(!bAppend)

CloseHandle(hFile);
return br;
}


//ic,д���ֽ���;
//����ic<=0,���szSave��ΪLPCWSTR�������ַ�����;

BOOL SaveFile(LPCWSTR szFile,LPVOID szSave,int ic,BOOL bAppend)
{ 
if(szSave==NULL) return 0;

BOOL br=FALSE;
HANDLE hFile=GetFileHandle(szFile);
if(hFile==INVALID_HANDLE_VALUE){eInfo("SaveFile-FileOpen");return FALSE;}


WORD ws=UNICODEFLAG;DWORD dwWritten; 
WriteFile(hFile,&ws,2,&dwWritten,NULL); 
if(dwWritten!=2){eInfo("SaveFile-WriteFile");CloseHandle(hFile);return FALSE;}


if(bAppend)
  {
  DWORD dwf=GetFileSize(hFile,NULL);
  SetFilePointer(hFile,dwf,NULL,FILE_BEGIN);  
  }

int iL=ic;
if(iL<=0) iL=wcslen((LPCWSTR)szSave)*2; 
WriteFile(hFile,szSave,iL,&dwWritten,NULL); 
if(dwWritten!=iL){eInfo("SaveFile-WriteFile");CloseHandle(hFile);return FALSE;}
else br=TRUE;

SetEndOfFile(hFile); //if(!bAppend)

CloseHandle(hFile);
return br;
}


//ic,д���ֽ���;
//����ic<=0,���szSave��ΪLPCTSTR�������ַ�����;

//TCHAR* szSave! ����ȫ�����뱣֤szSave��'\0'������
BOOL SaveFile(LPCTSTR szFile,LPVOID szSave,int ic,BOOL bAppend)
{
if(szSave==NULL) return 0;

BOOL br=FALSE;
HANDLE hFile=GetFileHandle(szFile);
if(!hFile){eInfo("SaveFile-FileOpen");return FALSE;}

if(bAppend)
  {
  DWORD dwf=GetFileSize(hFile,NULL);
  SetFilePointer(hFile,dwf,NULL,FILE_BEGIN);  
  }

int iL=ic;
if(ic<=0)iL=strlen((LPCTSTR)szSave); 
DWORD dwWritten;
WriteFile(hFile,szSave,iL,&dwWritten,NULL); 

SetEndOfFile(hFile);

if(dwWritten!=iL){eInfo("SaveFile-WriteFile");CloseHandle(hFile);return FALSE;}
else br=TRUE;
CloseHandle(hFile);
return br;
}




//SaveNew, ������byte����, ��������;
//io:      ���������ݵ��ļ�;
//iom:     �ο��Ƚ��ļ�,������io����. ȱʡ=-1,��ʱ��׷������, ע��, ����ˢ������;
//szSave:  ����������,LPVOID, buffer, ʵ������LPBYTE;
//ic:      �����������ֽ���;
//ie:      szSave�Ƚ�Ƭ����ֹλ��,��=-1,����ֹ��szSaveĩβ,0-based;
//ib:      szSave�Ƚ�Ƭ�Ͽ�ʼλ��,ȱʡ=0,0-based;
//return:  д�������ֽ���;

//inline 
int SaveNew(int io,int iom,LPVOID szSave,int ic, int ib,int ie)//=-1,0,-1;
{
if(szSave==NULL) return 0; if(ic<=0) return 0;
//int ic=wcslen(szSave); ic*=2;
if(iom==-1) //simple append;
  {
  lseek(io,0,SEEK_END);
  return write(io,(BYTE*)szSave,ic);  
  }

//ic=wcslen(szSave);
if(ib<0||ib>ic-1) ib=0;
if(ie<0||ie>ic-1) ie=ic-1;
if(ie<ib) ie=ib;
ie=ie-ib+1; //��ʱie��ʾƥ�䳤��;

const char*p=(const char*)szSave+ib;  int ip=0;
char w=0; 
bool bexist=false; 
lseek(iom,0,SEEK_SET); 

//SaveNew�ؼ�����; //����,���szSave��������iom,�򱣴�szSave��io;
while(!_eof(iom))
  {
  read(iom,&w,1);
  while(w==*p)
    {
	read(iom,&w,1);
	p++;
	ip++;
	if(ip>=ie) {bexist=true; break;}//��ȫƥ��;
	}      
  if(!bexist) {ip=0;p=(const char*)szSave+ib;}
  else break;
  }


if(bexist) return 0;

//ǿ�и���ioΪUnicode�ı�;
//WORD w=0xFEFF; lseek(io,0,SEEK_SET); write(io,&w,2);

//append;
lseek(io,0,SEEK_END); //iom may=io;
return write(io,(const char*)szSave,ic*2);  
}



////SaveNewӦ�ú���,�������;
//ע��: Ҫ���浽�µ�Unicode�ı�,�����ڵ���SaveNew֮ǰд��Unicode��־0xFEFF��;
int SaveNew(LPCWSTR szFile,const WORD*szCmpFile,LPVOID szSave,int ic,int ib,int ie)//=0,-1;
{
int io=_wopen(szFile,_O_BINARY|_O_RDONLY,_S_IREAD);
if(io==-1) {MessageBox(NULL,strerror(errno),"_wopen",0); return 0;}

int ir=0;
if(szCmpFile==NULL) //simple append;
  {
  ir=SaveNew(io,-1,szSave,ic,ib,ie);
  close(io);
  return ir;
  }

int iom=_wopen(szCmpFile,_O_BINARY|_O_RDONLY,_S_IREAD);
if(iom==-1)
  {
  MessageBox(NULL,strerror(errno),"_wopen",0);
  ir=SaveNew(io,-1,szSave,ic,ib,ie);
  close(io);
  return ir;  
  }

ir=SaveNew(io,iom,szSave,ic,ie,ib);
close(io); close(iom);
return ir;
}

//SaveNew�������;
//�Լ��䵱�Ƚ��ļ�;

//io: ������ _O_BINARY|_O_CREAT|_O_RDWR,_S_IREAD|_S_IWRITE��ʽ��;

int SaveNew(int io,LPVOID szSave, int ic) 
{
//int io=_wopen(szFile,_O_BINARY|_O_CREAT|_O_RDWR,_S_IREAD|_S_IWRITE);
//int io=_wopen(szTextFile,_O_BINARY|_O_RDONLY,_S_IREAD);//fileno(fwrz); // SD
if(io==-1)  return 0; 

int ir=SaveNew(io,io,szSave,ic,-1,0); //0,ic-1;
//close(io);
return ir;
}

int SaveNew(LPCWSTR szFile,LPVOID szSave, int ic) 
{
int io=_wopen(szFile,_O_BINARY|_O_CREAT|_O_RDWR,_S_IREAD|_S_IWRITE);
//int io=_wopen(szTextFile,_O_BINARY|_O_RDONLY,_S_IREAD);//fileno(fwrz); // SD
if(io==-1) {MessageBox(NULL,strerror(errno),"_wopen",0); return 0;}

int ir=SaveNew(io,io,szSave,ic,-1,0); //0,ic-1;
close(io);
return ir;
}






//SaveNewӦ�ú���,�������, Ansi�汾;

int SaveNew(LPCTSTR szFile,LPCTSTR szCmpFile,LPVOID szSave,int ic,int ib,int ie)//=0,-1;
{
int io=open(szFile,_O_BINARY|_O_RDONLY,_S_IREAD);
if(io==-1) {MessageBox(NULL,strerror(errno),szFile,0); return 0;}

int ir=0;
if(szCmpFile==NULL) //simple append;
  {
  ir=SaveNew(io,-1,szSave,ic,ib,ie);
  close(io);
  return ir;
  }

int iom=open(szCmpFile,_O_BINARY|_O_RDONLY,_S_IREAD);
if(iom==-1)
  {
  MessageBox(NULL,strerror(errno),szCmpFile,0);
  ir=SaveNew(io,-1,szSave,ic,ib,ie);
  close(io);
  return ir;  
  }

ir=SaveNew(io,iom,szSave,ic,ie,ib);
close(io); close(iom);
return ir;
}






////  ..2. д�ļ���������>  ////



////  <3. ����ļ�/��..  ////

//BrowseCallbackProc. For GetFolder: 
int CALLBACK BrowseProcW(HWND hdlg,UINT uMsg,LPARAM lParam,LPARAM lpData)
{
LPCITEMIDLIST pid; char szTmp[MAX_PATH];
switch(uMsg)
  {
  case WM_LBUTTONDBLCLK:  //No effect!	
    ////"WM_LBUTTONDBLCLK");
  break;  

  case BFFM_INITIALIZED: //SendMessage(hdlg,BFFM_ENABLEOK/BFFM_SETSELECTION/ BFFM_SETSTATUSTEXT ,...,...); 
    {
	//lpData��Ȼ����: 
    if(lpData) ::SendMessageW(hdlg, BFFM_SETSELECTIONW,TRUE,(LPARAM)lpData);  //szDef//(LPARAM)"C:\\WorkStation\\Work\\");//(LPARAM)"c:\\Permanent\\" 
    else{
	::GetCurrentDirectoryW(MAX_PATH,szFiles);
	::SendMessageW(hdlg, BFFM_SETSELECTIONW,TRUE,(LPARAM)szFiles); 
	}      

	//WM_SHOWWINDOW
	HWND hitem=GetDlgItem(hdlg,0x3742); // static ��ʾ��Ϣ. 
    ShowWindow(hitem,SW_HIDE);
    hitem=GetDlgItem(hdlg,0x3742);

	RECT re; GetWindowRect(hdlg,&re);
    int iw=re.right-re.left, ih=re.bottom-re.top;

    hitem=GetDlgItem(hdlg,0x3744); // Edit ѡ���ļ�/Ŀ¼ . 
    MoveWindow(hitem,20,10, iw-40,20,true);
    
	hitem=GetDlgItem(hdlg,0x3741); // SysTreeView32, Ŀ¼�� . 
    MoveWindow(hitem,20,40, iw-40,ih-120,true);


    //HWND hDesktop=GetDesktopWindow();
    //RECT re;GetClientRect(hDesktop,&re);RECT rc;GetClientRect(hwnd,&rc);
	POINT pt; GetCursorPos(&pt);   //HWND hp=GetParent(hdlg); 
	RECT rc; GetWindowRect(GetDesktopWindow(),&rc);
	int ix=pt.x-(re.right-re.left)*2/3, iy=pt.y-20;
	if(ix<0) ix=0; 	if(ix>rc.right-iw) ix=rc.right-iw;
    if(iy<0) iy=0; 	if(iy>rc.bottom-ih-40) iy=rc.bottom-ih-40;
    MoveWindow(hdlg,ix,iy, iw,ih,true); //��������λ��   
	//::SendMessage(hdlg, BFFM_SETSTATUSTEXT,0,(LPARAM)"��ѡ���Ŀ¼Ϊ��");    
    }
  break;

  case BFFM_SELCHANGED: break;    
    pid=(LPCITEMIDLIST)(lParam);SHGetPathFromIDList(pid,szTmp); //wsprintf(szInfo,szTmp);
    ::SendMessage(hdlg, BFFM_SETSTATUSTEXT,0,(LPARAM)szTmp);
    if(strstr(szTmp,".WAV")) 
    if(MessageBox(hdlg,"��ѡ����wav�ļ����Ƿ񲥷ţ�",NULL,MB_YESNO)==IDYES)PlayFile(szTmp);
  break;  
  case BFFM_VALIDATEFAILED:
  break;  
  }
return 0;
}  


//GetFolder: Unicode Version;
//wDefault: start point of the browse,the tree node of which is expanded;

BOOL GetFolder(WORD* wBuf,LPCWSTR wDefault,BOOL bFoldersOnly)
{
BOOL bOk=TRUE; wBuf[0]=0; 
//WORD* pwDisplayName=new WORD[MAX_PATH]; 

ITEMIDLIST iDL; LPITEMIDLIST piDL=&iDL;
BROWSEINFOW wbi; wbi.ulFlags=0;//BIF_NEWDIALOGSTYLE;
    wbi.hwndOwner=NULL; wbi.pidlRoot=NULL;
    wbi.pszDisplayName=new WORD[MAX_PATH]; *wbi.pszDisplayName=0; 
    wbi.lpszTitle=L"ѡ��/�����ļ�(��)";//NULL;//      
    
	wbi.ulFlags=BIF_EDITBOX; 
    if(bFoldersOnly)
      {
      wbi.lpszTitle=L"ѡ��/�����ļ���";//NULL;//      
      wbi.ulFlags|=BIF_STATUSTEXT; //BIF_STATUSTEXT;//BIF_EDITBOX|      
      }
    else wbi.ulFlags|=BIF_BROWSEINCLUDEFILES;//|BIF_EDITBOX|BIF_STATUSTEXT;

    wbi.lParam=(LPARAM)wDefault;
    wbi.lpfn=BrowseProcW; //�����NULL,����ָ��;//NULL;//
    
piDL=SHBrowseForFolderW(&wbi); //SHLOBJ.H(2304):WINSHELLAPI LPITEMIDLIST WINAPI SHBrowseForFolderW(LPBROWSEINFOW lpbi);
if(piDL)SHGetPathFromIDListW(piDL,wBuf);//SHLOBJ.H(2171):WINSHELLAPI BOOL WINAPI SHGetPathFromIDListW(LPCITEMIDLIST pidl, LPWSTR pszPath);
else bOk=FALSE;  
delete[] wbi.pszDisplayName; //pwDisplayName;
return bOk;
}










//GetFolder[]: Ansi Version:.
BOOL GetFolder(LPTSTR szBuf,LPCTSTR szDefault,BOOL bFolderOnly)//=FALSE
{
BOOL bOk=TRUE; szBuf[0]=0; ITEMIDLIST iDL;  LPITEMIDLIST piDL=&iDL;
char* szPathTitle=new char[MAX_PATH];

BROWSEINFO bi={0};
    bi.hwndOwner=NULL;
    bi.pidlRoot = NULL;//pidlRoot;
    bi.lpszTitle = "ѡ��/�����ļ���/�ļ�";
    
    if(bFolderOnly)
      {
      bi.ulFlags = BIF_EDITBOX;//BIF_STATUSTEXT|
      bi.lpszTitle = "ѡ��/�����ļ���";      
      }
    else
      bi.ulFlags = BIF_STATUSTEXT | BIF_BROWSEINCLUDEFILES ;
    
    //bi.ulFlags = BIF_STATUSTEXT | BIF_BROWSEINCLUDEFILES;// |BIF_NEWDIALOGSTYLE ;  //BIF_EDITBOX
    
    bi.lpfn=BrowseProc;
    bi. lParam=(LPARAM)szDefault;
    bi.pszDisplayName=szPathTitle;  //Title

piDL=SHBrowseForFolder(&bi); 
if(piDL)SHGetPathFromIDList(piDL,szBuf);  //MessageBox(NULL,szBuf,"",0);
else bOk=FALSE;
//MessageBox(NULL,szPath,"0GetFolder",0); //szPath=Title
delete[] szPathTitle;
return bOk;
}


///////////////////////////////////////////////////////////////////////////////
//  ��������������ļ�  ////////////////////  [2005��8��20�� 15ʱ26��] ////////////////////
///////////////////////////////////////////////////////////////////////////////

//OFNHookProcW,  a basic hook proc for GetOpenFileName.
//������WM_INITDIALOG��Ϣ.

UINT_PTR CALLBACK OFNHookProcW(HWND hdlg,UINT uiMsg,WPARAM wParam,LPARAM lParam) 
{
int wmId,wmEvent;
switch(uiMsg)
  {
  case WM_INITDIALOG:
    {
	POINT pt; GetCursorPos(&pt);
    HWND hp=GetParent(hdlg); RECT re; GetWindowRect(hp,&re);
    MoveWindow(hp,pt.x-(re.right-re.left)*2/3,pt.y-20,
	  re.right-re.left,re.bottom-re.top,TRUE); //��������λ��   
    }  
  break;
  case WM_DESTROY:  break;

  case WM_CTLCOLORBTN:   //Only for owner-drawn buttons;
  case WM_CTLCOLORSTATIC: //Read-only EditControl/ Static Control: 
  case WM_CTLCOLORDLG: //(HWND)lParam==hdlg
  break;
  case WM_CTLCOLOREDIT: break;  
  //case WM_LBUTTONDOWN:break;//Ok!  //case WM_KEYDOWN: break;//No!
  
  case WM_SIZE: break;// case DM_REPOSITION://=0xF
                  
  case WM_NOTIFY: // Only For Explore Style!
    {
    LPOFNOTIFYW pno=(LPOFNOTIFYW)lParam;   
    LPNMHDR pnh=&pno->hdr; 
    LPOPENFILENAMEW op=pno->lpOFN;       
	//switch(pnh->idFrom){case 0: break; case 1: break;}////"��");//ԭ���Ĵ򿪰�ť-0 //Ok!      	  	  
    switch(pnh->code)
      {
	  case CDN_SELCHANGE: 
		{ 
        HWND hp=GetParent(hdlg); //"Edit",��ʾ�ļ���/·��;
        SendMessageW(hp,CDM_GETFILEPATH,MAX_PATH,(LPARAM)szFiles);
		}     
	  break;
      case CDN_FILEOK: break; 
      default:break; //switch(pnh->code)
      }                        
    }
  break;

  case WM_COMMAND://=0x0111  //User Interface.  
	wmId=LOWORD(wParam); wmEvent=HIWORD(wParam);
    switch(wmId) //�˵���Ϣ: ����ļ��� Ŀ¼ ·��
      {
	  //case IDO_BROWSE:
 	  //break;
	  default:return FALSE; 
      }//switch(wmId)
  break;//case WM_COMMAND
  
  default:return FALSE; //switch(uiMsg)   
  }
return FALSE;
}


//����ֵ: OPENFILENAME::nMaxFile,���ڽ�ȡofn.lpstrFile=szFileName����ѡ��ʱ��·�����ļ�
bool GetFileName(LPWSTR szFileName,bool bSave,LPCWSTR szFilter,LPCWSTR szInitial)//=FALSE=NULL=NULL //UINT uFilterID,
{
WORD wFilter[MAX_PATH];
if(szFilter) wcscpy(wFilter,szFilter);
else wcscpy(wFilter,L"All Files (*.*)|*.*|Text Files(*.txt;*.doc;*.rtf)|*.txt;*.doc;*.rtf|Bitmap Files (*.bmp;*.ico;*.cur)|*.bmp;*.ico;*.cur|");

WORD*p=wFilter;
while(*p!=0) { if(*p=='|') *p=0; p++; } //�滻'|'Ϊ'\0';
  
OPENFILENAMEW ofn;
ZeroMemory(&ofn,sizeof(OPENFILENAMEW));
ofn.lStructSize=sizeof(OPENFILENAMEW);
ofn.hInstance=NULL; 
ofn.hwndOwner=NULL; 
*szFileName=0;
ofn.lpstrFile=szFileName;
ofn.nMaxFile=MAX_PATH*100; //��෵��Լ100���ļ���; //|OFN_ALLOWMULTISELECT
ofn.lpstrFilter=wFilter;
ofn.lpstrInitialDir=szInitial; //NULL Is Preferred!

ofn.Flags=OFN_EXPLORER|OFN_ENABLESIZING|OFN_SHOWHELP|OFN_ENABLEHOOK;//OFN_SHAREAWARE---������򿪳�ͻ

//ofn.lpTemplateName=MAKEINTRESOURCEW(IDD_DIALOG0);
ofn.lpfnHook=(LPOFNHOOKPROC) OFNHookProcW;

BOOL bok=FALSE;
if(bSave)
  {
  ofn.Flags|=OFN_OVERWRITEPROMPT;
  ofn.lpstrDefExt =NULL;
  ofn.lpstrTitle =L"�����ļ�";
  bok=GetSaveFileNameW(&ofn);
  }
else
  {
  //ofn.Flags|=OFN_ALLOWMULTISELECT; //
  ofn.Flags|= OFN_FILEMUSTEXIST|OFN_SHAREAWARE;
  ofn.lpstrTitle =L"���ļ�"; //szTitle;
  bok=GetOpenFileNameW(&ofn);
  }
return bok;
}


//����ֵ: OPENFILENAME::nMaxFile,���ڽ�ȡofn.lpstrFile=szFileName����ѡ��ʱ��·�����ļ�
bool GetFileName(LPTSTR szFileName,bool bSave,LPCTSTR szFileFilter,LPCTSTR szInitial)//=FALSE=NULL //UINT uFilterID,
{//Text Files(*.txt;*.doc);*.rtf|*.txt;*.doc;*.rtf|Icon Files (*.ICO)|*.ICO|All Files (*.*)|*.*|
TCHAR*szFilter=new char[MAX_PATH*2]; //NULL;//UINT uFilterID,
if(szFileFilter)sprintf(szFilter,szFileFilter);
else sprintf(szFilter,"All Files (*.*)|*.*|Text Files(*.txt;*.doc;*.rtf)|*.txt;*.doc;*.rtf|Icon Files (*.ICO)|*.ICO|Bitmap Files (*.bmp)|*.bmp|Exe Files (*.exe;*.dll)|*.exe;*.dll|");

//Convert String IDS_FILTER To Array szFilter: '|'--->'\0'=0;
UINT i=0, ic=strlen(szFilter); TCHAR ch='|'; 
for(i=0;i<ic; i++) 
  if(szFilter[i]==ch) szFilter[i]='\0';   

OPENFILENAME ofn;
ZeroMemory(&ofn,sizeof(OPENFILENAME));
ofn.lStructSize=sizeof(OPENFILENAME);
ofn.hInstance =NULL;//hThisInst;  
ofn.hwndOwner =NULL;// hThisWnd;

*szFileName=0; ofn.lpstrFile=szFileName;
ofn.nMaxFile=MAX_PATH*1000;
ofn.lpstrFilter=szFilter;
ofn.lpstrInitialDir=szInitial;
ofn.Flags=OFN_EXPLORER|OFN_ENABLESIZING|OFN_SHOWHELP;//OFN_SHAREAWARE---������򿪳�ͻ
BOOL br=FALSE;
if(bSave)
  {
  ofn.Flags|=OFN_OVERWRITEPROMPT;
  ofn.lpstrDefExt =NULL;
  ofn.lpstrTitle ="�����ļ�";
  br=GetSaveFileName(&ofn);
  }
else
  {
  ofn.Flags|= OFN_FILEMUSTEXIST|OFN_ALLOWMULTISELECT|OFN_SHAREAWARE;
  ofn.lpstrTitle ="���ļ�";//szTitle;
  br=GetOpenFileName(&ofn);
  }
//if(!br) eInfo("GetFileName");
delete[] szFilter;
return br;
}























//����ֵ: OPENFILENAME::nMaxFile,���ڽ�ȡofn.lpstrFile=szFileName����ѡ��ʱ��·�����ļ�
bool GetFileName(LPTSTR szFileName,bool bSave,LPCTSTR szInitial,HWND hOwner)//=NULL //UINT uFilterID,
{//Text Files(*.txt;*.doc);*.rtf|*.txt;*.doc;*.rtf|Icon Files (*.ICO)|*.ICO|All Files (*.*)|*.*|
TCHAR*szFilter=new char[MAX_PATH*2]; //NULL;//UINT uFilterID,
sprintf(szFilter,IDS_FILTER);
//Convert String IDS_FILTER To Array szFilter: \|'--->'\0'=0.
UINT i=0, ic=strlen(szFilter); TCHAR ch='|'; 
for(i=0;i<ic; i++) 
  if(szFilter[i]==ch) szFilter[i]='\0';   

OPENFILENAME ofn;
ZeroMemory(&ofn,sizeof(OPENFILENAME));
ofn.lStructSize=sizeof(OPENFILENAME);
ofn.hInstance = NULL;//hThisInst;  
ofn.hwndOwner =hOwner;// hThisWnd;

*szFileName=0; ofn.lpstrFile=szFileName;
ofn.nMaxFile=MAX_PATH*1000;
ofn.lpstrFilter=szFilter;
ofn.lpstrInitialDir=szInitial;
ofn.Flags=OFN_EXPLORER|OFN_ENABLESIZING|OFN_SHOWHELP;//OFN_SHAREAWARE---������򿪳�ͻ
BOOL br=FALSE;
if(bSave)
  {
  ofn.Flags|=OFN_OVERWRITEPROMPT;
  ofn.lpstrDefExt =NULL;
  ofn.lpstrTitle ="Save File";
  br=GetSaveFileName(&ofn);
  }
else
  {
  ofn.Flags|= OFN_FILEMUSTEXIST|OFN_ALLOWMULTISELECT|OFN_SHAREAWARE;
  ofn.lpstrTitle ="Open File";//szTitle;
  br=GetOpenFileName(&ofn);
  }
//if(!br) eInfo("GetFileName[]");
delete[] szFilter;
return br;//ofn.nMaxFile;
}

////  ..3. ����ļ�/��>  ////





///////////////////////////////////////////////////////////////////////////////
//��������: ��д��������: д�ļ�,�����ļ�////  [2005��9��7�� 16ʱ28��] ////////
///////////////////////////////////////////////////////////////////////////////




BOOL transferfile(WORD* wFile,WORD* szSave,BOOL bAppend)//int=FALSE
{
//��Щ������Է���FileOpen(.)�� 
DWORD dwAttrib=GetFileAttributesW(wFile);
if(dwAttrib==-1){eInfo("transferfile:GetFileAttributes");return FALSE;}
if(!(dwAttrib&FILE_ATTRIBUTE_ARCHIVE)){return FALSE;} 

int hSave=_wopen(szSave,_O_BINARY|_O_CREAT|_O_RDWR,_S_IREAD | _S_IWRITE);//fileno(fwrz); // SD
if(hSave==-1) {MessageBox(NULL,strerror(errno),"_wopen",0);return FALSE;}

if(bAppend)
  {
  DWORD dwf=filelength(hSave);//GetFileSize(hSave,NULL);
  lseek(hSave,dwf,SEEK_SET);  
  }

int hFile=_wopen(wFile,_O_BINARY|_O_CREAT|_O_RDWR,_S_IREAD | _S_IWRITE);
if(hFile==-1) {MessageBox(NULL,strerror(errno),"_wopen2",0);close(hSave);return FALSE;}

char cp; int ir;
while(!_eof(hFile))
{
ir=read(hFile,&cp,1);
if(ir<1){MessageBox(NULL,strerror(errno),"read",0);break;}
ir=write(hSave,&cp,1);
if(ir<1){MessageBox(NULL,strerror(errno),"read",0); break;}

//iloop++;if(iloop>1024*1000*1000)break;
}

close(hFile);
close(hSave);
return TRUE;
}




///////////////////////////////////////////////////////////////////////////////
//  ����������չ: ��������������ļ�/��  ////////////////////  [2005��8��20�� 15ʱ26��] ////////////////////
///////////////////////////////////////////////////////////////////////////////
//BrowseCallbackProc[]. // For GetFolderEx[]: 
int CALLBACK BrowseProc(HWND hwnd,UINT uMsg,LPARAM lParam,LPARAM lpData)
{
LPCITEMIDLIST pid; char szTmp[MAX_PATH];
switch(uMsg)
  {
  case WM_LBUTTONDBLCLK:  //No effect! ////"WM_LBUTTONDBLCLK");	    
  break;  

  case BFFM_INITIALIZED:
    {//SendMessage(hwnd,BFFM_ENABLEOK/BFFM_SETSELECTION/ BFFM_SETSTATUSTEXT ,...,...); 
    ::SendMessage(hwnd, BFFM_SETSTATUSTEXT,0,(LPARAM)"��ѡ���Ŀ¼Ϊ��");    
    ::SendMessage(hwnd, BFFM_SETSELECTIONW,TRUE,(LPARAM)lpData);//szDef//(LPARAM)"C:\\WorkStation\\Work\\");//(LPARAM)"c:\\Permanent\\" 
    HWND hDesktop=GetDesktopWindow();
    RECT re;GetClientRect(hDesktop,&re);RECT rc;GetClientRect(hwnd,&rc);
    MoveWindow(hwnd,re.right/2-rc.right/2,re.bottom/2-rc.bottom/2,rc.right,rc.bottom+30,TRUE);
    }
  break;

  case BFFM_SELCHANGED:
    pid=(LPCITEMIDLIST)(lParam);
    SHGetPathFromIDList(pid,szTmp); //wsprintf(szInfo,szTmp);
    ::SendMessage(hwnd, BFFM_SETSTATUSTEXT,0,(LPARAM)szTmp);
    
    if(strstr(szTmp,".wav")) 
    if(MessageBox(hwnd,"��ѡ����wav�ļ�.�Ƿ񲥷�?",NULL,MB_YESNO)==IDYES)
      PlayFile(szTmp);
  break;  
  case BFFM_VALIDATEFAILED:
  break;  
  }
return 0;
}  




    
////////////////////  [2006��2��18��ShellExecuteEx[]] ////////////////////
BOOL  PlayFile(LPCTSTR szFile)
{
//HWND hwnd;
SHELLEXECUTEINFO shinf={0};
shinf.cbSize=sizeof(SHELLEXECUTEINFO);
shinf.fMask=SEE_MASK_NO_CONSOLE;//SEE_MASK_NOCLOSEPROCESS|
shinf.hwnd=NULL;
shinf.lpVerb=NULL;
shinf.lpFile=szFile;
shinf.lpParameters="";
shinf.lpDirectory=NULL;
shinf.nShow=SW_SHOW;
shinf.hInstApp=NULL;

BOOL br=ShellExecuteEx(&shinf);
if(!br) eInfo("ShellExecuteEx");

//ShowWindow(hwnd,SW_MINIMIZE);
return br;
}    



