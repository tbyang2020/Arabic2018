



#ifndef _TRAY_H_
#define _TRAY_H_

#ifndef _WIN64
#define DWORD_PTR DWORD
#endif


//#include <commctrl.h> //LIB: comctl32.lib
//#pragma comment(lib, "comctl32.lib")

#include "ShellAPI.h" // LIB: Shell32.lib --- Ҫ��XpSp2�汾 
//#pragma comment(lib, "D:\\DevStudio\\m_libs\\Shell32.lib")
//#pragma comment(linker, "/LIBPATH:D:\\DevStudio\\m_libs")
#pragma comment(lib, "Shell32.lib") // --- 1��Shell32.lib������Ŀ¼��. 2��Ҫ��XpSp2�汾 

#define WM_TRAYICON  WM_USER+0x100  // ����ͼ����Ϣ  

//�ṹ����TRAY.CPP��ʵ��
#ifdef  _TRAY_CPP_    //#endif  // _TRAY_CPP_ //
#define TRAY_EXTERN   
#else 
#define TRAY_EXTERN extern 
#endif  // _TRAY_CPP_ //


extern HMENU hPopMenu; 
// .................. �������� .................. // 

// TrayIcon, ��������, ����Shell_NotifyIcon.
BOOL TrayIcon(HWND hDlg, DWORD umsg, UINT uID, HICON hIcon, PSTR pszTip);
BOOL TrayIconW(HWND hDlg, DWORD umsg, UINT uID, HICON hIcon, LPCWSTR pszTip);

// 1/3, AddTrayIcon, ����Ӧ�ú���.
void AddTrayIcon(HWND hDlg, UINT_PTR Index,
  UINT ID_Icon=0,LPSTR szTip=0);
void AddTrayIcon(HWND hDlg, UINT_PTR Index,
  HICON hIcon=0,LPSTR szTip=0); 
void AddTrayIconW(HWND hDlg, UINT Index,UINT ID_Icon=0,LPCWSTR szTip=0);
void AddTrayIconW(HWND hDlg, UINT Index, HICON hIcon=0,LPCWSTR szTip=0);

// 2/3, ModifyTrayIcon, ����Ӧ�ú���.
void ModifyTrayIcon(HWND hDlg, UINT Index, UINT ID_Icon=0,LPSTR szTip=0);
void ModifyTrayIcon(HWND hDlg, UINT_PTR uIndex, HICON hIcon=0L,LPSTR szTip=0L);
void ModifyTrayIconW(HWND hDlg, UINT Index, UINT ID_Icon=0,LPCWSTR szTip=0);
void ModifyTrayIconW(HWND hDlg, UINT Index,HICON hIcon=0L,LPCWSTR szTip=0L);

BOOL ModifyIconTip(HWND hDlg, UINT uID,LPCWSTR szTip); 



// 3/3, DeleteTrayIcon, ����Ӧ�ú���.
void DeleteTrayIcon(HWND hDlg, UINT Index);

// ShowBalloonTip, ��ʾ������ʾ, �߼�Ӧ�ú��� 
void ShowBalloonTip(HWND hDlg,LPCTSTR szMsg,LPCTSTR szTitle=0, 
  UINT uID=0, UINT uTimeout=0, DWORD dwInfoFlags=0x01 );  //=NIIF_INFO // |NIIF_NOSOUND 
void ShowBalloonTipW(HWND hDlg, LPCWSTR szMsg,LPCWSTR szTitle=0,  
  UINT uID=0, UINT uTimeout=0, DWORD dwInfoFlags=0x01 ); 


// On_TrayIcon, ����WM_TRAYICON��Ϣ ... ����hWnd��WndProc,���ʵ��޸�.
// LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam):
// case WM_TRAYICON: On_TrayIcon(.);break;
// wParam: the identifier of the taskbar icon in which the event occurred. 
// lParam: the mouse or keyboard message(id) associated with the event. 
void On_TrayIcon(HWND hWnd,WPARAM wParam,LPARAM lParam,HMENU hMenu);
// ------------------ �������� ------------------ // 




#endif // _TRAY_H_ //