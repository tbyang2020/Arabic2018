



#ifndef _INTERFACE_H_
#define _INTERFACE_H_    // #endif  // _INTERFACE_H_ //


// �ṹ����Interface.cpp��ʵ��;
#ifdef  _INTERFACE_CPP_    // #endif  // _INTERFACE_CPP_ //
#define INTERFACE_EXTERN 
#else 
#define INTERFACE_EXTERN extern 
#endif  // _INTERFACE_CPP_ //


INTERFACE_EXTERN  LPVOID  g_pFile;  // �ļ�ӳ��   


// INTERFACE_EXTERN HWND hThisWnd;  // ����������

INTERFACE_EXTERN HWND hDialog;   // ���Ի�����
INTERFACE_EXTERN HINSTANCE hThisInst;  // ������ʵ�����

INTERFACE_EXTERN HMENU hPopMenu;
INTERFACE_EXTERN HMENU hTrayIconMenu;

INTERFACE_EXTERN TCHAR szInterface[MAX_PATH];

INTERFACE_EXTERN wchar_t szTesmi[]
#ifdef  _INTERFACE_CPP_    //#endif  // _INTERFACE_CPP_ //
= L"\x628\x650\x633\x640\x640\x640\x640\x640\x645\x650\x20\x623\x644\x644\x647\x650\x20\x623\x644\x631\x651\x64E\x62D\x652\x645\x64E\x627\x646\x20\x650\x20\x623\x644\x631\x651\x64E\x62D\x650\x64A\x640\x640\x640\x640\x645\x650";
#else 
;
#endif  // _INTERFACE_CPP_ //


void SetTransparence(HWND hWnd, int a=-1); 
HWND AddControl(HWND hWnd, LPCWSTR szClass, DWORD dwStyle = 0, int id = 1, RECT*rc = 0L); 





void drawRect(HDC hdc, RECT*rc, COLORREF co=0);  



LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);



#endif  // _INTERFACE_H_ //




