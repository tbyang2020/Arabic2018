﻿




// Interface.cpp, 系统程序界面,  要提供热键、Taskbar-Icon等高级控制方式. 

// 工具 – Internet选项 – 高级 – 安全 - 允许活动内容在我的电脑中运行 √  

#define _INTERFACE_CPP_ 

// #define WINVER 0x0500 // #include <WinUser.h>:  TITLEBARINFO
// #define _WIN32_IE 0x0501  // 默认0x400. for  NIN_BALLOONUSERCLICK

#include <Windows.h>
#include "res/resource.h"
#include <stdio.h>

// #include "ShellAPI.h" // LIB: Shell32.lib --- 要求XpSp2版本 

#include "Interface.h"

#include "qTrace.h"

#include "../Arabic.h"



#pragma warning(disable:4996)
#define  _CONST_CORRECT_OVERLOADS  
#define  _CONST_RETURN   // non-const behavior for both C++ overloads


#define rR  (1/3.)  // (1/3.)  // 

#define WM_HOOK WM_USER+WH_MAX+0x01

#define WND_CLASS    L"Supervisor"  // 使用Unicode版本注册表函数,REG_SZ要求Unicode字符串  
#define WND_TITLE    L"Win32App"  // 使用Unicode版本注册表函数,REG_SZ要求Unicode字符串  




// DISP_# 直接利用 IDV_#   
#if 0
enum DISP_STATE{
DISP_NORMAL,      // 
DISP_HISTOGRAM,   // 直方图 
DISP_PIXEL,       // 按照像素显示 

};
#endif  // 0

int g_DisplayState=IDV_NORMAL;  // 当前显示内容 


#define  VB 32 

RECT g_PixelRC={0,0,VB,VB};  
//#define   PIXEL_WIDTH   1
//#define   PIXEL_HEIGHT  1 

int g_Histogram[256];  


#include "../Arabic.h"
 


bool GetFileName(LPWSTR szFile, bool bSave=FALSE, HWND hWnd=0L){ 

wchar_t*pFilter= new wchar_t[MAX_PATH]; 

swprintf(pFilter, L"All Files (*.*)|*.*|程序(*.exe;*.fon)|*.exe;*.fon|Text Files(*.txt;*.doc;*.rtf)|*.txt;*.doc;*.rtf|Icon Files (*.ICO)|*.ICO|Bitmap Files (*.bmp)|*.bmp|");
// Text Files(*.txt;*.doc);*.rtf|*.txt;*.doc;*.rtf|Icon Files (*.ICO)|*.ICO|All Files (*.*)|*.*|
// All Files (*.*)|*.*|
// Text Files(*.txt;*.doc;*.rtf)|*.txt;*.doc;*.rtf|
// Icon Files (*.ICO)|*.ICO|
// Bitmap Files (*.bmp)|*.bmp|


wchar_t*p=pFilter;  while(*p!=0){ if(*p=='|') *p=0; p++; }  // 替换'|'为'\0';
  
//                     0            1   2     3      4 5 6    7       8   9  10  11    12 
OPENFILENAMEW ofn = {sizeof(ofn), hWnd, 0,  pFilter, 0,0,0,  szFile, 256, 0, 0,   0L,   L"打开文件", 
  OFN_FILEMUSTEXIST,   // |OFN_ENABLESIZING |OFN_EXPLORER |OFN_SHOWHELP  |OFN_SHAREAWARE,  
  0,0,0,0,0,0,0,0,0};  // 9 个 0 

bool bok = false; 

*szFile = 0;  // 必须  
// bool bok=GetOpenFileNameW(&ofn);

if(bSave){
  ofn.Flags|=OFN_OVERWRITEPROMPT;
 // ofn.lpstrDefExt =NULL;  // 必须加扩展名 
  ofn.lpstrTitle =L"保存文件";
  bok=GetSaveFileNameW(&ofn);
}else{
  ofn.Flags|= OFN_FILEMUSTEXIST|OFN_SHAREAWARE;  // OFN_ALLOWMULTISELECT; //
//  ofn.lpstrTitle =L"打开文件";  
  bok=GetOpenFileNameW(&ofn);
}


delete[] pFilter;

return bok;
}


// TrackMenu, 显示菜单. 辅助函数 
void TrackMenu(HMENU hmenu,HWND hdlg){ 
POINT pt; GetCursorPos(&pt);  
// TPMPARAMS arp;arp.cbSize=sizeof(TPMPARAMS);  arp.rcExclude.left=0;  arp.rcExclude.top=0; arp.rcExclude.right=80;  arp.rcExclude.bottom=80;
TPMPARAMS tpm={sizeof(tpm),}; 
tpm.rcExclude.left=0,tpm.rcExclude.top=0,tpm.rcExclude.right=300,tpm.rcExclude.bottom=300; // screen area not to overlap       
UINT uFlag=TPM_VCENTERALIGN  //|TPM_TOPALIGN
      |TPM_LEFTBUTTON        //|TPM_NOANIMATION|TPM_VERPOSANIMATION //Win98,Win2000
      |TPM_HORIZONTAL;       //|TPM_NONOTIFY//|TPM_RETURNCMD //不直接响应鼠标选择
TrackPopupMenuEx(hmenu,uFlag,pt.x,pt.y,hdlg,&tpm);
}


// 指定窗口透明度.  int da 为透明度增量 ±1, ±2, ...  
void SetTransparence(HWND hWnd, int da){  // =-1

  static int ao = 255. *80/100;   // %80 不透明  %20 透明  
  //if(0 <= a && a < 256) ao = a; else ao++;

  ao += da;  

  if(ao < 25) ao = 25;    // 至少 10% 不透明 
  if(ao > 255) ao = 255;  // 彻底不透明
  
  SetLayeredWindowAttributes(hWnd, 0, ao, LWA_ALPHA); 
}



// 添加控件. dwStyle=WS_VISIBLE|WS_CHILD; //|WS_BORDER|WS_VSCROLL
// 可以随时调用 DestroyWindow 销毁子窗口

HWND AddControl(HWND hWnd, LPCWSTR szClass, DWORD dwStyle, int id  , RECT*rc ){ // = 0, 1, 0L

//INITCOMMONCONTROLSEX initCrl;initCrl.dwSize=sizeof(INITCOMMONCONTROLSEX);//initCrl.dwICC=ICC_TAB_CLASSES; 
//BOOL bOk=InitCommonControlsEx(&initCrl);//InitCommonControls();
//if(!bOk){MessageBox(NULL,"InitCommonControlsEx)","error",0); return NULL;}

RECT re;
if(rc!=NULL)  re=*rc; 
else{  GetClientRect(hWnd,&re); 
int B=8;  
re.left+=B; re.right-=B;
re.top+=B; re.bottom-=B;
}

DWORD dws = WS_VISIBLE|WS_CHILD;  //|WS_BORDER|WS_VSCROLL 
dws|=dwStyle; 
HWND hChild=CreateWindowExW(0,szClass,szClass,dws,
			 re.left,re.top,re.right-re.left, re.bottom-re.top,
			 hWnd,(HMENU)id,0L,0L);

// ShowWindow(hChild,SW_SHOW); 
return hChild;
}

 









void drawRect(HDC hdc, RECT*rc, COLORREF co){ // =0 
	
if (!rc) return; 

	HPEN hPen = (HPEN)SelectObject(hdc, GetStockObject(DC_PEN)); 
	SetDCPenColor(hdc, co); 

	MoveToEx(hdc, rc->left, rc->top, 0L); 
	LineTo(hdc, rc->left, rc->bottom); 
	LineTo(hdc, rc->right, rc->bottom); 
	LineTo(hdc, rc->right, rc->top); 
	LineTo(hdc, rc->left, rc->top); 

SelectObject(hdc, hPen); 

}



// embed rect rc into  rect rco.

void emRect(HDC hdc, RECT* rco, RECT*rc){

// if(!rco || !rc) return; 

RECT rco_t = {140, 30, 250, 240};
RECT rc_t= {504,20, 600, 200};  // {-504,200, 600, -20};   //
if (!rco) rco=&rco_t;
if (!rc) rc=&rc_t; 


	drawRect(hdc, rco,0xFF0000);   
RECT rtd=*rco; rtd.left-=8, rtd.top-=8; rtd.right+=8; rtd.bottom+=8; 
	drawRect(hdc, &rtd,0xC0C0C0); 

	drawRect(hdc, rc,0x0000FF); 
rtd=*rc; rtd.left-=8, rtd.top-=8; rtd.right+=8; rtd.bottom+=8; 
	drawRect(hdc, &rtd,0xC0C0C0); 




float w=rco->right-rco->left, W=rc->right-rc->left; 
float h=rco->bottom-rco->top, H=rc->bottom-rc->top; 
if (w==0||h==0||W==0||H==0) return; 

XFORM g_XFO;  GetWorldTransform(hdc,&g_XFO);   // 必要时恢复当前世界矩阵 

#if MAKE_TRANSFORM |1

SetGraphicsMode(hdc,GM_ADVANCED);  

XFORM g_pXF={1,0, 0,1,  0,0}; 

//g_pXF.eM11 *= W/w;   \
g_pXF.eM22 *= H/h;   \
g_pXF.eDx= rc->left - rco->left*W/w,  g_pXF.eDy= rc->top - rco->top*H/h;  // rco into rc


g_pXF.eM11 *= w/W;   \
g_pXF.eM22 *= h/H;   \
g_pXF.eDx= rco->left - rc->left*w/W,  g_pXF.eDy= rco->top - rc->top*h/H;  // rc into rco 


SetWorldTransform(hdc,&g_pXF); 

#endif  // MAKE_TRANSFORM


//drawRect(hdc, rco,0x00FF00);
 
rtd=*rco; rtd.left+=4, rtd.top+=4; rtd.right-=4; rtd.bottom-=4; 
	drawRect(hdc, &rtd,0xC0C000); 

rtd=*rc; rtd.left+=4, rtd.top+=4; rtd.right-=4; rtd.bottom-=4; 
	drawRect(hdc, &rtd,0x00B0B0); 


SetWorldTransform(hdc,&g_XFO); 

}


//#define max(a,b,c )  ( (((a) > (b)) ? (a) : (b)) < (c) ? (c): (((a) > (b)) ? (a) : (b)) )   



int APIENTRY WinMain(HINSTANCE hInst,HINSTANCE hPrevInst,LPSTR pCmd,int nShow){


#if TEST_AREA|0
	qTrace("iswspace(0)=%d, iswspace(0x20)=%d", iswspace(0), iswspace(0x20));

int i=2;  qTrace("%d", 0<=i <=1)  // 竟然返回 true! 

	BYTE c=521;  qTrace("c=%d",c);

int j=15;  	qTrace("(%d+1)%8=%d",  j, (j+1)%8  );   return 0; 

qTrace("%d", max(1,2, 3) );  // 2  

#endif  // TEST_AREA



// 1、检查运行的实例;
HWND hWnd=FindWindowW(WND_CLASS,NULL);
if(hWnd){MessageBox(NULL,"程序只允许一个实例运行!","Warn",0); return 0;}
hThisInst=hInst;

// 2、 注册热键 Ctrl+P, Pause, Ctrl+Q, Exit; 
ATOM key_CTRL_P,key_CTRL_Q;
key_CTRL_P = GlobalAddAtom(TEXT("_Hotkey_CTRL_P"));   
key_CTRL_Q = GlobalAddAtom(TEXT("_Hotkey_CTRL_Q"));   
//If hWnd=NULL, WM_HOTKEY messages are posted to the message queue of the calling thread and must be processed in the message loop. 
if(!RegisterHotKey(NULL,key_CTRL_P,MOD_CONTROL, 'P')) if(0)eInfo("CTRL_P 热键注册失败!"); 
if(!RegisterHotKey(NULL,key_CTRL_Q,MOD_CONTROL, 'Q')) if(0)eInfo("CTRL_Q 热键注册失败!");   

// 3、 注册窗口类 MSG_ONLY, "OsPeek";
WNDCLASSEXW wc={sizeof(WNDCLASSEXW),CS_DBLCLKS|CS_HREDRAW|CS_VREDRAW,WndProc,0,0,hInst,0L,\
LoadCursor(NULL,IDC_ARROW),(HBRUSH)(COLOR_WINDOW+1),   (LPCWSTR)IDR_MENU1, WND_CLASS,0};  // 

// small class icon 
wc.hIconSm =(HICON)LoadImage(hInst, MAKEINTRESOURCE(IDI_ICON1), IMAGE_ICON, 
    GetSystemMetrics(SM_CXSMICON),GetSystemMetrics(SM_CYSMICON),LR_DEFAULTCOLOR);                   

RegisterClassExW(&wc); 

DestroyIcon(wc.hIconSm); 

// 4、 创建窗口; 显示提示信息. Main program;
MSG msg={0,0};  

// 如果参数 hInst 换为 NULL, GetWindowLong(hWnd,GWL_HINSTANCE) 将返回 NULL.
hWnd=CreateWindowExW(WS_EX_LAYERED,  // WS_EX_TOPMOST| 允许 SetLayeredWindowAttributes
  WND_CLASS,WND_TITLE,
  WS_SYSMENU|WS_POPUPWINDOW|WS_CAPTION|WS_SIZEBOX |WS_VISIBLE, // |WS_MINIMIZEBOX,//  twinkle 闪烁 
  100,50,540*2,320*2,0L,(HMENU)0, hInst,0L); 
if(hWnd==NULL){ qTrace("CreateWindowExW Failed"); goto _EXIT_ ; }   // UpdateWindow(hThisWnd); //?lest SetWindowsHookEx fail!

// g_pSetLayeredWindowAttributes(m_hCurrWnd, 0, (BYTE)m_slider.GetPos(), LWA_ALPHA);

SetLayeredWindowAttributes(hWnd, 0, 255, LWA_ALPHA);  // 要求 WS_EX_LAYERED   

// ShowWindow(hThisWnd,SW_SHOW);  // 不再闪烁.
// g_hHook=SetWindowsHookEx(WH_JOURNALRECORD,(HOOKPROC)JournalRecordMouseProc,hInst,0); if(!g_hHook) eInfo("SetWindowsHookEx"); \\

// 5、主循环. 
while(GetMessage(&msg,NULL,0,0)) {
if(msg.message==WM_HOTKEY){
if(HIWORD(msg.lParam)=='Q'){ DestroyWindow(hWnd);  break; }
if(HIWORD(msg.lParam)=='P'){ 
  if(IsWindowVisible(hWnd)) ShowWindow(hWnd,SW_HIDE);
  else ShowWindow(hWnd,SW_SHOW); 
  }
}

TranslateMessage(&msg);
DispatchMessage(&msg);
}

//7、清理退出
_EXIT_:

UnregisterHotKey(NULL, key_CTRL_Q);  // 注销退出热键 Ctrl+Q
UnregisterHotKey(NULL, key_CTRL_P);  // 删除热键 Ctrl+P
UnregisterClassW(WND_CLASS,hInst);

//if(g_hHook!=NULL) UnhookWindowsHookEx(g_hHook);  
return msg.wParam;
}






// 数字输入对话框  InputBox  

INT_PTR CALLBACK DialogProc(HWND hdlg,UINT uMsg, WPARAM wParam,LPARAM lParam){

switch (uMsg)  {
case WM_INITDIALOG:{

// HFONT hFont = CreateFont( 18, 8,  0,0,   400,  0,0,0,  1, 0,0,0,0, "Traditional Arabic" );    // (HFONT)GetStockObject(DEFAULT_GUI_FONT); 
// SendDlgItemMessage(hdlg,IDC_COMBO1,WM_SETFONT,(WPARAM)hFont,MAKELPARAM(true,0)); 
	
SetWindowTextW(hdlg,L"اَلسَّلَامُ عَلَيْكُم");  // 设计阶段的阿拉伯语不能正确显示! 

#if TEST_CHARS|1


wchar_t szt[64];
swprintf(szt, L"%d  昜 ", L'昜'); 
SendDlgItemMessageW(hdlg, IDC_COMBO1,CB_ADDSTRING,0,(long)szt);
swprintf(szt, L"%d  工 ", L'工'); 
SendDlgItemMessageW(hdlg, IDC_COMBO1,CB_ADDSTRING,0,(long)szt);
swprintf(szt, L"%d  丞 ", L'丞'); 
SendDlgItemMessageW(hdlg, IDC_COMBO1,CB_ADDSTRING,0,(long)szt);
swprintf(szt, L"%d  赢 ", L'赢'); 
SendDlgItemMessageW(hdlg, IDC_COMBO1,CB_ADDSTRING,0,(long)szt);
swprintf(szt, L"%d  鹰 ", L'鹰'); 
SendDlgItemMessageW(hdlg, IDC_COMBO1,CB_ADDSTRING,0,(long)szt);

swprintf(szt, L"%d  ا ", L'ا'); 
SendDlgItemMessageW(hdlg, IDC_COMBO1,CB_ADDSTRING,0,(long)szt);
swprintf(szt, L"%d  ش ", L'ش'); 
SendDlgItemMessageW(hdlg, IDC_COMBO1,CB_ADDSTRING,0,(long)szt);
swprintf(szt, L"%d  غ ", L'غ'); 
SendDlgItemMessageW(hdlg, IDC_COMBO1,CB_INSERTSTRING,0,(long)szt);

#endif   

SendDlgItemMessage(hdlg, IDC_COMBO1,CB_SETCURSEL,0,0);

}break;  //SetClassLong  // HINSTANCE hinst=GetModuleHandle(0); 
    

case WM_COMMAND: 
switch(LOWORD(wParam)){ 

case IDOK: 
EndDialog(hdlg,GetDlgItemInt(hdlg,IDC_COMBO1,0,0));    
break; 

case IDCANCEL:  
EndDialog(hdlg,-1);  // DestroyWindow(hdlg); // //EndDialog(hdlg,0);//
// SendMessage(GetParent(hdlg),WM_APP+0x01,0,0);
break;
     
default:break;
}//switch(wmId)
break; // WM_COMMAND

default:break;//switch (uMsg)
}
return FALSE;  // message  not processed 
}




// HANDLE g_hFile=NULL;  // 文本文件句柄, 用于记录 WH_JOURNALRECORD 事件的消息.

HWND  hToolTip=0; 

HFONT g_hFont=0;  


LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam){

// static double   g_xo=0, g_yo=0;                    // 原点,  WM_MOUSEMOVE 更改, 按下Ctrl键 
static int      g_cx, g_cy;                        // cursor point, WM_LBUTTONDOWN/UP 更改, 用于 WM_MOUSEMOVE    
static XFORM    g_XFW={1,0, 0,1, 0,0,};    // 世界矩阵.  WM_MOUSEWHEEL 缩放, WM_MOUSEMOVE平移. 


// static HFONT hFont= CreateFont( 18, 8,  0,0,   400,  0,0,0,  1, 0,0,0,0, "Arial" );   



int wId, wEvent;  

switch (message) { 

case WM_CREATE: {  

RECT rc; GetClientRect(hWnd,&rc);  
//g_XFW={1,0, 0, 1, rc.right/3, rc.bottom/3,}; 

// g_XFW.eDx=rc.right*2./7,  g_XFW.eDy=rc.bottom/2; 

// 载入 popup 菜单, 控制程序的设置、退出等等. hPopMenu=LoadMenu((HINSTANCE)GetWindowLong(hWnd,GWL_HINSTANCE),(LPCTSTR)IDR_MENU1); 
hPopMenu=LoadMenu(0,(LPCTSTR)IDR_MENU1);  
hPopMenu=GetSubMenu(hPopMenu,0);

HWND hEdit=AddControl( hWnd, L"Edit",WS_BORDER|WS_VSCROLL|ES_MULTILINE|ES_WANTRETURN, IDC_EDIT1); 
int h=16*2, w=0;  // 16*4  // lfHeight = GetDeviceCaps(hDC, LOGPIXELSY)*n/72 
g_hFont =     // (HFONT)GetStockObject(ANSI_VAR_FONT); 
CreateFont(h, w,  0, 0, FW_NORMAL, 0, 0, 0, ARABIC_CHARSET, 0, 0, 0, 0,  "Traditional Arabic");  // "Fixedsys Excelsior 3.01" // "宋体"
SendMessage(hEdit,WM_SETFONT,(long)g_hFont,0); 
SendMessage(hEdit,WM_SETTEXT,0,0);

} break;  // WM_CREATE 


case WM_DESTROY:
DestroyMenu(hPopMenu);	
PostQuitMessage(0);
break;



//case WM_RBUTTONDOWN:  TrackMenu(hPopMenu,hWnd);  break;

//case WM_LBUTTONDBLCLK: 

case WM_LBUTTONDOWN:  // g_cx=LOWORD(lParam), g_cy=HIWORD(lParam);  break; 
case WM_LBUTTONUP:  g_cx=LOWORD(lParam), g_cy=HIWORD(lParam);  InvalidateRect(hWnd,0,true);  break; 



case WM_LBUTTONDBLCLK: 
  SendMessage(hWnd,WM_COMMAND,IDT_TEST,0); 
break; 




case WM_MOUSEMOVE:{  // 有问题, 影响窗口重绘.

int x=LOWORD(lParam), y=HIWORD(lParam); if(x==g_cx && y==g_cy) break; 
int dx = (x - g_cx), dy = (y - g_cy);   
g_cx=x; g_cy=y; 

// qTrace("dx=%d, dy=%d", dx,dy);


if (g_DisplayState==IDV_PIXEL)
if( MK_LBUTTON&wParam ){  // MK_RBUTTON&wParam

static float g_dx=0, g_dy=0; 

g_dx+=dx; g_dy+=dy; // /4.
//if (g_dx<10 && g_dx>-10  && g_dy<10 && g_dy>-10) break; 

g_PixelRC.left+=g_dx; g_PixelRC.right+=g_dx;
g_PixelRC.top+=g_dy;  g_PixelRC.bottom+=g_dy;
g_dx=0, g_dy=0; 

 
if(g_PixelRC.right-g_PixelRC.left<VB){ 
 g_PixelRC.right+=(VB-(g_PixelRC.right-g_PixelRC.left))/2.;
 g_PixelRC.left-=(VB-(g_PixelRC.right-g_PixelRC.left))/2.;
}

if(g_PixelRC.bottom-g_PixelRC.top<VB){ 
 g_PixelRC.bottom+=(VB-(g_PixelRC.bottom-g_PixelRC.top))/2.;
 g_PixelRC.top-=(VB-(g_PixelRC.bottom-g_PixelRC.top))/2.;
}

if (g_PixelRC.left<0){  g_PixelRC.right-=g_PixelRC.left;  g_PixelRC.left=0;  }
if (g_PixelRC.top<0){  g_PixelRC.bottom-=g_PixelRC.top;  g_PixelRC.top=0;  }




InvalidateRect(hWnd,0,1); 
break;  
}


if( !(MK_LBUTTON&wParam) )break;  

if(dx<100 && dx>-100 && dy<100 && dy>-100){ g_XFW.eDx+=dx; g_XFW.eDy+=dy; }  // 最大位移 100 px 
g_cx=x; g_cy=y; 
InvalidateRect(hWnd,0,true);    // return 0;  
return 0;  
}break; 



#if TRANSPARENT_MODE 

case WM_MOUSEWHEEL:{  // // wParam(MK_CONTROL,delta), lParam(x,y)   
  if(!(LOWORD(wParam)&MK_CONTROL))break;

  int ir = GET_WHEEL_DELTA_WPARAM(wParam)/WHEEL_DELTA;  // (short)HIWORD(wParam) // WHEEL_DELTA=120 

  SetTransparence(hWnd, ir*3); 

}break;



#else

case WM_MOUSEWHEEL:{  

if( LOWORD(wParam)&MK_CONTROL ){  //  功能键按下, 更改透明度 

int ir = GET_WHEEL_DELTA_WPARAM(wParam)/WHEEL_DELTA;  // (short)HIWORD(wParam) // WHEEL_DELTA=120 
SetTransparence(hWnd, ir*3); 

break;
}   // if( LOWORD(wParam)&MK_CONTROL )



 
static int ir; ir=(short) HIWORD(wParam);   // nMouseWheelDelta. WHEEL_DELTA=120 的倍数  

//if((MK_CONTROL&LOWORD(wParam)) ){  //  按下 Ctrl 键, 调整 ScrollPos 

int scp=GetScrollPos(hWnd,SB_VERT);  scp-= ir/120; SetScrollPos(hWnd,SB_VERT,scp,true);  //SCROLLINFO sci={sizeof(sci),  SIF_TRACKPOS, 0,0,0,0, scp, };  SetScrollInfo(hWnd,0,&sci,1); // SIF_TRACKPOS只能查询，不能设置。
if(scp<0) scp=0; SendMessage(hWnd,WM_VSCROLL,MAKEWPARAM(SB_THUMBPOSITION,scp),0); 


if( !(MK_CONTROL&LOWORD(wParam)) ){  //  没按下 Ctrl 键, 调整坐标变换矩阵  

if(ir>0) g_XFW.eM11*=1.05, g_XFW.eM22*=1.05; 
else if(ir<0) g_XFW.eM11*=0.95, g_XFW.eM22*=0.95; 

if(g_XFW.eM11<0.1) g_XFW.eM11=0.1; if(g_XFW.eM11>10) g_XFW.eM11=10;  // 最大缩放比例 20:1 
if(g_XFW.eM22>0){ if(g_XFW.eM22<0.1) g_XFW.eM22=0.1; if(g_XFW.eM22>20) g_XFW.eM22=20;  } 
else            { if(g_XFW.eM22<-20) g_XFW.eM22=-20; if(g_XFW.eM22>-0.1) g_XFW.eM22=-0.1;  } 

InvalidateRect(hWnd,0,true); return 0;  
}  // 没按下 Ctrl 键, 调整坐标变换矩阵 

}break;  // case WM_MOUSEWHEEL  

#endif 


case WM_PAINT:{   // WM_NCPAINT 可以代替 WM_PAINT.  

PAINTSTRUCT ps;  
HDC hdc= BeginPaint(hWnd,&ps);

SetGraphicsMode(hdc,GM_ADVANCED); 
SetWorldTransform(hdc,&g_XFW); 

int B=  100; 
RECT re, rc;  GetClientRect(hWnd,&re); 
rc=re; 
rc.left+=B; rc.right-=B; rc.top+=B; rc.bottom-=B;   


static int *g_pSt=0;  // 统计数据  


switch (g_DisplayState){

case IDV_NORMAL: break;


case IDV_ALPHABET: {

//AddControl(hWnd, L"Edit",WS_BORDER,1); 
//	ar_Alphabet(hWnd); 

}break;







case IDV_PIXEL:{
////if(!g_pDIB) break; 
// RECT rs = g_pixelRC; 
////drawPixels(hdc,g_pDIB,&rc,&g_PixelRC);  // g_pixelRC 通过 WM_MOUSEMOVE 移动 
}break; 


case IDV_HISTOGRAM:{
// drawHistogram(hdc,g_Histogram); 

// drawDistribution(hdc, g_Histogram, 256);




}break; 







default:{
//if (!g_pSt)break; 



}break;  


}  //  




//DrawEdge(hdc,&rc,BDR_SUNKENINNER|BDR_RAISEDOUTER,BF_LEFT|BF_TOP); 
//DrawEdge(hdc,&rc,BDR_SUNKENINNER,BF_RECT|BF_FLAT); 

// static HFONT hFont=CreateFontDirect( 8,19,200,"Traditional Arabic");


#if DRAW_TIP

HFONT hf=(HFONT)GetStockObject(DEFAULT_GUI_FONT);
HFONT hof=(HFONT)SelectObject(hdc,hf);
SetTextColor(hdc,0xFF0000); 
TextOutW(hdc, rc.left+4,rc.bottom-12,L"双击测试",4);
TextOutW(hdc, rc.left+4,rc.bottom-12-24,L"右键菜单",4);  // 42---文字高度
SetTextColor(hdc,0); 
SelectObject(hdc,hof);

#endif  // DRAW_TIP


// drawFont(hdc,8,0xD,g_pFont); 
//drawFont(hdc,8,0x20,g_pFont); 

//drawFont(hdc,g_Fonts); 

//emRect(hdc, 0, 0);  



////vBit8(hdc,g_pDIB,&rc);  // 必须放在后面! 
 
EndPaint(hWnd,&ps);	
//\\SendMessage(hWnd,WM_NCPAINT,1,0);


#if DRAW_TITLE|0

TITLEBARINFO ti;  ti.cbSize=sizeof(TITLEBARINFO);  \
GetTitleBarInfo(hWnd,&ti);  RECT rt=ti.rcTitleBar; 

int iBX = GetSystemMetrics(SM_CXFRAME);   // SM_CXBORDER
int iBY = GetSystemMetrics(SM_CYFRAME);   // SM_CYEDGE  SM_CYBORDER
int iw  = GetSystemMetrics(SM_CXICON);  // SM_CXSMICON   SM_CXICON    SM_CXSIZE   SM_CXMENUSIZE
int ih  = GetSystemMetrics(SM_CYMENUSIZE);  // SM_CXSMICON SM_CYICON   SM_CYMENUSIZE   // // SM_CXICON    SM_CYSIZE   SM_CYMENU  SM_CYMENUSIZE

hdc = GetWindowDC(hWnd);
// int B=4;  
RECT r =  {iBX+iw, iBY, re.right-iBX-iw, 2*iBY+ih,};   // {iw+iBX, iBY, re.right-iw-iBX*2, ih+iBY,};    
// InvertRect(hdc, &r);  

HFONT holdf=(HFONT)SelectObject(hdc,hFont);
COLORREF co=GetPixel(hdc,r.left+(r.right-r.left)/2, r.top+(r.bottom-r.top)/2);
SetBkColor(hdc,co); SetTextColor(hdc,0xBB0000); //0xFFFFFF
DrawTextW(hdc,szTesmi,wcslen(szTesmi),&r,DT_CENTER);   //szTesmi
SelectObject(hdc,holdf);

ReleaseDC(hWnd,hdc);
#endif  // DRAW_TITLE


}break;  // case WM_PAINT 


case WM_HOOK: break;  // 只要有Hook消息,不用任何动作,菜单也会自动CancelMode! // OnMouseHook(hWnd,wParam,lParam);  // WM_CANCELMODE


case WM_SYSCOMMAND:{ break;  
switch(LOWORD(wParam)){
case SC_MINIMIZE:{
case SC_CLOSE:   // "关闭"改为"最小化". 

// RECT ro,r={ ptIcon.x-2, ptIcon.y-2, ptIcon.x+2, ptIcon.y+2,};
// GetWindowRect(hWnd,&ro);
// DrawAnimatedRects(hWnd,IDANI_CAPTION,&ro,&r); 
ShowWindow(hWnd,SW_HIDE); 
return 0;
}break; 

default: break; 
}
}break; // case WM_SYSCOMMAND




case WM_KEYDOWN:{  if(wParam==VK_ESCAPE){ DestroyWindow(hWnd);  break; }
switch(wParam){

case 'D':{ // SendMessage(hWnd, WM_DRAW,0,0);  
InvalidateRect(hWnd,0,1);  // 通过 GetKeyState 刷新显示
}break; 




}}break;




case WM_COMMAND:  
wId=LOWORD(wParam); wEvent=HIWORD(wParam); 

switch (wId){ 

case IDH_ABOUT: MessageBox(hWnd,"图像处理 2018-1-3","帮助",MB_OK); break; 


case  IDM_TEST:{

WCHAR wbuf[256];  
FILE* fp=fopen("L8p49.txt","rb");  if(!fp){qTrace("L8p49.txt"); break;}
while(!feof(fp)){

fgetws(wbuf,256,fp); 
WCHAR*p=wbuf;

while( iswspace(*p++) );  

if(!isArabic(*p)){  wbuf[0]=0; continue; }

break;  
}

if(!*wbuf) break;  

SendDlgItemMessageW(hWnd, IDC_EDIT1, EM_REPLACESEL,0, (long) wbuf); 

 
SendMessage(hWnd, WM_COMMAND,  MAKELONG(IDM_CONV,0),0);


}break;






case IDV_EDIT:{

HWND hEdit = GetDlgItem(hWnd,IDC_EDIT1);

if (!hEdit){

	 
hEdit = AddControl( hWnd, L"Edit",WS_BORDER|WS_VSCROLL|ES_MULTILINE|ES_WANTRETURN,1); 


int h=16*2, w=0;  // 16*4  // lfHeight = GetDeviceCaps(hDC, LOGPIXELSY)*n/72 
HFONT hFont =     // (HFONT)GetStockObject(ANSI_VAR_FONT); 
CreateFont(h, w,  0, 0, FW_NORMAL, 0, 0, 0, ARABIC_CHARSET, 0, 0, 0, 0,  "Traditional Arabic");  // "Fixedsys Excelsior 3.01" // "宋体"
SendMessage(hEdit,WM_SETFONT,(long)hFont,0); 
SendMessage(hEdit,WM_SETTEXT,0,0);

}  // if (!hEdit) 


InvalidateRect(hWnd,0,true); 
}break;


case IDV_DEL1:{

static int sw= SW_SHOW;

sw= (sw==SW_SHOW)? SW_HIDE:SW_SHOW;  

ShowWindow( GetDlgItem(hWnd,IDC_EDIT1), sw ); 
}break;



case IDV_ALPHABET:{  
//case IDV_NORMAL: g_DisplayState=wId; InvalidateRect(hWnd,0,1); break;  

ar_Alphabet(hWnd); 

}break; 

//case IDV_PIXEL:  g_DisplayState=wId; InvalidateRect(hWnd,0,1); break;  
////case IDV_HISTOGRAM:  g_DisplayState=wId; getHistogram(g_pDIB, g_Histogram); InvalidateRect(hWnd,0,1); break;  




case IDM_CONV:{  // 传换音标  
t_cx_ar(hWnd); 
	
}break; 






case IDO_OPEN:
case IDT_TEST:{ 

  wchar_t szFile[256];
  bool bok=GetFileName(szFile, 0);
  if(!bok) break; 


////if (g_pDIB){ free(g_pDIB); g_pDIB=0L; }

////if (!g_pDIB) g_pDIB = readDib(szFile); 
////assert(g_pDIB); 



InvalidateRect(hWnd,0,1); 
break;

//SendDlgItemMessage(hWnd, IDC_COMBO1, CB_SETCURSEL, rand()%20,0);
HDC hdc=GetWindowDC(hWnd); if(hdc==0){ eInfo("GetDCEx");  break; }
RECT rc,re; GetWindowRect(hWnd,&re); GetClientRect(hWnd,&rc);  
rc.bottom=(re.bottom-re.top)-rc.bottom;

DrawCaption(hWnd, hdc,&rc,DC_TEXT|DC_ICON|DC_ACTIVE|DC_GRADIENT);

ReleaseDC(hWnd,hdc); 
}break; 


case IDF_SAVE:{
  wchar_t szFile[256];
  bool bok=GetFileName(szFile, 1);
  if(!bok) break; 

////if(!saveDib(g_pDIB, szFile))MessageBoxW(0,L"Failed To Save File!",szFile,0); 
}break;





case IDM_EXIT: DestroyWindow(hWnd); break;

default: break;
}break; // case WM_COMMAND


default: break; // switch (message)
}

return DefWindowProcW(hWnd, message, wParam, lParam);;
}




