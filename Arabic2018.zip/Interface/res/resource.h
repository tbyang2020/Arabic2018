//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ ���ɵİ����ļ���
// �� Interface.rc ʹ��
//
#define IDC_BUTTON1                     3
#define IDC_BUTTON2                     4
#define IDC_BUTTON3                     5
#define IDC_BUTTON4                     6
#define IDC_BUTTON5                     7
#define IDC_BUTTON6                     8
#define IDI_ICON1                       101
#define IDD_DIALOG1                     101
#define IDI_ICON2                       102
#define IDR_MENU1                       103
#define IDB_BITMAP1                     106
#define IDB_BITMAP2                     107
#define IDI_ICON3                       107
#define IDI_ICON4                       109
#define IDI_ICON5                       112
#define IDI_ICON6                       113
#define IDI_ICON7                       115
#define IDI_ICON8                       116
#define IDI_ICON9                       117
#define IDI_ICON10                      118
#define IDI_ICON11                      119
#define IDI_ICON12                      120
#define IDC_STATIC1                     1000
#define IDC_STATIC2                     1001
#define IDC_STATIC3                     1002
#define IDC_STATIC4                     1003
#define IDC_CHECK1                      1003
#define IDC_EDIT1                       1004
#define IDC_COMBO1                      1005
#define IDC_COMBO2                      1006
#define IDC_COMBO5                      1007
#define IDC_COMBO3                      1008
#define IDC_COMBO4                      1010
#define IDO_EXIT                        40001
#define IDT_GENERAL                     40002
#define IDO_ENUMWND                     40003
#define IDO_PROCESS                     40004
#define IDO_PROCESSSNAP                 40005
#define IDO_WINDOWSNAP                  40006
#define IDO_SHOWWND                     40007
#define IDO_HIDEWND                     40008
#define IDO_CONFIG                      40009
#define IDO_SHOWTIP                     40010
#define IDO_HIDETIP                     40011
#define IDO_VIEW                        40012
#define IDO_CANCELL                     40013
#define IDO_LAMDAN                      40015
#define IDT_PLANET                      40016
#define IDT_TIMEZONE                    40017
#define ID_40018                        40018
#define IDT_TEST                        40019
#define IDO_01                          40020
#define IDO_OPEN                        40021
#define ID_40022                        40022
#define IDP_SPLIT                       40023
#define IDP_801                         40024
#define IDP_INVERT                      40025
#define ID_40026                        40026
#define IDP_EDGE                        40027
#define ID_40028                        40028
#define IDP_BINV                        40029
#define ID_Menu                         40030
#define ID_ABOUT                        40031
#define IDH_ABOUT                       40032
#define ID_40033                        40033
#define IDV_PIXEL                       40034
#define IDV_NORMAL                      40035
#define IDV_HISTOGRAM                   40036
#define ID_40037                        40037
#define IDF_SAVE                        40038
#define ID_40039                        40039
#define IDV_ALPHABET                    40040
#define ID_40041                        40041
#define IDV_EDIT                        40042
#define ID_40043                        40043
#define IDV_DEL_EDIT1                   40044
#define IDV_DEL1                        40045
#define IDM_TEST                        40046
#define IDM_EXIT                        40047
#define IDM_CONV                        40048

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        121
#define _APS_NEXT_COMMAND_VALUE         40049
#define _APS_NEXT_CONTROL_VALUE         1004
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
