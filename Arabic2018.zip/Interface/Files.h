
#ifndef _FILES_H_
#define _FILES_H_    //#endif  // _FILES_H_ //

//�ṹ����FILES.CPP��ʵ��
#ifdef  _FILES_CPP_    //#endif  // _FILES_CPP_ //
#define FILES_EXTERN 
#else 
#define FILES_EXTERN extern 
#endif  // _FILES_CPP_ //


#include <stdio.h>
#include <io.h>
#include <fcntl.h>
#include <sys/stat.h> 

//#include <sys/types.h>
#include <shlobj.h>

#include <direct.h>
//#include <stdlib.h>

#define UNICODEFLAG 0xFEFF    
#define UNICODETEXTFLAG 0xFEFF   

//////  [2006��3��1��]��ȡ�̶�Filter,�����,��Ӧ��Ҳ�㹻����//////
#define IDS_FILTER_TEXT   "Text Files(*.txt;*.doc;*.rtf)|*.txt;*.doc;*.rtf|\
All Files (*.*)|*.*|"

#define IDS_FILTER   "All Files (*.*)|*.*|\
Text Files(*.txt;*.doc;*.rtf)|*.txt;*.doc;*.rtf|\
Document Files(*.doc)|*.doc|\
Pure Text Files(*.txt)|*.txt|\
Rich Text Files(*.rtf)|*.rtf|\
Bitmap Files (*.bmp)|*.bmp|\
Icon Files (*.ico)|*.ico|\
Program  Files (*.exe;*.dll)|*.exe;*.dll|\
Executable Files (*.exe)|*.exe|\
Dll Files (*.dll)|*.dll|\
Record Files(*.rco)|*.rco|"


////////////////////////////  <Applications  ////////////////////////////
#define HEADER_MARKER   ((WORD) ('R'<<8) | 'C')





FILES_EXTERN //0x00-0xFF;
enum FILE_EXTENSIONS       // Declare enum type Days
{
FILE_EXTENSION_NOT_EXIST=-3,
FILE_EXTENSION_UNKNOWN=-2,
FILE_EXTENSION_FILE=-1,         //etc.

FILE_EXTENSION_BIN=0,          //etc.

//known file formats;
FILE_EXTENSION_TXT,
FILE_EXTENSION_UNICODETEXT, //ʵ�ʸ�ֵ�Ǹ����ļ�����*p==0xFEFF,�޸�FILE_EXTENSION_TXT���õ�;
FILE_EXTENSION_DOC,
FILE_EXTENSION_RTF,
FILE_EXTENSION_BMP,
FILE_EXTENSION_ICO,
FILE_EXTENSION_ICO_DLL,   //Icon In a DLL File;
FILE_EXTENSION_ICO_EXE,   //Icon In an EXE File;
FILE_EXTENSION_CUR,
FILE_EXTENSION_WAV,
FILE_EXTENSION_AVI,

FILE_EXTENSION_EXE,
FILE_EXTENSION_DLL,

//self defined formats;
FILE_EXTENSION_WRZ,
FILE_EXTENSION_RAG,
FILE_EXTENSION_ALL,


FILE_EXTENSION_BITMAP,
FILE_EXTENSION_ICON,
FILE_EXTENSION_NOTYPE,
};  



////  <0. ��������..  ////

int GetFileID(LPCTSTR szName, int _O_RDS=-1);
int GetFileID(LPCWSTR szName, int _O_RDS=-1);
int GetFileExtension(LPCTSTR szFile);
int GetFileExtension(LPCWSTR szFile);

////  ..0. ��������..  ////



////  <1. ���ļ���������..  ////
char* readfile(const wchar_t*szFile, int ib=0, int ie=-1);


int readfile(LPCTSTR szFile,LPVOID szBuf,int ib=0,int ie=-1); 
int readfile(LPCWSTR szFile,LPVOID szBuf,int ib=0,int ie=-1); 


int readline(int io,char*szp, int iB=65536);

int readline(int io,char*szp, const char splice); //='\\'=0
int readline(int io,wchar_t*szp);
int readsect(int io,wchar_t*szp);


DWORD ReadFile(LPCWSTR szFile,LPVOID szBuf=NULL,DWORD ic=-1,int istart=0);
DWORD ReadFile(LPCTSTR szFile,LPVOID szBuf=NULL,DWORD ic=-1,int istart=0);

////  ..1. ���ļ���������>  ////

////  <2. д�ļ���������..  ////

BOOL SaveFile(LPCTSTR szFile,LPCTSTR szSave,BOOL bAppend=false);
BOOL SaveFile(LPCWSTR szFile,LPCWSTR szSave,BOOL bAppend=false);
BOOL SaveFile(LPCTSTR szFile,LPVOID szSave,int ic=0,BOOL bAppend=false);
BOOL SaveFile(LPCWSTR szFile,LPVOID szSave,int ic=0,BOOL bAppend=false);

int SaveNew(int io,int iom,LPVOID szSave,int ic, int ib=0,int ie=-1);//0,-1;

int SaveNew(LPCWSTR szFile,const WORD*szCmpFile,LPVOID szSave,int ic,int ib=0,int ie=-1);
int SaveNew(LPCTSTR szFile,LPCTSTR szCmpFile,LPVOID szSave,int ic,int ib=0,int ie=-1);
int SaveNew(LPCWSTR szFile,LPVOID szSave, int ic); 
////  ..2. д�ļ���������>  ////




////  <4. ��������..  ////
HANDLE GetFileHandle(LPCTSTR szName);
HANDLE GetFileHandle(LPCWSTR szName);
////  ..4. ��������>  ////



///////////////////////////////////////////////////////////////////////////////
// ��������������ļ�/��  //////////////2007��5��12��//////////////
///////////////////////////////////////////////////////////////////////////////
BOOL GetFolder(LPTSTR szBuf,LPCTSTR szDefault="C:\\WorkStation",BOOL bFoldersOnly=FALSE);  //"C:\\Designs\\Rename\\Test\\*"
BOOL GetFolder(WORD* wBuf,LPCWSTR wDefault=L"C:\\Designs\\Rename\\Test\\*",BOOL bFoldersOnly=FALSE);

///////////////////////////////////////////////////////////////////////////////
//  ��������������ļ�  //////////////2007��5��12��//////////////
///////////////////////////////////////////////////////////////////////////////

//Primary������ļ�
bool GetFileName(LPWSTR szFileName,bool bSave=false,LPCWSTR szFileFilter=NULL,LPCWSTR szInitial=NULL);//,HWND hOwner=NULL //UINT uFilterID,
bool GetFileName(LPTSTR szFileName,bool bSave=FALSE,LPCTSTR szFileFilter=NULL,LPCTSTR szInitial=NULL);// //UINT uFilterID,

//Extension������ļ�
//BOOL GetFileNameEx(LPTSTR szFileName,BOOL bSave=FALSE,LPCTSTR szInitial=NULL,//UINT uFilterID,
//int iStyle=GETFILE_STYLE_EXPLORE_DEFINE); 



////////////////////   ////////////////////
///////////////////////////////////////////////////////////////////////////////
//��д���������������ļ� //2007��5��12��//
///////////////////////////////////////////////////////////////////////////////
//��д������
BOOL savefile(WORD* wFileName,char* szSave,int iTo=-1,BOOL bAppend=FALSE);//int iFrom=0,

//enumwindow


////////////////////////////  Applications>  ////////////////////////////


//�����ο�������////////////////////  [2005��8��20�� 15ʱ26��] ////////////////////
//Ҫ����IDS_FILTER�������#include "resource.h"����#include "Files.h"��ǰ�档
DWORD FileRead(LPVOID lpBuf,DWORD nToRead=-1,int iStart=0,LPCTSTR szFileName=NULL);
void ReadText();void ReadAsciis();

DWORD FileWrite(LPCVOID lpBuf,DWORD nToWrite=-1,int iStart=0,LPCTSTR szFileName=NULL);
void WriteText();

BOOL SaveFile(LPCWSTR wFileName,char* szSave,BOOL bAppend=FALSE);
BOOL SaveFile(LPCWSTR wFileName,WORD* wSave,BOOL bAppend=FALSE);
BOOL SaveFile(LPCTSTR szFileName,TCHAR* szSave,BOOL bAppend=FALSE);
BOOL SaveFile(LPCTSTR  szFileName,WORD* wSave,BOOL bAppend=FALSE);

BOOL FileModify(LPCVOID lpBuf,DWORD nToWrite=-1,int iStart=0,LPCTSTR szFileName=NULL);
void ModifyText();





///////////////////////////////////////////////////////////////////////////////
//  ������չ��������������ļ�/��   //2007��5��12��//
///////////////////////////////////////////////////////////////////////////////
int CALLBACK BrowseProc(HWND hwnd,UINT uMsg,LPARAM lParam,LPARAM lpData);
int CALLBACK BrowseProcW(HWND hwnd,UINT uMsg,LPARAM lParam,LPARAM lpData);
BOOL PlayFile(LPCTSTR szFile);

UINT_PTR CALLBACK OFNHookProcDefine(HWND hdlg,UINT uiMsg,WPARAM wParam,LPARAM lParam);// handle to dialog box
UINT_PTR CALLBACK OFNHookProcDefineW(HWND hdlg,UINT uiMsg,WPARAM wParam,LPARAM lParam);// handle to dialog box












#endif  // _FILES_H_ //



