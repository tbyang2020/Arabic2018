




#ifndef _TOOLTIPS_H_
#define _TOOLTIPS_H_  // #endif  // _TOOLTIPS_H_ //


//�ṹ����TOOLTIPS.CPP��ʵ��
#ifdef  _TOOLTIPS_CPP_    //#endif  // _TOOLTIPS_CPP_ //
#define TOOLTIPS_EXTERN 
#else 
#define TOOLTIPS_EXTERN extern 
#endif  // _TOOLTIPS_CPP_ //





//.................. ToolTip ..................//

HWND WINAPI AddToolTip(HWND hOwner,UINT uID=0, LPWSTR szTip=0);
void UpdateTip(HWND htip, HWND hWnd,UINT uID, LPWSTR wnew);
bool AddTool(HWND htip,HWND hOwner,UINT uID, LPWSTR wtip);
bool AddTool(HWND htip,HWND hOwner,HWND htool, LPWSTR wtip);

//------------------ ToolTip ------------------//








#endif  // _TOOLTIPS_H_ //