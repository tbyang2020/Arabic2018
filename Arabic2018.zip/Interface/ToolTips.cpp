




#define  _TOOLTIPS_CPP_   

//InitCommonControlsEx: comctl32.lib; //#include <commctrl.h>

#define WINVER 0x0500  // #include <WinUser.h>:  TITLEBARINFO

#include <Windows.h>
#include "res/resource.h"  

#include <commctrl.h>  // LIB: comctl32.lib

#include "ToolTips.h"  




//.................. ToolTip ..................//

// AddToolTip, ���hOwner: uID, ������ʾszTip. [2007-3-11 ���� 12:01:21]//
// d:\Msdn\2000JUL\1033\Shellcc.chm::/shellcc/CommCtls/ToolTip/UsingTooltips;
// #pragma comment(lib, "comctl32.lib")
// �÷�ʾ��:
// case WM_MOUSEMOVE:  if(bToolTipVisible) SendMessage(g_hwndTT,TTM_TRACKPOSITION,0,(LPARAM)MAKELPARAM(GET_X_LPARAM(lParam)+15,GET_Y_LPARAM(lParam)+15));

HWND WINAPI AddToolTip(HWND hOwner,UINT uID, LPWSTR szTip){ //=0, =NULL;

// INITCOMMONCONTROLSEX icex;icex.dwSize=sizeof(icex);icex.dwICC =ICC_BAR_CLASSES;  \
if(!InitCommonControlsEx(&icex)) return NULL;  // Load the tooltip class from the DLL.

HWND hwndTT=CreateWindowExW(WS_EX_TOPMOST,TOOLTIPS_CLASSW,NULL,
                          WS_POPUP|TTS_NOPREFIX|TTS_ALWAYSTIP ,0,0,0,0,  //|TTS_BALLOON |TTM_RELAYEVENT  
                          hOwner,(HMENU)NULL,(HINSTANCE)NULL,NULL);
// Prepare TOOLINFO structure for use as tracking tooltip.
TOOLINFOW ti={0}; ti.cbSize=sizeof(TOOLINFOW); // ti.hinst=hinst;
ti.uFlags=TTF_SUBCLASS;  // |TTF_ABSOLUTE | TTF_TRACK;
if(uID!=0)  ti.uFlags|=TTF_TRANSPARENT|TTF_IDISHWND;  

ti.hwnd=hOwner;  // If lpszText includes the LPSTR_TEXTCALLBACK value, this member identifies the window that receives the TTN_GETDISPINFO notification messages.  

if(uID!=0) ti.uId=(UINT)GetDlgItem(hOwner,uID);  else  ti.uId=0x01; 

ti.lpszText=szTip;  // L"���ش���"; 


//GetClientRect(hOwner,&ti.rect);  // no effect when TTF_IDISHWND; //ti.rect.left=ti.rect.top=ti.rect.bottom=ti.rect.right=0; 

int icx=GetSystemMetrics(SM_CXSIZE);  // 25
TITLEBARINFO tin={sizeof(tin),0}; GetTitleBarInfo(hOwner,&tin);
RECT r=tin.rcTitleBar;   int iw=r.right-r.left, ih=r.bottom-r.top;
SetRect(&ti.rect,iw-icx, -ih,  iw,0);


if(!SendMessage(hwndTT,TTM_ADDTOOLW,0,(LPARAM)&ti)) { MessageBox(NULL,"TTM_ADDTOOLW","error",0); }    
//int ipc=SendMessage(hwndTT,TTM_SETMAXTIPWIDTH,0,5); 
return hwndTT;

ti.uId=(UINT)GetDlgItem(hOwner, 0x40);  // ITEM_COMBO
ti.lpszText=L"�����ı�!"; 
if(!SendMessage(hwndTT,TTM_ADDTOOLW,0,(LPARAM)&ti)) {MessageBox(NULL,"TTM_ADDTOOLW","error",0);  return NULL;}    
ti.uId=(UINT)GetDlgItem(hOwner, 0x0B);  // ITEM_CLIENT  
ti.lpszText=L"���س���ѡ��!"; 
if(!SendMessage(hwndTT,TTM_ADDTOOLW,0,(LPARAM)&ti)) {MessageBox(NULL,"TTM_ADDTOOLW","error",0); return NULL;}    

//SendMessage(hwndTT,TTM_SETDELAYTIME,TTDT_AUTOMATIC,-1);

SendMessage(hwndTT,TTM_TRACKACTIVATE,(WPARAM)TRUE,(LPARAM)&ti);  // Activate (display) the tracking tooltip;
//bToolTipVisible=TRUE;
return(hwndTT);    
}

//TTN_GETDISPINFO
//    lpnmtdi = (LPNMTTDISPINFO)lParam;
//#define TTN_NEEDTEXT TTN_GETDISPINFO


void UpdateTip(HWND htip,HWND hOwner,UINT uID, LPWSTR wnew){
TOOLINFOW ti;ti.cbSize=sizeof(TOOLINFOW);//ti.uFlags = TTF_SUBCLASS|TTF_ABSOLUTE;//|TTF_IDISHWND;//; //TTF_SUBCLASS; //
ti.uId=(UINT)GetDlgItem(hOwner,uID);  //uid;//UINT uid = 0; //uID;//  
ti.lpszText=wnew;//GetClientRect(hWnd, &ti.rect);//All items in the client area;//ti.rect.bottom=20;  // GET COORDINATES OF THE MAIN CLIENT AREA;// Tooltip control will cover the whole window; 
SendMessageW(htip,TTM_UPDATETIPTEXTW,0,(LPARAM)&ti);		
}



bool AddTool(HWND htip,HWND hOwner,UINT uID, LPWSTR wtip){
TOOLINFOW ti={0}; ti.cbSize=sizeof(TOOLINFOW); //ti.hinst=hinst;
ti.uFlags=TTF_SUBCLASS|TTF_ABSOLUTE|TTF_TRANSPARENT|TTF_IDISHWND; //TTF_TRACK|;
ti.hwnd=hOwner;  ti.uId=(UINT)GetDlgItem(hOwner,uID);//uID;//
ti.lpszText=wtip; //GetClientRect(hOwner,& ti.rect);//no effect when TTF_IDISHWND; //ti.rect.left=ti.rect.top=ti.rect.bottom=ti.rect.right=0; 
if(!SendMessage(htip,TTM_ADDTOOLW,0,(LPARAM)&ti)) 
  {MessageBox(NULL,"TTM_ADDTOOLW","error",0); return false;}    

//int ipc=SendMessage(htip,TTM_SETMAXTIPWIDTH,0,5); 
return true;
}

bool AddTool(HWND htip,HWND hOwner,HWND htool, LPWSTR wtip){
TOOLINFOW ti={0}; ti.cbSize=sizeof(TOOLINFOW); //ti.hinst=hinst;
ti.uFlags=TTF_SUBCLASS|TTF_ABSOLUTE|TTF_TRANSPARENT|TTF_IDISHWND; //TTF_TRACK|;
ti.hwnd=hOwner;  ti.uId=(UINT)htool;//uID;//
ti.lpszText=wtip; //GetClientRect(hOwner,& ti.rect);//no effect when TTF_IDISHWND; //ti.rect.left=ti.rect.top=ti.rect.bottom=ti.rect.right=0; 
if(!SendMessage(htip,TTM_ADDTOOLW,0,(LPARAM)&ti)) 
  {MessageBox(NULL,"TTM_ADDTOOLW","error",0); return false;}    

//int ipc=SendMessage(htip,TTM_SETMAXTIPWIDTH,0,5); 

return true;
}



//------------------ ToolTip ------------------//
