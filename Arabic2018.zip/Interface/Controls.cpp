





#define  _CONTROLS_CPP_    //�ṹ����CONTROLS.CPP��ʵ��;

//InitCommonControlsEx: comctl32.lib; //#include <commctrl.h>

#define WINVER 0x0500 // #include <WinUser.h>:  TITLEBARINFO

#include <Windows.h>
#include "res/resource.h" //IDI_ICON1
//#include "Wide.h"
//#include "EProcess.h"
//#include <RICHEDIT.H>



#include "Files.h"
//#include "ioop.h"
#include "Controls.h"
//#include "info.h"







#pragma warning(disable:4996)
#define  _CONST_CORRECT_OVERLOADS  
#define  _CONST_RETURN   // non-const behavior for both C++ overloads

#define WORD wchar_t 










WORD wControls[MAX_PATH]={0};
HWND hStatus;







// AddControl, ΪhWnd���ӿؼ�szClass.
// dwStyle���ӵ�ʽ����szClass�й�. ���AddControlһ�㲻����ȫ����AddEdit�ȵ�. 
// AddControl(hWnd,szClass,0,0,1);

HWND AddControl(HWND hWnd,LPWSTR szClass, UINT id, RECT* reo,DWORD dwStyle){ //=ITEM_LIST
//INITCOMMONCONTROLSEX initCrl;initCrl.dwSize=sizeof(INITCOMMONCONTROLSEX);//initCrl.dwICC=ICC_TAB_CLASSES; 
//BOOL bOk=InitCommonControlsEx(&initCrl);//InitCommonControls();
//if(!bOk){MessageBox(NULL,"InitCommonControlsEx)","error",0); return NULL;}

if(dwStyle==0) dwStyle=get_style(szClass);//WS_VISIBLE|WS_CHILD; //|WS_BORDER|WS_VSCROLL

dwStyle|=WS_VSCROLL; 


RECT re;
if(reo!=NULL)  re=*reo;
else GetClientRect(hWnd,&re); 

HWND hChild=CreateWindowExW(0,szClass,szClass,dwStyle,
			 re.left,re.top,re.right-re.left, re.bottom-re.top,
			 hWnd,(HMENU)id,0L,0L);

ShowWindow(hChild,SW_SHOW); 
return hChild;
}


















// style, ָ���ؼ���ȱʡʽ��. 

inline DWORD get_style(LPCWSTR szclass){  if(szclass==0)return 0; 
WORD*p=new WORD[wcslen(szclass)+1];  wcscpy(p,szclass); 
wcslwr(p); DWORD dwStyle=WS_VISIBLE|WS_CHILDWINDOW|WS_TABSTOP|WS_BORDER; //|WS_SIZEBOX
dwStyle|=WS_CLIPSIBLINGS|WS_CLIPCHILDREN; 

if(wcscmp(p,L"static")==0)dwStyle|=SS_WORDELLIPSIS|SS_NOTIFY|SS_CENTER;  
if(wcscmp(p,L"edit")==0) dwStyle|= WS_HSCROLL| WS_VSCROLL|ES_AUTOHSCROLL|ES_AUTOVSCROLL|ES_MULTILINE|ES_WANTRETURN; 
if(wcscmp(p,L"listbox")==0) dwStyle|=LBS_DISABLENOSCROLL|LBS_HASSTRINGS|LBS_NOTIFY||LBS_WANTKEYBOARDINPUT;  
if(wcscmp(p,L"combobox")==0) dwStyle|=LBS_HASSTRINGS|CBS_DROPDOWN |CBS_NOINTEGRALHEIGHT |CBS_AUTOHSCROLL;

if(wcscmp(p,L"button")==0) dwStyle|=BS_CENTER|BS_FLAT|BS_VCENTER;

if(wcscmp(p,L"richedit")==0) dwStyle|=0; 
//if(wcscmp(p,L"syslist")==0) dwStyle|=0; 
if(wcscmp(p,L"listview")==0) dwStyle|=0; 
if(wcscmp(p,L"treeview")==0) dwStyle|=0; 
if(wcscmp(p,L"tab")==0) dwStyle|=0;  

return dwStyle; 
}





//��ʾ�ڴ�: Static�ؼ�;
HWND AddStatic(HWND hParent,UINT uID,RECT* reo, bool bIcon){
RECT re;
if(reo!=NULL)  re=*reo;
else   re.left=re.top=10,re.right=70,re.bottom=30;//GetClientRect(hParent,&re); 

UINT ist=   WS_CHILD|WS_VISIBLE|WS_CLIPSIBLINGS|WS_CLIPCHILDREN
			 //|WS_BORDER//|WS_DISABLED//|LBS_NOSEL
			 //|SS_ENDELLIPSIS 
			 //|SS_WORDELLIPSIS
			 |SS_SIMPLE
			 //|SS_SUNKEN
			 |SS_WHITEFRAME
			 //|SS_WHITERECT
			 //|SS_ICON
			 |SS_NOTIFY //STN_CLICKED
             |SS_CENTER;
if(bIcon) ist|=SS_ICON;
HWND hStatic=CreateWindowExW(WS_EX_TRANSPARENT,L"Static",L"Static",//L"Static",//(LPWSTR)MAKEINTRESOURCEW(IDI_ICON),//
             ist,
			 re.left,re.top,re.right-re.left, re.bottom-re.top,
			 hParent,(HMENU)uID,0,0);

if(bIcon)  {
  HICON hicon=LoadIcon(0,(LPCTSTR)IDI_ICON2);
  SendMessage(hStatic,STM_SETICON,(WPARAM)hicon,0);
  DestroyIcon(hicon);
  }

return hStatic;
}



//��ʾ�ڴ�: Edit�ؼ�;
HWND AddEdit(HWND hParent,UINT uID,RECT* reo){
RECT re;
if(reo!=NULL)  re=*reo;
else   GetClientRect(hParent,&re);
//RICHEDIT.H(51):#define RICHEDIT_CLASSW		L"RichEdit20W"
HWND hEdit=CreateWindowExW(WS_EX_CLIENTEDGE,L"Edit",L"Edit",
             WS_CHILD|WS_VISIBLE|WS_BORDER|WS_VSCROLL|WS_HSCROLL|WS_SIZEBOX
			 |WS_CLIPSIBLINGS|WS_CLIPCHILDREN
			 //|WS_BORDER|WS_DISABLED//|LBS_NOSEL
             //|ES_READONLY
			 |ES_AUTOHSCROLL|ES_AUTOVSCROLL|ES_MULTILINE
			 |ES_WANTRETURN,
			 re.left,re.top,re.right-re.left, re.bottom-re.top,
			 hParent,(HMENU)uID,0,0);
if(hEdit==NULL) MessageBox(NULL,"Creating Edit Control","error",0);  

ShowWindow(hEdit,SW_SHOW);
return hEdit;
}




//[0]��ʾ�ڴ�: �б��ؼ�;
HWND AddList(HWND hParent,UINT uID,RECT*reo){

RECT re;
if(reo!=NULL)  re=*reo;
else   GetClientRect(hParent,&re);

HWND hList=CreateWindowExW(WS_EX_CLIENTEDGE,L"ListBox",L"ListBox", //L"LISTBOX",��Unicode��ʽ�Ǳ�Ҫ��,�Ա���ȷ��ʾUnicode�ַ���;
             WS_CHILD|WS_VISIBLE|WS_VSCROLL//|WS_DLGFRAME   //WS_BORDER
			 //|WS_HSCROLL
			 //|WS_SIZEBOX
			 //|WS_BORDER|WS_DISABLED//|LBS_NOSEL
             |LBS_DISABLENOSCROLL|LBS_HASSTRINGS|LBS_NOTIFY
			 //|LBS_MULTIPLESEL
             //|LBS_NOINTEGRALHEIGHT
			 |LBS_WANTKEYBOARDINPUT,
			 re.left+10,re.top+10,re.right-re.left-20, re.bottom-re.top-20,
			 hParent,(HMENU)uID,NULL,NULL);
return hList;
}

// AddCombo, ����ؼ�: ��Ͽ�ؼ�;
HWND AddCombo(HWND hParent,UINT uID,RECT*reo){
RECT re;
if(reo!=NULL)  re=*reo;
else   GetClientRect(hParent,&re);

HWND hCombo=CreateWindowExW(0,L"ComboBox",L"ComboBox",
             WS_VISIBLE|WS_CHILD //|//CBS_DISABLENOSCROLL//|WS_BORDER//
			 |WS_VSCROLL
			 //|WS_HSCROLL|WS_SIZEBOX
			 |WS_BORDER//|WS_DISABLED//|LBS_NOSEL
             //|CBS_DISABLENOSCROLL
			 //|CBS_HASSTRINGS
			 |CBS_DROPDOWN //|CBS_DROPDOWNLIST
             |CBS_NOINTEGRALHEIGHT
			 //|CBS_AUTOHSCROLL
			 ,
			 //re.left+10,re.top+10,re.right-re.left-20, re.bottom-re.top-20,
			 re.left,re.top,re.right-re.left, re.bottom-re.top,
			 hParent,(HMENU)uID,NULL,NULL);
return hCombo;
}



//Nutton
HWND AddButton(HWND hParent,UINT uID,int bimage,RECT*reo) //0,BS_ICON,...;
{

RECT re;
if(reo!=NULL)  re=*reo;
else {
  GetClientRect(hParent,&re);
  re.left=re.right/2;re.right=re.left+100; re.bottom=40;
  }

UINT istyle=WS_CHILD|WS_VISIBLE//|WS_BORDER//|WS_VSCROLL|WS_HSCROLL//|WS_DLGFRAME   
			 //|WS_SIZEBOX|WS_BORDER
			 //|WS_DISABLED//|LBS_NOSEL
//|BS_PUSHBUTTON
|BS_CENTER
|BS_FLAT
|bimage
|BS_VCENTER;

UINT iex=0;
if(bimage!=0)iex|=WS_EX_TRANSPARENT;

HWND hButton=CreateWindowExW(0,L"Button",L"Button1", //L"LISTBOX",��Unicode��ʽ�Ǳ�Ҫ��,�Ա���ȷ��ʾUnicode�ַ���;
             istyle,
			 re.left,re.top,re.right-re.left, re.bottom-re.top,
			 hParent,(HMENU)uID,NULL,NULL);
//ShowWindow(hButton,SW_SHOW);
return hButton;
}


//����Ĵ�����ά��: [1] WC_TABCONTROLW=L"SysTabControl32"  // Commctrl.h
//[0/] AddTab[]: ����Tab
//����[Unicode]�ؼ�:
HWND AddTab(HINSTANCE hInst,HWND hWnd,UINT iItem,RECT* rp){//=ITEM_LIST //=NULL

RECT re; RECT*p=rp;
if(p==NULL)  {
  p=&re;
  GetClientRect(hWnd,p);
  }

int iX=p->left+20, iY=p->top+20;
int iW=p->right-p->left-2*20,iH=p->bottom-p->top-2*20; iW/=4;iH/=4;

WORD wClass[MAX_PATH]=L"SysTabControl32";//{'L','i','s','t','B','o','x',0};//delete[] wClass;

//����[Unicode]�ؼ�:
DWORD wdStyle= WS_CHILD|WS_VISIBLE|WS_CLIPSIBLINGS //| WS_SIZEBOX
              //|TCS_BOTTOM
              //|TCS_BUTTONS
              |TCS_TABS
              |TCS_MULTILINE|TCS_RIGHTJUSTIFY
              //|TCS_RAGGEDRIGHT
              |TCS_FIXEDWIDTH//|TCS_FORCEICONLEFT|TCS_FORCELABELLEFT
              |TCS_HOTTRACK
              |TCS_FOCUSNEVER //Ok!
              |TCS_MULTISELECT
              //|TCS_SCROLLOPPOSITE
              |TCS_TOOLTIPS
              //|TCS_VERTICAL;
              |TCS_OWNERDRAWFIXED
              ;
HWND hControl=CreateWindowExW(WS_EX_CLIENTEDGE,WC_TABCONTROLW,WC_TABCONTROLW,wdStyle,
    iX,iY,iH,iW,hWnd,(HMENU)iItem,hInst,0L);
if(!hControl)MessageBoxW(NULL,WC_TABCONTROLW,L"error",0);  
//��Ҫ�ĳ�ʼ��  
TCITEMW tie; tie.mask = TCIF_TEXT | TCIF_IMAGE; tie.iImage =-1; tie.cchTextMax=16;
tie.pszText = L"��3��... "; SendMessage(hControl, TCM_INSERTITEMW,0,(LPARAM)&tie); //TabCtrl_InsertItemW(hControl,0, &tie) ; //TAB_WORDS=1  
tie.pszText = L"��4�� "; SendMessage(hControl, TCM_INSERTITEMW,1,(LPARAM)&tie); //TAB_DICTS=2
tie.pszText = L"˫3�� "; SendMessageW(hControl, TCM_INSERTITEMW,2,(LPARAM)&tie); //TAB_DICTS=2
tie.pszText = L"����ʽ"; SendMessageW(hControl, TCM_INSERTITEMW,3,(LPARAM)&tie); //TAB_DICTS=2
//tie.pszText = L"ʱ̬ "; SendMessageW(hControl, TCM_INSERTITEMW,4,(LPARAM)&tie); //TAB_DICTS=2
SendMessage(hControl,TCM_SETCURSEL,0,0);         

//����������: ������ɫ
//DWORD dwr=SetClassLong(hControl,GCL_HBRBACKGROUND,(long)CreateSolidBrush(RGB(0,255,100)));  \


return hControl;
}






//extern void RefreshTips(HWND hdlg);//,int iPlanetName,BOOL bTitle=FALSE



//SaveInput[]: save a combo's text to query history file,and add the text to its list;
//����       : 0---failure, 1---successful;
int SaveInput(HWND hCombo,LPCWSTR szFile)
{
if(!IsWindow(hCombo)) return 0;
WORD* wtext=new WORD[MAX_PATH*2+1];  *wtext=0;
SendMessageW(hCombo,WM_GETTEXT,MAX_PATH*2,(LPARAM)wtext);

//eVacuate(wtext,' ');
if(*wtext==0) return 0;

int isel=SendMessageW(hCombo,CB_FINDSTRINGEXACT,-1,(LPARAM)wtext);
if(isel==CB_ERR) SendMessageW(hCombo,CB_ADDSTRING,0,(LPARAM)wtext);
else return 0;

if(szFile==NULL) return 0;
DWORD dwAttrib=GetFileAttributesW(szFile);
if(dwAttrib==-1 || (dwAttrib&FILE_ATTRIBUTE_DIRECTORY)) return 0;

WORD wr[2]; wr[0]='\r', wr[1]='\n';
int io=_wopen(szFile,_O_BINARY|_O_RDWR,_S_IREAD|_S_IWRITE); if(io==-1) MessageBox(NULL,strerror(errno),"Warning" ,0);
//_O_BINARY|_O_CREAT|_O_RDWR,_S_IREAD | _S_IWRITE);|_O_APPEND
_lseek(io,0L,SEEK_END); 

isel=_write(io, wr,4); if(isel!=4) MessageBox(NULL,strerror(errno),"Warning" ,0);
isel=wcslen(wtext)*2;
_write(io,wtext,isel); if(isel<=0) MessageBox(NULL,strerror(errno),"Warning" ,0);
close(io);  //chsize
//setendoffile
delete[] wtext;
return 1;
}




// [2006��1��2�� 11ʱ17��] 
HWND CreateList(HINSTANCE hInst,HWND hWnd,UINT uID,RECT* rp)  //=NULL  
{
RECT re;
if(rp!=NULL) 
  re=*rp;
else
  GetClientRect(hWnd,&re);

int iMargin=10; //|LBS_MULTIPLESEL
HWND hControl=CreateWindowExW(0L,L"ListBox",L"ListControl",\
  WS_CHILD|WS_VISIBLE|WS_BORDER|WS_VSCROLL
  //|WS_HSCROLL
  //|WS_SIZEBOX|WS_BORDER
  |WS_DISABLED
  |LBS_NOSEL
  |LBS_DISABLENOSCROLL|LBS_HASSTRINGS|LBS_NOTIFY
  |LBS_NOINTEGRALHEIGHT|LBS_WANTKEYBOARDINPUT,
  re.left+iMargin,re.top+iMargin,re.right-re.left-2*iMargin,re.bottom-re.top-2*iMargin,\
  hWnd,(HMENU)uID,hInst,0L);
if(!hControl)MessageBox(NULL,"Error Creating Control!","",0);

return hControl;
}












HWND InitTab(HWND hdlg)
{
BOOL bOk;
     INITCOMMONCONTROLSEX initCrl;
     initCrl.dwSize=sizeof(INITCOMMONCONTROLSEX);
     initCrl.dwICC=ICC_TAB_CLASSES; 
bOk=InitCommonControlsEx(&initCrl);//InitCommonControls();
if(!bOk){MessageBox(NULL,"InitCommonControlsEx","error",0); return NULL;}
//COMMCTRL.H(4656):#define WC_TABCONTROLW   L"SysTabControl32"
HWND hTab=CreateWindowEx( 0L,WC_TABCONTROL,"Tabs",
  WS_CHILD| WS_VISIBLE|WS_CLIPSIBLINGS |TCS_TABS|TCS_BUTTONS,//|TCS_FIXEDWIDTH|TCS_FOCUSNEVER|TCS_RIGHT|TCS_RIGHTJUSTIFY|TCS_SINGLELINE|TCS_OWNERDRAWFIXED
             0,300,115,23,hdlg,(HMENU)NULL,NULL,NULL);//hThisInst
if(!hTab){MessageBox(NULL,"CreateWindowEx","error",0); return NULL;}
     TCITEM tie;     
     tie.mask = TCIF_TEXT | TCIF_IMAGE; 
     tie.iImage = -1; 
     tie.pszText = "��"; 
TabCtrl_InsertItem(hTab,1, &tie) ; //TAB_WORDS=1  
     tie.pszText = "��¼"; 
 		 //TabCtrl_InsertItem(hTab,TAB_DICTS, &tie) ;   //The same:
SendMessage(hTab, TCM_INSERTITEM,2,(LPARAM)&tie); //TAB_DICTS=2
SendMessage(hTab, TCM_SETCURSEL,0,0);     

return hTab;
}


//  [2006��3��18�տؼ���������] 
//����ؼ��������� ...... 
//AddInput[]: ��ComboBox��Text���뵽List��;
//����: �ɹ�����,����TRUE...
BOOL AddInput(HWND hdlg,int iCombo){       
WORD* wText=new WORD[MAX_PATH];wText[0]=0;  //��ȡ�����ַ���

SendDlgItemMessageW(hdlg,iCombo,WM_GETTEXT,MAX_PATH,(LPARAM)wText); 

//<���������ַ���  //WORD*wTmp=(WORD*)malloc(MAX_PATH);wTmp[0]=0;
BOOL bOk=FALSE; //if(ic!=CB_ERR) bExist=TRUE;
int ic=SendDlgItemMessageW(hdlg,iCombo,CB_FINDSTRINGEXACT,-1,(LPARAM)wText); 
if(ic==CB_ERR)     //����¼IDC_COMBO1�еĴ���
  {
  ic=0;//SendDlgItemMessageW(hdlg,IDC_LIST1,LB_FINDSTRINGEXACT,-1,(LPARAM)wText);
  if(ic==LB_ERR)   //����¼IDC_LIST1�еĴ���   
    {//eVacuate(wText,' ');
    if(*wText!=0)  //����¼�մ���  
      {
      bOk=TRUE;
      SendDlgItemMessageW(hdlg,iCombo,CB_INSERTSTRING,0,(LPARAM)wText);                          
      }
    }  
  }
//���������ַ���>  //free(wTmp);
delete[] wText;               
return bOk;
}


/*//[2]װ�������ַ����б���ListBox/ComboBox
//  [2006��3��17��]  
//  LoadList[]: ��LoadListEx[]һ�������͹���, ��Ϊ�˷���ʹ��, �ر���LoadList[];
//  wItem!=0[,0-->'\r'], ���wNote=0, �����[ע����Ϣ]�ֶεķֻ�: q=wcschr(p,wNote)ָ��p��β��,*q=0��Ӱ��p.
//  ����[����ע����Ϣ]���͵�iItemList, ���wNote!=0, ������ʹ���;
//  ����: ������.
//  �����ص�: �ȶ�����������,Ȼ��wItem�ֻ�����, �ٶȿ�, ��ռ���ڴ��
int LoadParagraph(LPCWSTR szFileName,HWND hdlg,int iItemList,
      WORD wItem,WORD wNote,int iType)//,BOOL bItemOnly=IDC_LIST1//=WITEM,=WNOTE,=ITEM_LIST,=FALSE
{
if(iItemList==-1) return 0;

WORD* szFile=new WORD[MAX_PATH];*szFile=0;
if(szFileName==NULL)
  GetFileName(szFile,FALSE);
else swprintf(szFile,szFileName);

WORD* wText=readfileW(szFile); // Read File.


////Send To List.
int ADDSTRING=LB_ADDSTRING,FINDSTRING=LB_FINDSTRING,ERR=LB_ERR;
if(iType==ITEM_COMBO){ADDSTRING=CB_ADDSTRING; FINDSTRING=CB_FINDSTRING; ERR=CB_ERR;}

if(wItem==0) wItem='\r';
WORD*p=wText; p++;//����UNICODEFLAG 
WORD*po,*q;
int iloop=0,ic=0,isel=-1;
while(p) 
  {
  po=wcschr(p,wItem);
  if(po) *po=0; 

  q=wcschr(p,wNote);
  if(q) *q=0;   

  isel=SendDlgItemMessageW(hdlg,iItemList,FINDSTRING,-1,(LPARAM)p);
  if(isel==ERR) 
    {//�����ż�ָ����Ĳ����ַ�
    //if(wItem=='\r') eVacuate(p,'\n'); if(wItem=='\n') eVacuate(p,'\r'); 
    if(*p!=0){SendDlgItemMessageW(hdlg,iItemList,ADDSTRING,0,(LPARAM)p); ic++;}
    }
  
  if(q) *q=wNote;
 
  if(po) *po=wItem;
  
  //Another Loop ......
  p=po; if(p) p++;
  iloop++;  if(iloop>10000) break;
  }

free(wText);
return ic;//iCell;//wFirst
}

//[2]װ�������ַ����б���ListBox/ComboBox
////////////////////  [2006��3��17��] ////////////////////
//  LoadParagraphs[]: ���ζ��ļ���iListID�ؼ�;
//  ����: ����;
//  �����ص�: �ȶ�����������,Ȼ��'\r'�ֻ�����, �ٶȿ�, ��ռ���ڴ��.
int LoadParagraphs(LPCWSTR szFileName,HWND hdlg,int iListID,int iType)//=ITEM_LIST
{
if(iListID==-1) return 0;
////Prepare.
WORD* szFile=new WORD[MAX_PATH];*szFile=0;
if(szFileName==NULL)
  GetFileName(szFile,FALSE);
else swprintf(szFile,szFileName);

////Read File.
WORD* wText=readfileW(szFile); 
if(wText==NULL) return 0;   
int ADDSTRING=LB_ADDSTRING,FINDSTRING=LB_FINDSTRING,ERR=LB_ERR;  //Send To List.

if(iType==ITEM_COMBO){ADDSTRING=CB_ADDSTRING; FINDSTRING=CB_FINDSTRING; ERR=CB_ERR;}

WORD*p=wText; p++;//����UNICODEFLAG 
WORD*po,*q;
int iloop=0,ic=0,isel=-1;
while(p) 
  {
  po=wcschr(p,'\r');
  if(po) *po=0; 
  isel=SendDlgItemMessageW(hdlg,iListID,FINDSTRING,-1,(LPARAM)p);
  if(isel==ERR) 
    {//�����ż�ָ����Ĳ����ַ�
    eVacuate(p,'\n'); 
    if(*p!=0){SendDlgItemMessageW(hdlg,iListID,ADDSTRING,0,(LPARAM)p); ic++;}
    } 
  if(po) *po='\r';
  
  //Another Loop ......
  p=po; if(p) p++;
  iloop++;  if(iloop>10000) break;
  }

free(wText);
return ic;//iCell;//wFirst
}
*/


//[4]װ�������ַ����б���Edit
// [2006-9-1 21:23:55] 
//  LoadEdit: ���ζ��ļ���iTreeID�ؼ�;
//  ����    : ���ڵ���;
//  �����ص�: �ȶ����ļ���һ��/������[L"\r\n"],Ȼ����, �ٶȿ�, ռ���ڴ���;
//            ��һ���ַ�Ϊ'\''��skip��־;
//#define UNICODEFLAG 0xFEFF   // pCaret[0]=0x2506;

int LoadEdit(LPCWSTR szFileName,HWND hEdit) {
if(hEdit==NULL) return 0;
if(!IsWindow(hEdit)) return 0;

WORD* szFile=new WORD[MAX_PATH];*szFile=0;
if(szFileName==NULL)
  GetFileName(szFile,FALSE);
else swprintf(szFile,szFileName);

int io=_wopen(szFile,_O_BINARY|_O_RDONLY,_S_IREAD);  // Open file;

if(io==-1) {MessageBox(NULL,strerror(errno),"_wopen",0);delete[] szFile; return 0;}

WORD ws; 
read(io,&ws,2);
if(ws!=UNICODEFLAG) 
   {
   MessageBox(NULL,"This Text File Is Not Unicode. You Can Save It As Unicode Text,And Try Agin!","Abort",0);
   close(io);delete[] szFile; return 0;
   }

////Read File;

//���ԭ������...;
int index=0;
//�����ַ�����hEdit;
WORD*p=wcsrchr(szFile,'\\'); if(p) p++; else p=szFile;
SendMessageW(hEdit,WM_SETTEXT,0,(LPARAM)p);

WORD* wText=new WORD[MAX_PATH]; * wText=0;
long iSize=filelength(io);
long iloop=0,ip=0;

//int iRank=0;//0-root,1-parallel,2-sibling;


while(!_eof(io)) 
  {
  read(io,&ws,2);
  switch(ws)
    {
    case '\r':
	break;
    case '\n': //�����Ѷ��ַ���,���㿪ʼ��һ��/��;
	  {
	  if(*wText==0){ip=0; break;}
	  if(*wText=='\''){*wText=0;ip=0; break;}

	  switch(*wText)
	    {
		case '[':
		case '>':
		case '<':
		break;
		default: break;		
		}
      wcscat(wText,L"\r\n");
      SendMessageW(hEdit,EM_REPLACESEL,0,(LPARAM)wText);
	  *wText=0; ip=0;
	  }
	break;
	default:
      wText[ip++]=ws; wText[ip]=0; if(ip>MAX_PATH-3) break;
	break;	
	}
  }//while(!_eof(io)) 

delete[] wText;
close(io);
return index;//iCell;//wFirst
}




//[4]װ�������ַ����б���ListBox,ComboBox,EditBox or RichEdit;
//////////////////// 2007��5��12�� ////////////////////
//  LoadList: ���ζ��ļ���hList�ؼ�;
//  ����    : ����,ʧ�ܷ���-1;
//  �����ص�: �ȶ����ļ���һ��/������[L"\r\n"],Ȼ����, �ٶȿ�, ռ���ڴ���;
//  #define UNICODEFLAG 0xFEFF   ////pCaret[0]=0x2506;
//  iCombo=0,List, 1,Combo, 2, Edit, 3, RichEdit;
int LoadList(LPCWSTR szFileName,HWND hList,int iCombo)//=0;
{
//Prepare.
if(hList==NULL) return 0;
if(!IsWindow(hList)) return 0;

WORD* szFile=new WORD[MAX_PATH];*szFile=0;
if(szFileName==NULL)
  GetFileName(szFile,FALSE);
else wcscpy(szFile,szFileName);

 //���ļ�ʱ����0xFEFF!
WORD*p=szFile; //if(*p==0xFEFF) p++;

int io=_wopen(p,_O_BINARY|_O_RDONLY,_S_IREAD); //strerror(errno)

if(io==-1) {MessageBoxW(NULL,p,L"_wopen: error",0);delete[] szFile; return -1;}

WORD ws; 
read(io,&ws,2); lseek(io,0,SEEK_SET);

int ib=2;
if(ws!=UNICODEFLAG) 
   {
   ib=1;
   //MessageBox(NULL,"This file will be Loaded as Ansi text file!","Warn",0);
   //close(io);delete[] szFile; return -1;
   }
//else MessageBox(NULL,"This file will be Loaded as Unicode text file!","Warn",0);


//���ԭ������...;

//�����ַ�����hList;
UINT uMsg=LB_ADDSTRING;
if(iCombo==1) uMsg=CB_ADDSTRING;
else if(iCombo>=2) uMsg=EM_REPLACESEL;
//WORD*p=wcsrchr(szFile,'\\'); if(p) p++; else p=szFile; SendMessageW(hList,uMsg,0,(LPARAM)p);
p=new WORD[10240]; * p=0; char*q=(char*)p;
long iSize=filelength(io);  
long iloop=0,ip=0;

////Read File;
int index=0;
while(!_eof(io)) 
  {
  if(ib==1)
    {
	readline(io,p);

    SendMessage(hList,uMsg,0,(LPARAM)q); index++;
    if(uMsg==EM_REPLACESEL) SendMessage(hList,uMsg,0,(LPARAM)"\r\n");    
	}
  else
    {
	*p=0;
	readline(io,p); 
	SendMessageW(hList,uMsg,0,(LPARAM)p); index++; //MessageBoxW(NULL,p,NULL,0);
    if(uMsg==EM_REPLACESEL) SendMessageW(hList,uMsg,0,(LPARAM)L"\r\n");      
	} 
  }


/*
ws=0;
while(!_eof(io)) 
  {
  read(io,&ws,ib); 
  if(ws=='\r' || ws=='\n')
    {
	if(ib==1)
      {
      if(*q==0){ip=0; break;} //if(*q=='\''){*q=0;ip=0; break;}
	  SendMessage(hList,uMsg,0,(LPARAM)q); index++;
      if(uMsg==EM_REPLACESEL) SendMessage(hList,uMsg,0,(LPARAM)"\r\n");//}      
      }
    else
      {
      if(*p==0){ip=0; break;} //if(*p=='\''){*p=0;ip=0; break;}
	  SendMessageW(hList,uMsg,0,(LPARAM)p); index++;
      if(uMsg==EM_REPLACESEL) SendMessageW(hList,uMsg,0,(LPARAM)L"\r\n");//}       
      }     
    *p=0,*q=0, ip=0;
    }
  else
    {
    if(ip<10240-4)
      {
      if(ib==1) q[ip++]=ws,q[ip]=0;
      else  p[ip++]=ws,p[ip]=0;
      }    
    }//else;  
  }//while(!_eof(io)) 

//���һ������,before EOF;
if(ib==2)
{
SendMessageW(hList,uMsg,0,(LPARAM)p); index++;
if(uMsg==EM_REPLACESEL) SendMessageW(hList,uMsg,0,(LPARAM)L"\r\n"); 
}
else
{
SendMessage(hList,uMsg,0,(LPARAM)q); index++;
if(uMsg==EM_REPLACESEL) SendMessage(hList,uMsg,0,(LPARAM)"\r\n"); 
}
*/

close(io);
delete[] p;
return index;//iCell;//wFirst
}


////////////////////  [2006��3��16�� �Ի����ù���,list���ݴ�ȡ] ////////////////////// 
//[1]����ListBox/ComboBox�������ַ����б�;
//  SaveList[]: ��ListBox/ComboBox�����Unicode�ı��ļ�;
//  ������һ��WORD,��Ϊ������WUNICODETEXTFLAG;
//  �����˵�����wDelimit�ָ�;  //Deleted Function: SaveInputs[]: "\r\n".
//  ����:  �������Ŀ����;
//iType=0,List, 1,Combo; // 2, Edit;
////////////////////  [2006��3��18�� 12ʱ55��] ////////////////////

inline int savelistW(int io,HWND hList,int itype)//,bool bAppend=false=0,ListBox; =1,ComboBox;
{
int GETCOUNT=LB_GETCOUNT,GETTEXT=LB_GETTEXT,FINDSTRING=LB_FINDSTRING,ERR=LB_ERR;
if(itype==1) {GETCOUNT=CB_GETCOUNT;GETTEXT=CB_GETLBTEXT; FINDSTRING=CB_FINDSTRING; ERR=CB_ERR;}

int ic=SendMessage(hList,GETCOUNT,0,0); //1-based count of items.
if(ic==ERR|| ic<=0) {return 0;}  

WORD* ws=new WORD[MAX_PATH];
lseek(io,0,SEEK_SET);
*ws=0xFEFF;  write(io,ws,2);  

//if(bAppend) 
//lseek(io,0,SEEK_END);

int ir=0,iL=0; int ib=0, ie=0; int isave=0;
for(int i=0;i<ic;i++)
  {
  *ws=0;
  SendMessageW(hList,GETTEXT,i,(LPARAM)ws);
  ib=0, ie=wcslen(ws);
  wcscat(ws,L"\r\n");
  iL=ie+2;
  if(ie>0) 
    {
	//write(io,ws,2*iL); 
	
	isave=SaveNew(io,-1,(LPVOID)ws,wcslen(ws)*2);

	//*ws='\r',*(ws+1)='\n';
	//write(io,ws,4); 
    if(isave>0) ir++; //if(ir==19) ir=0;
    }
  }

delete[] ws;
return ir;
}

inline int savelistA(int io,HWND hList,int itype) //,bool bAppend=false=0,ListBox; =1,ComboBox;
{
int GETCOUNT=LB_GETCOUNT,GETTEXT=LB_GETTEXT,FINDSTRING=LB_FINDSTRING,ERR=LB_ERR;
if(itype==1) {GETCOUNT=CB_GETCOUNT;GETTEXT=CB_GETLBTEXT; FINDSTRING=CB_FINDSTRING; ERR=CB_ERR;}

int ic=SendMessage(hList,GETCOUNT,0,0); //1-based count of items.
if(ic==ERR|| ic<=0) {MessageBox(NULL,"GETCOUNT","error",0);  return 0;}

char* ws=new char[MAX_PATH];
//lseek(io,0,SEEK_SET); //*ws=0xFEFF;  write(io,ws,2);  

//if(bAppend) 
lseek(io,0,SEEK_END);

int ir=0,iL=0; int ib=0,ie=0; int isave=0;
for(int i=0;i<ic;i++)
  {
  *ws=0;
  SendMessage(hList,GETTEXT,i,(LPARAM)ws);
  ib=0,ie=strlen(ws);
  
  strcat(ws,"\r\n");

  iL=ie+2;
  if(ie>0) 
    {
	
	isave=SaveNew(io,-1,(LPVOID)ws,ie*2);

	//write(io,ws,iL);  //�洢����;  
	//*ws='\r',*(ws+1)='\n'; //׼���ָ�����;
	//write(io,ws,2); 
    if(isave>0) ir++; //if(ir==19) ir=0;
    }
  }

delete[] ws;
return ir;
}



int SaveList(LPCWSTR szName,HWND hItem,int iType)//,WORD*wDelimit//=ITEM_LIST //For ComboBox And ListBox!
{
//׼��Ҫ�洢�Ķ���
//HWND hItem=GetDlgItem(hdlg,iItem);if(hItem==NULL) return 0;

int GETCOUNT=LB_GETCOUNT,GETTEXT=LB_GETTEXT,FINDSTRING=LB_FINDSTRING,ERR=LB_ERR;
if(iType==1) {GETCOUNT=CB_GETCOUNT;GETTEXT=CB_GETLBTEXT; FINDSTRING=CB_FINDSTRING; ERR=CB_ERR;}

int ic=SendMessage(hItem,GETCOUNT,0,0); //1-based count of items.
if(ic==ERR|| ic<0) {MessageBox(NULL,"GETCOUNT","error",0);   return 0;}

//׼��Ҫ�洢���ļ���
int io=_wopen(szName,_O_BINARY|_O_CREAT|_O_RDWR,S_IREAD|S_IWRITE); //GetFileID(szName); //���Ҫ�洢���ļ�����Unicode�ı�,�򷢳����档 
if(io<=0){MessageBox(NULL,"�ļ���ʧ��.","����",MB_YESNO);return 0;}

WORD w=0; 
int isize=filelength(io); //�½��ļ�����Unicode�ı���ʽ;
if(isize==0) {w=0xFEFF; write(io,&w,2);lseek(io,0,SEEK_SET);}

int ir=0;
read(io,&w,2);
if(w!=UNICODEFLAG)
  {
  //int iR=MessageBox(NULL,"�����ļ�����Unicode�ı�,�Ƿ����?","����",MB_YESNO);//if(iR==IDNO){close(io);return 0;}   
  ir=savelistA(io,hItem,iType);//,bAppend
  }
else ir=savelistW(io,hItem,iType);//,bAppend

close(io); //RunNotePad(szName);
return ir;
}









//return: -1, error; 0,text exists; 1,add successful;
int  AddText(HWND hCombo) 
{
if(!IsWindow(hCombo)) return -1;

WORD *ws=new WORD[MAX_PATH]; *ws=0;
SendMessageW(hCombo,WM_GETTEXT,MAX_PATH,(LPARAM)ws);
int isel=SendMessageW(hCombo,CB_FINDSTRING,-1,(LPARAM)ws);
if(isel!=CB_ERR) return 0;
SendMessageW(hCombo,CB_ADDSTRING,0,(LPARAM)ws);
return 1;
}












//[4]װ�������ַ����б���ComboBox;
//LoadCombo[]: ���ζ��ļ���hHiden�б�;
//  ����'\\'��ͷ�����ַ������͵�ComboBox--hList�б�;
//  ����    : ����,ʧ�ܷ���-1;
//  �����ص�: �ȶ����ļ���һ��/������[L"\r\n"],Ȼ����, �ٶȿ�, ռ���ڴ���;
//            ��һ���ַ�Ϊ'\''��skip��־;
//#define UNICODEFLAG 0xFEFF   ////pCaret[0]=0x2506;

int LoadCombo(LPCWSTR szFileName,HWND hList,HWND hHiden)
{
////Prepare.
if(hList==NULL) return 0;
if(!IsWindow(hList)) return 0;

WORD* szFile=new WORD[MAX_PATH];*szFile=0;
if(szFileName==NULL)
  GetFileName(szFile,FALSE);
else swprintf(szFile,szFileName);

////Open file;
int io=_wopen(szFile,_O_BINARY|_O_RDONLY,_S_IREAD);
if(io==-1) {delete[] szFile; return -1;}//MessageBox(NULL,strerror(errno),"_wopen",0);

WORD ws; 
read(io,&ws,2);
if(ws!=UNICODEFLAG) 
   {
   MessageBox(NULL,"This Text File Is Not Unicode. You Can Save It As Unicode Text,And Try Agin!","Abort",0);
   close(io);delete[] szFile; return -1;
   }



//���ԭ������...;
int index=0;
//�����ַ�����hList;
UINT uMsg=LB_ADDSTRING;
//if(iCombo==1) uMsg=CB_ADDSTRING;else if(iCombo==2) uMsg=EM_REPLACESEL;

//WORD*p=wcsrchr(szFile,'\\'); if(p) p++; else p=szFile;   
//SendMessageW(hList,uMsg,0,(LPARAM)p);

WORD* wText=new WORD[MAX_PATH*5]; * wText=0;
long iSize=filelength(io);  
long iloop=0,ip=0;

//int iRank=0;//0-root,1-parallel,2-sibling;
WORD*p=NULL;
while(!_eof(io)){
  read(io,&ws,2);
  switch(ws)
    {
    case '\r':
	break;
    case '\n': //�����Ѷ��ַ���,���㿪ʼ��һ��/��;
	  {
	  if(*wText==0){ip=0; break;}
	  if(*wText=='\''){*wText=0;ip=0; break;}

      //wcscat(wText,L"\r\n");
      //if(*wText!=0x20){
	    SendMessageW(hHiden,uMsg,0,(LPARAM)wText); index++;
		p=wcsrchr(wText,'\\'); if(!p) p=wText; else p++;
	    SendMessageW(hList,CB_ADDSTRING,0,(LPARAM)p); //index++;
      *wText=0; ip=0;
	  }
	break;
	default:
      wText[ip++]=ws; wText[ip]=0; if(ip>3*MAX_PATH-4) break;
	break;	
	}
  };//while(!_eof(io));

SendMessageW(hHiden,uMsg,0,(LPARAM)wText); index++;
p=wcsrchr(wText,'\\'); if(!p) p=wText; else p++;
SendMessageW(hList,CB_ADDSTRING,0,(LPARAM)p); //index++;

close(io);
delete[] wText;
return index;//iCell;//wFirst
}





//return: line count, or -1 when fail;
inline int SaveEdit(LPCWSTR szFile,HWND hEdit)
{
HANDLE io=CreateFileW(szFile,GENERIC_READ|GENERIC_WRITE,FILE_SHARE_READ|FILE_SHARE_WRITE,
                      NULL,OPEN_ALWAYS,FILE_ATTRIBUTE_NORMAL,NULL); // SD    
if(io==NULL) {MessageBox(NULL,"CreateFileW","error",0); return -1;}//{MessageBox(NULL,strerror(errno),"_wfopen",0);return -1;}
int ic=SendMessage(hEdit,EM_GETLINECOUNT,0,0);

WORD* szText=new WORD[MAX_PATH*ic]; *szText=0; int icw=0;
WORD wr; DWORD dwr;
wr=UNICODEFLAG; WriteFile(io,&wr,2,&dwr,NULL);


/*for(int i=0;i<ic;i++)
  {
  icw=SendMessageW(hEdit,EM_GETLINE,i,(LPARAM)szText);  
  icw=wcslen(szText)*2;
  WriteFile(io,szText,icw,&dwr,NULL);*szText=0;
  }*/

SendMessageW(hEdit,WM_GETTEXT,MAX_PATH*ic,(LPARAM)szText);//szText[100]=0;

icw=wcslen(szText)*2; 
icw=WriteFile(io,szText,icw,&dwr,NULL);
if(icw==0) MessageBox(NULL,"EM_GETLINE","error",0); 
CloseHandle(io);

delete[] szText;
return ic;
}


/*
////////////////////  [2006��3��17��] ////////////////////
//  LoadListEx[]: �ò�ͬ��ʽ���شǵ�, ����=loaddict //����һ�������͹���
//  ������: WNOTE,='\n'.��������ָ��.����,='\n'ʱ�������ı��п��ܻ����WRETURN,��'\r',��eVacuate[]���֮.
//            wItem!=0[,0-->'\r']; ���wNote=0, �����[ע����Ϣ]�ֶεķֻ�: q=wcschr(p,wNote)ָ��p��β��,*q=0��Ӱ��p.
//  �������͵�iItemList, ���iNoteList����,[��������]ע����Ϣ���͵�iNoteList.
//  bNoteOnly=TRUE, �������ע����Ϣ��iNoteList.
//  ����: ������.
//  ���ļ�����ΪLPVOID����,����Ҳ����.
//  �����ص�: �ȶ�����������,Ȼ��wItem,wNote�ֻ�����, �ٶȿ�, ��ռ���ڴ��
int LoadListEx(LPCWSTR szFileName,HWND hdlg,int iItemList,
      int iNoteList,WORD wItem,WORD wNote,int iType,BOOL bNoteOnly)//=IDC_LIST1//=WITEM,=WNOTE,=ITEM_LIST,=FALSE
{
////Prepare.
WORD* szFile=new WORD[MAX_PATH];*szFile=0;
if(szFileName==NULL)
  GetFileName(szFile,FALSE);
else swprintf(szFile,szFileName);
//if(strlen(szFile)==0){MessageBox(NULL,"Invalid File Name!","ReadRecord",0);return -1;}
//int iType=GetFileExtension(szFile);\
if(iType!=FILE_EXTENSION_WRZ && iType!=FILE_EXTENSION_TEXT)return -1;

////Read File.
WORD* wText=readfileW(szFile);  //return 0;
if(wText==NULL) return 0;
// Send To Lists Accordingly. //GetDlgItem
int ADDSTRING=LB_ADDSTRING,FINDSTRING=LB_FINDSTRING,ERR=LB_ERR,INITSTORAGE=LB_INITSTORAGE,ERRSPACE=LB_ERRSPACE;//

if(iType==ITEM_COMBO)
  {ADDSTRING=CB_ADDSTRING; FINDSTRING=CB_FINDSTRING; ERR=CB_ERR;INITSTORAGE=CB_INITSTORAGE;ERRSPACE=CB_ERRSPACE;}

int isel=SendDlgItemMessage(hdlg,iItemList,INITSTORAGE,50000,50*50000); 

isel=SendDlgItemMessage(hdlg,iNoteList,INITSTORAGE,50000,50*50000); 


if(wItem==0) wItem='\r';
WORD*p=wText; p++;//����UNICODEFLAG //wcschr(wText,wItem); 
WORD*po,*q;
int iloop=0,ic=0;
while(p) 
  {
  po=wcschr(p,wItem);
  if(po) *po=0; 

  if(!bNoteOnly && iNoteList!=-1) 
    {
    isel=SendDlgItemMessageW(hdlg,iNoteList,FINDSTRING,-1,(LPARAM)p);
    if(isel==ERR) SendDlgItemMessageW(hdlg,iNoteList,ADDSTRING,0,(LPARAM)p);  
    }

  q=wcschr(p,wNote);
  if(q) 
    {
    *q=0; 
    if(bNoteOnly && iNoteList!=-1) 
      if(wNote!=0)
        if(*(q+1)!=0)
          {
          isel=SendDlgItemMessageW(hdlg,iNoteList,FINDSTRING,-1,(LPARAM)(q+1));
          if(isel==ERR) SendDlgItemMessageW(hdlg,iNoteList,ADDSTRING,0,(LPARAM)(q+1));  
          }      
    }
  
  if(iItemList!=-1)
    {
    isel=SendDlgItemMessageW(hdlg,iItemList,FINDSTRING,-1,(LPARAM)p);
    if(isel==ERR)
      {//�����ż�ָ����Ĳ����ַ�
      //if(wItem=='\r') eVacuate(p,'\n'); if(wItem=='\n') eVacuate(p,'\r'); 
      //if(*p!=0xfeff) //?
      SendDlgItemMessageW(hdlg,iItemList,ADDSTRING,0,(LPARAM)p);ic++;
      }
    }
  
  if(q) *q=wNote;
 
  if(po) *po=wItem;
  
  if(ic>5000) break; //���Ԥװ��5000��

  //Another Loop ......
  p=po; if(p) p++;
  iloop++;  if(iloop>10000 ) break;
  }

free(wText);
return ic;//iCell;//wFirst
}
*/
// [2006��3��17��] 
//  LoadHugeList[]: �ÿ��ٷ�ʽ���شǵ�, ����=LoadListEx[],�����ط�ʽ��ͬ;
//  ������: WNOTE,='\r'.��������ָ��.����,�������ı��п��ܻ����WNEWLINE,��'\n',��eVacuate[]���֮.
//            wItem!=0[,0-->'\r']; ���wNote=0, �����[ע����Ϣ]�ֶεķֻ�: q=wcschr(p,wNote)ָ��p��β��,*q=0��Ӱ��p.
//  �������͵�iItemList, ���iNoteList����,[��������]ע����Ϣ���͵�iNoteList.
//  bNoteOnly=TRUE, �������ע����Ϣ��iNoteList.
//  ����: ������.
//  �����ص�: �߶�����,�߰�wItem,wNote�ֻ�����, �ٶȿ�, ռ���ڴ���;
//  ˵��: ���װ��5000��.          
int LoadHugeList(LPCWSTR szFileName,HWND hdlg,int iItemList,
      int iNoteList,WORD wItem,WORD wNote,int iType,BOOL bNoteOnly)//=IDC_LIST1//=WITEM,=WNOTE,=ITEM_LIST,=FALSE
{
int hF=_wopen(szFileName,_O_BINARY|_O_RDONLY,_S_IREAD);
if(hF==-1) {return 0;} 
WORD ws; 
read(hF,&ws,2);
if(ws!=UNICODEFLAG) 
   {
   MessageBox(NULL,"This Text File Is Not Unicode. You Can Save It As Unicode Text,And Try Agin!","Abort",0);
   close(hF); return 0;
   }

int ADDSTRING=LB_ADDSTRING,FINDSTRING=LB_FINDSTRING,ERR=LB_ERR,INITSTORAGE=LB_INITSTORAGE,ERRSPACE=LB_ERRSPACE;//
if(iType==ITEM_COMBO)
  {ADDSTRING=CB_ADDSTRING; FINDSTRING=CB_FINDSTRING; ERR=CB_ERR;INITSTORAGE=CB_INITSTORAGE;ERRSPACE=CB_ERRSPACE;}

int isel=SendDlgItemMessage(hdlg,iItemList,INITSTORAGE,50000,50*50000);  
if(isel==ERRSPACE) MessageBox(NULL,"INITSTORAGE","error",0);  
isel=SendDlgItemMessage(hdlg,iNoteList,INITSTORAGE,50000,50*50000);  
//if(isel==ERRSPACE) eInfo("INITSTORAGE",NULL);

// Read File/Send To Lists Accordingly. //GetDlgItem
if(wItem==0) wItem='\r';
WORD wPartner=0;
if(wItem=='\r') wPartner='\n';

WORD*wText=new WORD[MAX_PATH]; *wText; int ip=0;
long iSize=filelength(hF);
long iloop=0,ic=0;

BOOL bNoted=FALSE;

while(!_eof(hF)) 
  {
  read(hF,&ws,2);
  if(ws==wNote)
    {
    if(!bNoted)
      {ic++; bNoted=TRUE; 
      SendDlgItemMessageW(hdlg,iItemList,ADDSTRING,0,(LPARAM)wText);
      }

    wText[ip]=0x20; wText[++ip]=0; //Ϊע�����ݶ�����һ���ո�.//���Ҳ����������ע�ͱ��          
    }
  else if(ws==wItem)
    {
    SendDlgItemMessageW(hdlg,iNoteList,ADDSTRING,0,(LPARAM)wText);  
    *wText=0; ip=0; bNoted=FALSE;   
    }
  else if(ws!=wPartner)
    {    
    wText[ip]=ws; wText[++ip]=0;
    }

  if(ic>5000) break; //���Ԥװ��5000��
  //Another Loop ......
  iloop++;  if(iloop>iSize/2) break;
  }//while(!_eof(hF)) 

delete[] wText;
close(hF);
return ic;//iCell;//wFirst
}





// [2005��10��5�� 9ʱ29��]  
//  openlist[]: ��Unicode�ı��ļ�װ�ص�ListBox/ComboBox.
//  openlist[]=loadinputs[],ֻ�ǻ��Ʋ�ͬ.
//  ����һ��WORD,��Ϊ������WUNICODETEXTFLAG.
//  �����˵���ָ���wDelimit.  
//  [2005��10��5�� 9ʱ29��]  
int openlist(LPCWSTR szName,HWND hdlg,int iItem,WORD*wDelimit,int iItemType,BOOL bAppend)//=ICDITEM_COMBO  //For ComboBox And ListBox!
{
//׼��Ҫװ�صĶ���
HWND hItem=GetDlgItem(hdlg,iItem);
if(hItem==NULL) return -1;

//׼��Ҫװ�ص��ļ���
int hf=GetFileID(szName);  if(hf<=0) return -1;
//���Ҫװ�ص��ļ�����Unicode�ļ�,�򷢳����档
WORD ws=0; int ic=0; //UNICODEFLAG
read(hf,&ws,2);
if(ws!=UNICODEFLAG)
  {
  ic=MessageBox(hdlg,"����Unicode�ļ�,�Ƿ����?","����",MB_YESNO);
  if(ic==IDNO)
    {
    close(hf);
    return -1;                                     
    }
  else lseek(hf,0,SEEK_SET);//����Unicode�ļ�,�����һ��WORD
  }
ic=0;


//׼���ָ����š�
WORD*wItems=new WORD[MAX_PATH];*wItems=0;
if(wDelimit==NULL) wsprintfW(wItems,L"\r\n");
else  wsprintfW(wItems,wDelimit);
int id=wcslen(wItems);

//װ�����ݡ�//����loaddict[]�еĻ��� 
UINT uMsg=CB_RESETCONTENT;  if(iItemType==ITEM_LIST) uMsg=LB_RESETCONTENT;
if(!bAppend) SendMessage(hItem,uMsg,0,0);  

uMsg=CB_ADDSTRING;  if(iItemType==ITEM_LIST) uMsg=LB_ADDSTRING;

WORD*p=NULL;
WORD* wText=new WORD[MAX_PATH*10+1]; int ir=0;
long iloop=0;int iOk=0;//ѭ������.
WORD*wMatch=new WORD[id+1];*wMatch=0; int ip=0;
while(!eof(hf)) //(iCell<=iC)//2//MAXLOOP���Ʋ�����������//WINUSER.H(330):#define VK_RETURN 0x0D
  {  
  ws=0; 
  iOk=read(hf,&ws,2);if(iOk<=0) {break;} 
  if(ir<MAX_PATH*10){wText[ir]=ws;ir++;wText[ir]=0;}
  p=wcschr(wItems,ws);
  if(p) 
  if(ip<id)
    {wMatch[ip]=ws;ip++;wMatch[ip]=0;}
  if(ip==id)
    {
    p=wcsstr(wItems,wMatch);
    if(p)
      { 
      SendMessageW(hItem,uMsg,0,(LPARAM)wText); ic++;
      *wMatch=0;ip=0;
      *wText=0;ir=0;
      }        
    } 

  iloop++;  
  if(iloop>10000) break;
  }

if(ir>0)//���һ������,��Ϊǰ�涼�ǵ�������һ������ʱ�ŷ����ı�,�����һ���������治������һ������.
  {
  SendMessageW(hItem,uMsg,0,(LPARAM)wText); ic++;
  }

//�˳�.
delete[] wItems;
delete[] wMatch;
delete[] wText;
close(hf);

//RunNotePad(szName);
return ic;
}







//  [2006��3��18��WndProc Interceptions]  
//InterceptDlg[]: Intercept Dialog's Window Procedure.
//˵��: ��Ԥ�����س���.
//  [2006��3��19�մ���VK_RETURN��---WM_COMMAND::IDOK] 
//WNDPROC OldDlgProc;
LRESULT APIENTRY InterceptDlg(HWND hwnd,UINT uMsg,WPARAM wParam,LPARAM lParam)  
{
int wmId, wmEvent;   
switch(uMsg)
  {
  //case WM_LBUTTONDOWN:break; 
  //case WM_KEYDOWN:break; // No Effect!
  case DM_GETDEFID: 
  break;
  case WM_COMMAND:
    wmId=LOWORD(wParam); wmEvent=HIWORD(wParam);
    switch(wmId)
      {
      case IDOK: //Combo�е�VK_RETURNҲ��IDOK!
        //RefreshTips(hwnd);
      break;
      case IDCANCEL:
        {                
        }
      break;
      default:break;// switch(wmId)
      }
  break;
  default:break;//switch(uMsg)
  }
return CallWindowProc(OldDlgProc,hwnd,uMsg, wParam, lParam); // not reached!
} 

//Intercept ComboBox's Window Procedure.
//˵��: �ص�Ԥ����VK_RETURN��.
//  [2006��3��19�մ���VK_RETURN��] 
//WNDPROC OldComboProc; //SetClassLong[] //NotePadW.dsw
LRESULT APIENTRY InterceptCombo(HWND hwnd,UINT uMsg,WPARAM wParam,LPARAM lParam)  
{//return CallWindowProc(OldComboProc,hwnd,uMsg, wParam, lParam); // not reached!
//int wmId, wmEvent;  
switch(uMsg)
  {
  case WM_LBUTTONDOWN: //Ok!
  break;
  case WM_KEYDOWN:
    switch(wParam)
      {
      case VK_RETURN:  //Combo�е�VK_RETURN��Dlg�е�IDOK!
        SendMessage(hwnd,CB_SHOWDROPDOWN,FALSE,0);\
        return TRUE; //Ok!
      break;
      case VK_BACK: //SendMessage(GetParent(hwnd),CB_SHOWDROPDOWN,FALSE,0);
      break;
      case VK_DELETE: 
      break;

      default:break;
      }//switch(wParam)            
  
  case WM_COMMAND:  
  break;
  default:break;
  }//switch(uMsg);
        
return CallWindowProc(OldComboProc,hwnd,uMsg, wParam, lParam); // not reached!
} 

//Intercept ComboBox's EditBox's Window Procedure.
//˵��: ��Ԥ����del����backspace��. 
//   [2006��3��19��Nothing Done]  
LRESULT APIENTRY InterceptCEdit(HWND hwnd,UINT uMsg,WPARAM wParam,LPARAM lParam)  
{
switch(uMsg)
  {
  case WM_LBUTTONDOWN: //Ok!//But No Use!
  break;
  case WM_LBUTTONDBLCLK:
    {//��չEdit�ؼ���˫���������; //[2007-3-10 ���� 05:49:09] 
	}
  break;
  case WM_RBUTTONDOWN:
    //

    //return 0;
  break;

  case WM_KEYDOWN:
    switch(wParam)
      {
      case VK_RETURN: //Dialogû��VK_RETURN��Ϣ!//Combo�е�VK_RETURN��Dlg�е�IDOK!
      case VK_ESCAPE: //Dialogû��VK_RETURN��Ϣ!//Combo�е�VK_RETURN��Dlg�е�IDOK!
        {
        HWND hp=GetParent(hwnd); hp=GetParent(hp);
        SendMessage(hp,WM_KEYDOWN,wParam,lParam); //return true;
        //DWORD dwDID=SendMessage(hwnd,DM_GETDEFID,0,0);    
        //SendMessage(hwnd,DM_SETDEFID,IDC_BUTTON1,0);//SendDlgItemMessage(hThisWnd,IDOK,BM_CLICK,0,0); 
        }
      break;
      case VK_BACK: 
      break;
      case VK_DELETE: 
        {
        break;
        HWND hcombo=GetParent(hwnd); int iSel=SendMessage(hcombo,CB_GETCURSEL,0,0);        
        SendMessage(hcombo,CB_DELETESTRING,iSel,0);        
        }
      break;

      default:break;//switch(wParam)      
      }    
  break;

  default:break;//switch(uMsg)     
  }

return CallWindowProcW(OldCEditProc,hwnd,uMsg, wParam, lParam);
}

//Intercept EditBox's Window Procedure.
//˵��: ��Ԥ����del����backspace��. 
//   [2006��3��19��Nothing Done]  

WORD wEdit[MAX_PATH]={0};  

LRESULT APIENTRY InterceptEdit(HWND hwnd,UINT uMsg,WPARAM wParam,LPARAM lParam)  
{
return CallWindowProcW(OldEditProc,hwnd,uMsg, wParam, lParam);

switch(uMsg)
  {
  case WM_LBUTTONDOWN:
     //Ok!//But No Use!
  break;
  case WM_LBUTTONDBLCLK:
    {//��չEdit�ؼ���˫���������; //[2007-3-10 ���� 05:49:09] ;//Ok!

	}
  break;
  case WM_RBUTTONDOWN:
    //TrackMenu(hMenu,hwnd);  //Ok!//But No Use!
    //return 0;
  break;

  case WM_KEYDOWN:
    switch(wParam)
      {
      case VK_RETURN: //û��VK_RETURN��Ϣ!//Combo�е�VK_RETURN��Dlg�е�IDOK!
        {
        //DWORD dwDID=SendMessage(hwnd,DM_GETDEFID,0,0);      
        //SendMessage(hwnd,DM_SETDEFID,IDC_BUTTON1,0);
        //SendDlgItemMessage(hThisWnd,IDOK,BM_CLICK,0,0); 
        }
      break;
      case VK_BACK: 
        {
        }                
      break;
      case VK_DELETE: 
        {
        break;
        HWND hcombo=GetParent(hwnd);
        int iSel=SendMessage(hcombo,CB_GETCURSEL,0,0);
        SendMessage(hcombo,CB_DELETESTRING,iSel,0);        
        }
      break;

      default:break;//switch(wParam)      
      }    
  break;

  default:break;//switch(uMsg)     
  }

return CallWindowProcW(OldEditProc,hwnd,uMsg, wParam, lParam);

/*
switch (uMsg)
  { 
  //case WM_PAINT: break;
  
  case WM_COMMAND:
    wmId=LOWORD(wParam);wmEvent=HIWORD(wParam);
    switch(wmId)
      {
      case ITEM_COMBO:
        switch(wmEvent)
          {
          case CBN_EDITUPDATE:
            {
            //SendMessageW(hCombo,WM_GETTEXT,MAX_PATH,(LPARAM)wMatch);
            //purify(wMatch,'\n');purify(wMatch,'\r');purify(wMatch,' ');
            //if(wMatch[0]!=0)
              //FiltrateCandidates(wMatch,hEdit,IDITEM_LIST,ITEM_COMBO);   
              //SelectCandidates(wMatch,hEdit,IDITEM_LIST,ITEM_COMBO);                                  
            }
          break;
          default:break;
          }
      break;//ITEM_COMBO
      
      default:break;
      }
  break;//WM_COMMAND
  

//���ôʵ����з�Ӧ��
case WM_MOUSEWHEEL://WINUSER.H(1501):#define WM_MOUSEWHEEL 0x020A
  {
  wmId= LOWORD(wParam); 
  wmEvent = HIWORD(wParam); 
  //int fwKeys = GET_KEYSTATE_WPARAM(wParam); //short zDelta = GET_WHEEL_DELTA_WPARAM(wParam);

  if(wmEvent>0) SendMessage(hEdit,EM_SCROLL,SB_LINEUP,0);
  //else SendMessage(hEdit,EM_SCROLL,SB_LINEDOWN,0);

  }
break;    





 case WM_KEYDOWN:
    {


    switch(wParam)
      {
     
      //case VK_SPACE: break;

      
      
      case VK_RETURN:
        { //Crtl+VK_RETURN ��hEdit�ļ��ټ���Crtl+VK_RETURN Ҳ��hEdit�ļ��ټ���
        SHORT wState=GetKeyState(VK_LCONTROL);//VK_LMENU//typedef short//=WCHAR=WORD
        if(wState&0x10000000)// "Down");
        //�����case WM_CHAR��̽�ⰴ��״̬��Ӧ�����ã�
        //SHORT GetAsyncKeyState( int vKey);


          {//MessageBeep(MB_ICONEXCLAMATION);
          SendMessageW(hEdit,WM_COPY,0,0);//  Wprint(wInfo,"abcd");
          //GetClipTextW(hEdit,wInfo);
          SendMessageW(hList,LB_ADDSTRING,0,(LPARAM)wInfo);
          //RunNotePad(DICT_FILE); // ShowWindow(hList,SW_SHOW);
          }
        wState=GetKeyState(VK_RCONTROL);//typedef short//=WCHAR=WORD
        if(wState&0x10000000) 
          {//MessageBeep(MB_ICONEXCLAMATION);
          SendMessageW(hEdit,WM_COPY,0,0);//  Wprint(wInfo,"abcd");
          //GetClipTextW(hEdit,wInfo);          
          int ip=SendMessageW(hList,LB_FINDSTRINGEXACT,-1,(LPARAM)wInfo);
          if(ip!=LB_ERR)          
            SendMessageW(hList,LB_DELETESTRING,ip,0);
          }                
        }   
      break;//VK_RETURN


      }
    }
  break;// WM_KEYDOWN
 
  case WM_CHAR :  
      {
    switch(wParam)
      {
      case VK_SPACE:
      break;
      case VK_RETURN:
      break;//VK_RETURN
      case VK_BACK:
      break;

      
      default:
        {
        HKL hKL=GetKeyboardLayout(0);
        if(LOWORD(hKL)==0x0401)  
          {
          MoveTips(hCombo,hEdit);
          if(GetFocus()!=hCombo)
            {
            SetFocus(hCombo);
            ShowWindow(hCombo,SW_SHOW);
            }
          
          PostMessageW(hCombo,WM_CHAR,wParam,lParam);//WM_KEYDOWN                 
          
          return 0;//Stop key input!
          }
        else  
          {
          if(i!=0)ShowWindow(hCombo,SW_HIDE);
          i=0;   
          }                         
        }
      break;            
      }//wParam
    }
  break;//WM_CHAR    


  default:break; 
  }//uMsg
return CallWindowProc(OldProc,hwnd,uMsg, wParam, lParam); // not reached!
*/
} //InterceptEdit;


#define WM_MOUSEWHEEL 0x020A

HWND hEdit,hList;//,hCombo

int i;
WORD wSelect[MAX_PATH]; WORD wMatch[MAX_PATH];//maximum possible length of a word.

void MoveTips(HWND hTip,HWND hPrev,int nCmdShow)//=hEdit=SW_SHOW
{//GetFocus();//HWND SetFocus(HWND hWnd);
POINT p;
GetCaretPos(&p); //ToClient
//int iR=MapWindowPoints(hTip,hPrev,&p,1);//hWndFrom, hWndTo,lpPoints,cPoints// number of points in array     
MoveWindow(hTip,p.x,p.y,100,100,TRUE);
}



LRESULT APIENTRY InterceptList(HWND hwnd,UINT uMsg,WPARAM wParam,LPARAM lParam)  
{
//int wmId, wmEvent;   
switch(uMsg)
  {
  case WM_RBUTTONDOWN:

  break;
  case WM_KEYDOWN:
    switch(wParam)
      {
      case VK_RETURN:  //Combo�е�VK_RETURN��Dlg�е�IDOK!
        //SendMessage(hwnd,CB_SHOWDROPDOWN,FALSE,0); 
        //return TRUE; //Ok!
      break;
      case VK_BACK: 
        //SendMessage(GetParent(hwnd),CB_SHOWDROPDOWN,FALSE,0);
      break;
      case VK_DELETE: 
      break;

      default:break;//switch(wParam)      
      }
  break;      
  default:break;
  }
return CallWindowProc(OldListProc,hwnd,uMsg, wParam, lParam); // not reached!
} 

