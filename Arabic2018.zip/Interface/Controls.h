#ifndef _CONTROLS_H_
#define _CONTROLS_H_

#include <commctrl.h> //LIB: comctl32.lib
#pragma comment(lib, "comctl32.lib")

//�ṹ����CONTROLS.CPP��ʵ��
#ifdef  _CONTROLS_CPP_    //#endif  // _CONTROLS_CPP_ //
#define CONTROLS_EXTERN   
#else 
#define CONTROLS_EXTERN extern 
#endif  // _CONTROLS_CPP_ //


HWND AddControl(HWND hWnd,LPWSTR szClass,UINT id=1, RECT* rp=0,DWORD dwStyle=0);








//absent resource:
#ifndef IDI_ICON
#define IDI_ICON 0
#endif
#ifndef IDI_ICON1
#define IDI_ICON1 0
#endif

#ifndef IDI_ICON2
#define IDI_ICON2 IDI_ICON1
#endif

enum CONTROLTYPE{
CONTROL_Static=1,
CONTROL_Edit,      //=2;
CONTROL_ListBox,   //=3;
CONTROL_SysList,   //=4;
CONTROL_ComboBox,  //=5;
CONTROL_Button,    //=...;
CONTROL_RichEdit,   
CONTROL_ListView,
CONTROL_TreeView,
CONTROL_Tab,       // ... 
};


//For window procedure interceptions;
CONTROLS_EXTERN WNDPROC OldDlgProc;
CONTROLS_EXTERN WNDPROC OldEditProc; 
CONTROLS_EXTERN WNDPROC OldComboProc; 
CONTROLS_EXTERN WNDPROC OldCEditProc; 
CONTROLS_EXTERN WNDPROC OldListProc; 
////////////////////  [2006��3��18��WndProc Interceptions] ////////////////////
LRESULT APIENTRY InterceptDlg(HWND hwnd,UINT uMsg,WPARAM wParam,LPARAM lParam); 
LRESULT APIENTRY InterceptEdit(HWND hwnd,UINT uMsg,WPARAM wParam,LPARAM lParam);  

LRESULT APIENTRY InterceptCombo(HWND hwnd,UINT uMsg,WPARAM wParam,LPARAM lParam);  
LRESULT APIENTRY InterceptCEdit(HWND hwnd,UINT uMsg,WPARAM wParam,LPARAM lParam);  
LRESULT APIENTRY InterceptList(HWND hwnd,UINT uMsg,WPARAM wParam,LPARAM lParam);  



CONTROLS_EXTERN bool bToolTipVisible; 











//���ֽ�4b,���0xF==16-1=2^4-1=15,
//�ֽ�8b,1B,���0xFF=16^2-1=255,
//�� 16b,2B,���0xFFFF=16^4-1=65535,
//˫��32b,4B,���0xFFFF FFFF=16^8-1=4294967295,
//MaxByte=0xFF

//LOBYTE(): ClassIdentifier; HIBYTE(): MemberIdentifier.
#define ITEM_EDIT 0x10
    #define ITEM_EDIT1 0x1001
    #define ITEM_EDIT2 0x1002
    #define ITEM_EDIT3 0x1003

#define ITEM_LIST 0x20
    #define ITEM_LIST1 0x2001
    #define ITEM_LIST2 0x2002
    #define ITEM_LIST3 0x2003
    #define ITEM_LIST4 0x2004
    #define ITEM_LIST5 0x2005
    #define ITEM_LIST6 0x2006
    #define ITEM_LIST7 0x2007
    #define ITEM_LIST8 0x2008
    #define ITEM_LIST9 0x2009
    #define ITEM_LIST10 0x2010 //HIBYTE()=0x20,LOBYTE()=0x10.

#define ITEM_LISTVIEW 0x30
    #define ITEM_LISTVIEW1 0x30001
    #define ITEM_LISTVIEW2 0x30002
    #define ITEM_LISTVIEW3 0x30003
    #define ITEM_LISTVIEW4 0x30004
    #define ITEM_LISTVIEW5 00x30005
    #define ITEM_LISTVIEW6 0x30006
    #define ITEM_LISTVIEW7 0x30007
    #define ITEM_LISTVIEW8 0x30008
    #define ITEM_LISTVIEW9 0x30009
    #define ITEM_LISTVIEW10 0x3010


#define ITEM_COMBO 0x40
    #define ITEM_COMBO1 0x4001
    #define ITEM_COMBO2 0x4002
    #define ITEM_COMBO3 0x4003
    #define ITEM_COMBO4 0x4004
    #define ITEM_COMBO5 0x4005

#define ITEM_TAB 0x50
    #define ITEM_TAB1 0x5001
    #define ITEM_TAB2 0x5002
    #define ITEM_TAB3 0x5003

#define ITEM_TREE 0x60
    #define ITEM_TREE1 0x6001
    #define ITEM_TREE2 0x6002
    #define ITEM_TREE3 0x6003

#define ITEM_BUTTON 0x70
    #define ITEM_BUTTON1 0x7001
    #define ITEM_BUTTON2 0x7002
    #define ITEM_BUTTON3 0x7003
    #define ITEM_BUTTON4 0x7004
    #define ITEM_BUTTON5 0x7005

#define ITEM_TREEVIEW 0x80
    #define ITEM_TREEVIEW1 0x8001
    #define ITEM_TREEVIEW2 0x8002
    #define ITEM_TREEVIEW3 0x8003

#define ITEM_SYSLIST 0x30  //Identical to ITEM_LISTVIEW
    #define DITEM_SYSLIST1 0x3001
    #define DITEM_SYSLIST2 0x3002
    #define DITEM_SYSLIST3 0x3003

#define ITEM_STATIC 0x90  //Identical to ITEM_LISTVIEW
    #define ITEM_STATIC1 0x9001
    #define ITEM_STATIC2 0x9002
    #define ITEM_STATIC3 0x9003

#define ITEM_TOOLTIP 0x0A //ToolTip  Control;

#define ITEM_CLIENT 0x0B




#define MARGIN 5

#include <COMMCTRL.H>

//����ѡ��, see //FINDREPLACE 
typedef struct TREEDIR
{
HWND hTree; //ƥ���/Сд;
HTREEITEM hParent;      //�ʸ�/�ָ�����;
}*PTREEDIR;




HWND AddStatic(HWND hParent,UINT uID,RECT* reo=0, bool bIcon=false);//


HWND AddButton(HWND hParent,UINT uID,int bImage=0,RECT*reo=NULL);




HWND AddEdit(HWND hParent,UINT uID,RECT* reo=0);
//HWND AddRichEdit(HWND hParent,UINT uID,RECT* reo);
HWND AddList(HWND hParent,UINT uID,RECT*reo);
HWND AddCombo(HWND hParent,UINT uID,RECT*reo=NULL);





int LoadEdit(LPCWSTR szFileName,HWND hEdit);
int LoadList(LPCWSTR szFileName,HWND hList,int iCombo=0);
int LoadCombo(LPCWSTR szFileName,HWND hList,HWND hHiden);



//int SaveInput(HWND hCombo,LPCWSTR szFile);



HWND AddTab(HINSTANCE hInst,HWND hWnd,UINT iItem,RECT* rp=NULL);//=ITEM_LIST //
HWND AddEdit(HINSTANCE hInst,HWND hWnd,WORD* wClass);
//HWND AddCtrl(HINSTANCE hInst,HWND hWnd,LPCTSTR szClass);










HWND CreateEdit(HINSTANCE hInst,HWND hWnd,UINT uID,RECT* rp=NULL);
HWND CreateList(HINSTANCE hInst,HWND hWnd,UINT uID,RECT* rp=NULL);  //=NULL  




HWND InitTab(HWND);

//HWND AddControl(HINSTANCE hInst,HWND hWnd,WORD* wClass=NULL);
//HWND AddCtrl(HINSTANCE hInst,HWND hWnd,LPCTSTR szClass=NULL);

////////////////////  [2005��9��6�� 19ʱ5��: Backup: Obsolete->AddControl[]] ////////////////////


BOOL AddInput(HWND hdlg,int iCombo);

//saveinputs[]=savelist[]!
int SaveList(LPCWSTR szName,HWND hItem,int iType);//,WORD*wDelimit=NULLBOOL bAppend=true,=ITEM_LIST //For ComboBox And ListBox!
int  AddText(HWND hCombo);

//WORD*wDelimit=NULL,wDelimit="\r\n";
int saveinputs(HWND hdlg,int iItem=-1,LPCTSTR szName=NULL,BOOL bAppend=FALSE,int iType=ITEM_COMBO);  //For ComboBox Only!
int saveinputs(HWND hdlg,int iItem=-1,LPCWSTR szName=NULL,BOOL bAppend=FALSE,int iType=ITEM_COMBO);  //For ComboBox Only!

int LoadParagraph(LPCWSTR szFileName,HWND hdlg,int iItemList,
      WORD wItem=0x2219,WORD wNote=0x2192,int iType=ITEM_LIST);//,BOOL bItemOnly=IDC_LIST1//=WITEM,=WNOTE,=ITEM_LIST,=FALSE
int LoadListEx(LPCWSTR szFileName,HWND hdlg,int iItemList,
      int iNoteList=-1,WORD wItem=0x2219,WORD wNote=0x2192,int iType=ITEM_LIST,BOOL bNoteOnly=FALSE);//=IDC_LIST1//=WITEM,=WNOTE,=ITEM
int LoadHugeList(LPCWSTR szFileName,HWND hdlg,int iItemList,
      int iNoteList=-1,WORD wItem=0x2219,WORD wNote=0x2192,int iType=ITEM_LIST,BOOL bNoteOnly=FALSE);//=IDC_LIST1//=WITEM,=WNOTE,=ITEM_LIST,=FALSE

int LoadParagraphs(LPCWSTR szFileName,HWND hdlg,int iListID,int iType=ITEM_LIST);

//int savelist(LPCWSTR szName,HWND hdlg,int iItem,WORD*wDelimit=NULL,int iItemType=ITEM_COMBO,BOOL bAppend=FALSE);//=ICDITEM_COMBO  //For ComboBox And ListBox!
int openlist(LPCWSTR szName,HWND hdlg,int iItem,WORD*wDelimit=NULL,int iItemType=ITEM_COMBO,BOOL bAppend=FALSE);//=ICDITEM_COMBO  //For ComboBox And ListBox!







void MoveTips(HWND hTip,HWND hParent,BOOL bShow=TRUE);


//OldProc=(WNDPROC)SetWindowLongW(hEdit,GWL_WNDPROC,(LONG)InterceptEdit);if(!OldProc) ...         
//HWND hCEdit= FindWindowExW(hCombo,NULL,L"Edit",NULL); 
//case IDO_WNDPROC: OldCombo=(WNDPROC)SetWindowLongW(hCEdit,GWL_WNDPROC,(LONG)InterceptCombo); if(!OldCombo) ...
//case IDO_RESTOREWNDPROC: hNew=(WNDPROC)SetWindowLong(hCEdit,GWL_WNDPROC,(LONG)OldCombo);

char* eVacuate(char*szSrc,const char cBan);
WORD* eVacuate(WORD*szSrc,const WORD cBan);


#endif // _CONTROLS_H_ //