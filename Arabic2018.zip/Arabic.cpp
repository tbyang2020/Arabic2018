﻿


#define  _ARABIC_CPP_  
#include "Arabic.h"


#include "Interface/Interface.h"
#include "Interface/qTrace.h"



bool isArabic(WCHAR c){   return ( 0x05FF<c && c<0x077F );   }    // 还有一些特殊字符没考虑 ... 









int ar_Alphabet(HWND hWnd){

HWND hEdit = GetDlgItem(hWnd,IDC_EDIT1);
if (!hEdit) return 0;  

 
// t_npc(hEdit); return 0; 


wchar_t ws[128];  

int IC=MAXWORD, ic=0;    

IC=ARE-ARH+1;   

for (int i=0; i<MAXWORD; i++){   // [0, MAXWORD]

if ( ! (ARH<=i && i<=ARE) ) continue;  
//if ( ! (ARSH<=i && i<=ARSE) ) continue; 
//if ( ! (ARFAH<=i && i<=ARFAE) ) continue; 
//if ( ! (ARFBH<=i && i<=ARFBE) ) continue; 


if (iswalpha(i)){
//if (iswdigit(i)){ 
//if (iswspace(i)){
//if (iswpunct(i)){

//if ( !iswpunct(i) && !iswspace(i) && !iswdigit(i) && !iswalpha(i) ){

//if (be_ar_note(i)){


ic++; 
swprintf(ws, L"%d \t%c \t 0x%X\r\n",ic, i,i);
SendMessageW(hEdit,EM_REPLACESEL,0,(long)ws);

}  // if

}  // for 

swprintf(ws, L"\r\n总数: %d / %d \r\n",ic, IC);
SendMessageW(hEdit,EM_REPLACESEL,0,(long)ws);

return ic;
}




// Arabic - English 1-1 对应部分.  实用读本配音方案 

// 注意确保 _ar_sn, _sn_ar 互逆

// 返回 < MAX_SP (<32） 的数值, 表示用以表示该字符的 ZSP 的个数. 

inline
wchar_t  _ar_sn(wchar_t w){
wchar_t c=w;  
switch (w){

case Alef:       c = Alef_SP;    break;        // 0x627 ا   ZSP有时也表示 Sukun、Lam, 反映射需要分情况定义
case Alef_Up:    c = 'a';    break;        
case Hemz:       c = Hemz_SP;       break;         // 0x621 ء 变换为 L'ʔ' 0x294 厄  è  // 怎样区分 Hemz、Alef_up ？ 
case Hemz_Alef:  c = Hemz_Alef_SP;  break;        



case Beh: c='b';  break;       // 0x628  ب

case Teh_Marbuta:  c='t';  break;    // 0x629   ة 圆塔,  而不是 TEH  
case Teh: c = Teh_SP;      break;    // 0x62A   ت  TEH  -- 反映射遇到 t, 应当检查是否 t+ZSP  

case Theh: c=L'ɵ';  break;           // 0x62B  ث 变换为 0x275  ɵ 


case Jeem: c=L'ʤ'; break;          // 0x62C  ج  变换为 -- 0x2A4  ʤ 


case Hah: c=L'ħ'; break;           // 0x62D  ح  变换为 -- 0x127  ħ  赫


case Khah: c='x'; break;          // 0x62E  خ  变换为 -- x 喝  ...... 怎么用英文的x代表'喝'呢?! 真是奇怪!  

case Dal:  c='d'; break;           // 0x62F  د  变换为 -- d 

case Thal: c=L'ð'; break;          // 0x630  ذ  变换为 -- 0xF0  ð   

case Reh: c='r'; break;      // 0x631  ر  变换为 -- r  

case Zain: c='z'; break;      // 0x632  ز   变换为 -- z  

case Seen: c='s'; break;      // 0x633  س   变换为 -- s  

case Sheen: c=L'ʃ'; break;      // 0x634  ش   变换为 -- 0x283  ʃ   -- 最好使用双字符 sh, 但需注意反映射 s+h 

case Sad: c=L'ş'; break;      // 0x635  ص   变换为 -- 0x15F  ş   s但嘴唇稍圆


case Dad: c=L'đ'; break;      // 0x636  ض   变换为 -- 0x111  đ   d但嘴唇稍圆


case Tah: c=L'ţ'; break;      // 0x637 ط   变换为 -- 0x163  ţ   t但嘴唇稍圆

case Zah: c=L'δ'; break;      // 0x638 ظ   变换为 -- 0x3B4   δ  ð但嘴唇稍圆

case Ain: c=L'ʕ'; break;      // 0x639 ع   变换为 -- 0x295   ʕ  阿

case Ghain: c=L'ġ'; break;    // 0x63A غ   变换为   ġ  0121   伽    

case Feh: c='f'; break;      // 0x641 ف   变换为  f    

case Qaf: c='g'; break;      // 0x642 ق   变换为  g    

case Kaf: c='k'; break;      // 0x643 ك   变换为  k   

case Lam: c='l'; break;      // 0x644 ل   变换为 l  

case Meem: c='m'; break;      // 0x645 م   变换为 m  

case Noon: c='n'; break;      // 0x646 ن   变换为 n  -- 反映射遇到 n, 应当检查是否鼻音  

case Heh: c='h'; break;       // 0x647  ه   变换为 h 

case Waw: c='w'; break;      // 0x648  و  变换为 w 

case Yeh_:
case Yeh: c='j'; break;      // 0x649   ى  ي 变换为 j


// 一下是音符, 即元音 

//case 0x64B: c=1; break;     // 0x64B  Fathatan     1=en    需要2个字符! 
//case 1: c=0x64B; break;

//case 0x64C: c=2; break;     // 0x64C 	Dammatan ٌ 2=un    需要2个字符! 
//case 2: c=0x64C; break;  

//case 0x64D: c=3; break;     // 0x64D  Kasratan    3=in    需要2个字符! 
//case 3:  c=0x64D; break;  

case  Fatha: c = 'e'; break;   // Fatha  0x64E
 
case  Damma: c = 'u'; break;   // Damma  0x64F

case  Kasra: c = 'i'; break;    // Kasra  0x650

case Sukun:  c=Sukun_SP; break; 
case Shadda: c=Shadda_SP; break;       // Shadda 0x0651   // Shadda <--> 0x3C9 ω 也可以不变
case Maddah: c=Maddah_SP; break;       //  (上)Maddah  0x0653

// 叠音, 表示两个相同的辅音字母重叠,前静符后动符, 读时带静符者似有似无一带而过并把叠音前的字母读的稍微重一些。

// 静音、叠音、长音 最好单独处理 

}  // switch

return c; 
}


inline
wchar_t  _sn_ar(wchar_t w){
wchar_t c=w; 
switch (w){

case ZSP:  c=Sukun;  break;  // ZSP 默认为Sukun. 但是, ZSP 根据前后字符有不同的映射定义, 并且连续若干个 ZSP 通过段定义某个字符,  因此, 反映射必须提前处理.  
case Alef_SP: c=Alef;       break; 
case Alef_Hemz_SP: c=Alef_Hemz;  break; 
case Hemz_Alef_SP:  c=Hemz_Alef;  break; 
case L'ʔ':    c=Hemz;   break;     // HEMZ=0x621   HEMZ_ALEF = 0x0623  HEMZ_WAW = 0x0624 

case 'a': c= Alef; break;  // 单独处理 

case 'b': c= Beh; break;

case 't': c=Teh_Marbuta;   break;   // 0x62A  ت  TEH,   圆塔 0x629   ة,  t+ZSP×10 = 塔

         
case L'ɵ':  c=Theh; break;  // 0x62B  ث 变换为 0x275  ɵ 
         
case L'ʤ': c=Jeem; break;  // 0x62C  ج  变换为 -- 0x2A4  ʤ 
          
case L'ħ': c=Hah; break;  // 0x62D  ح  变换为 -- 0x127  ħ  赫
          
case 'x': c=Khah; break;  // 0x62E  خ  变换为 -- x 喝  ...... 怎么用英文的x代表'喝'呢?! 真是奇怪!  

case 'd': c=Dal; break;  // 0x62F  د  变换为 -- d 
          
case L'ð': c=Thal; break;  // 0x630  ذ  变换为 -- 0xF0  ð   
    
case 'r': c=Reh; break;  // 0x631  ر  变换为 -- r  

case 'z': c=Zain; break;  // 0x632  ز   变换为 -- z  
     
case 's': c=Seen; break;  // 0x633  س   变换为 -- s  
       
case L'ʃ': c=Sheen; break;  // 0x634  ش   变换为 -- 0x283  ʃ 
     
case L'ş': c=Sad; break;  // 0x635  ص   变换为 -- 0x15F  ş   s但嘴唇稍圆

case L'đ': c=Dad; break; // 0x636  ض   变换为 -- 0x111  đ   d但嘴唇稍圆

case L'ţ': c=Tah; break; // 0x637 ط   变换为 -- 0x163  ţ   t但嘴唇稍圆
    
case L'δ': c=Zah; break;  // 0x638 ظ   变换为 -- 0x3B4   δ  ð但嘴唇稍圆
    
case L'ʕ': c=Ain; break;  // 0x639 ع   变换为 -- 0x295   ʕ  阿
    
case L'ġ': c=0x63A; break; // 0x63A غ   变换为   ġ  0121   伽  

      
case 'f': c=Feh; break; // 0x641 ف   变换为  f   

case 'g': c=Qaf; break;  // 0x642 ق   变换为  g    
     
case 'k': c=Kaf; break;  // 0x643 ك   变换为  k   
     
case 'l': c=Lam; break; // 0x644 ل   变换为 l  
    
case 'm': c=Meem; break;  // 0x645 م   变换为 m  
     
case 'n': c=Noon; break;  // 0x646 ن   变换为 n 
   
case 'h': c=Heh; break;  // 0x647  ه   变换为 h 
     
case 'w': c=Waw; break;  // 0x648  و  变换为 w 
     
case 'j': c=Yeh; break;  // 0x649   ى  ي 变换为 j

// 一下是音符, 即元音 


//case 0x64B: c=1; break;     // 0x64B  Fathatan     1=en    需要2个字符! 
//case 1: c=0x64B; break;

//case 0x64C: c=2; break;     // 0x64C 	Dammatan ٌ 2=un    需要2个字符! 
//case 2: c=0x64C; break;  

//case 0x64D: c=3; break;     // 0x64D  Kasratan    3=in    需要2个字符! 
//case 3:  c=0x64D; break;  

case 'e': c=Fatha; break;  // Fatha  0x64E
 
case 'u': c=Damma; break;  // Damma  0x64F
 
case 'i': c=Kasra; break;  // Kasra  0x650


// < 32 的个数标记  
case Sukun_SP: c=Sukun; break;      // Shadda 0x0651   // Shadda <--> 0x3C9 ω 也可以不变. 叠音, 表示两个相同的辅音字母重叠, 前静符后动符, 读时带静符者似有似无一带而过并把叠音前的字母读的稍微重一些。 

case Maddah_SP: c=Maddah; break;    // 长音
case Shadda_SP: c=Shadda; break;  
case Lam_SP: c=Lam; break;  
case Teh_SP: c=Teh; break;  
case Noon_SP: c=Noon_SP; break;      // 与 'n' 不同, 这里不转换, 而是把前面的 *n 反换为鼻音  

}  // switch

return c; 
}




// 单词配音. 初步处理一对多、多对一问题 

// 注意, 缓冲区 szt 长度约 2 倍于 ws 的长度, 


// 转换 ws  为音标 

wchar_t* ar_sn(const wchar_t* ws, wchar_t*szt){

if (!ws) return 0; 
 

wchar_t w, wo=0, wn=0, wnn=0;    // 检查 4 位 wo [w] wn  wnn,  位标号 0  1  2  3 
// wchar_t pc[3] = {0};  //     记录前 3 个字符 

const wchar_t* p=ws;
wchar_t* q=szt;  *q=0; 



while(*p){

w = *p++;  
wn = *p;  wnn = *(p+1); 

#if SPECIAL_MAP|1  // 个别特殊字符--单字符配音方案 

if (iswspace(w)) { *q++=0x20; *q=0;  wo=w; continue; }
if (w == Shadda){ if(wo!=0){ *q++= _ar_sn(wo); *q=0; };  wo=w; continue; }  // Shadda 换双字母 
if (w == Sukun){ *q++=ZSP; *q=0;   wo=w; continue; }   // 其实已经放在 1-1 对应部分  
if (w == Maddah){   wo=w; continue; }  // 忽略 Maddah ?  
if (w == Alef_Up){   *q++='a'; *q++=':';  *q=0; wo=w; continue; }

// 长元音 3 个  -- 要用到 wnn, 因为此时 Alef 不应当带音符  
if (w == Fatha && wn==Alef)if(!be_ar_note(wnn)){  *q++='a'; *q++=':';  *q=0;   p++;   wo=wn; continue; }
if (w == Kasra && wn==Yeh)if(!be_ar_note(wnn)){ *q++='i'; *q++=':';  *q=0;    p++;   wo=wn; continue; }
if (w == Damma && wn==Waw)if(!be_ar_note(wnn)){ *q++='u'; *q++=':';  *q=0;    p++;   wo=wn; continue; }


// 软音 2 个 -- 位3为静符或不是音符! 
if (w == Fatha && wn==Yeh)if(wnn==Sukun || !be_ar_note(wnn)){ *q++='a'; *q++='i';  *q=0;     p++;   wo=wn; continue; }  //   ai   <-->   Fatha + Yeh [+ Sukun]
if (w == Fatha && wn==Waw)if(wnn==Sukun || !be_ar_note(wnn)){ *q++='a'; *q++='u';  *q=0;     p++;   wo=wn; continue; }  //   au   <-->   Fatha + Waw [+ Sukun]

// 鼻音 3 个 
// Fathatan <--> en,  Dammatan <--> un, Kasratan <--> in    此时 wu[1] 不管是什么
if (w == Fathatan){ *q++='e'; *q++='n';  *q=0;     wo=w; continue; }   
if (w == Dammatan){ *q++='u'; *q++='n';  *q=0;     wo=w; continue; }   
if (w == Kasratan){ *q++='i'; *q++='n';  *q=0;     wo=w; continue; }   



if (w == Lam){} 

#endif  // SPECIAL_MAP 


if (be_ar_note(w)) { *q++=_ar_sn(w); *q=0;  wo=w; continue; }  // 竟然遇到单个音符, 只有按单字符配音 

if (be_ar_note(wn)) {  // 字母+音符配音方案 p+=2 

}  









if (w != Alef && w!=Hemz_Alef){ *q++=_ar_sn(w); *q=0;  wo=w; continue; }




if (wn!=Lam) { *q++=_ar_sn(w); *q=0;  wo=w; continue; }  // 没有音符的字母, 按单字符配音 
 
if (wo!=0 && !iswspace(wo) ) { *q++=_ar_sn(w); *q=0;  wo=w; continue; }  // 不在词首, 按单字符配音 









// 其余情况 1-1 对应  

*q++ = _ar_sn(w);  *q=0;  

wo=w;  
}  // while 


return szt; 
}

wchar_t* sn_ar(const wchar_t* ws, wchar_t*szt){

if (!ws) return 0; 

//static wchar_t* szt=(wchar_t*)malloc(256*2);  
//int iL = wcslen(ws); 
//if (iL>256) { qTrace("iL=%d",iL); szt=(wchar_t*)realloc(szt,iL*2); }


wchar_t w, wo=0, wn=0; 

const wchar_t* p=ws;  wchar_t *q=szt; 


while(*p){

w = *p++;  

if (iswspace(w)) { *q++=0x20; *q=0; wo=w; continue; }

wn = *p; 



if (w == wn){  *q++= _sn_ar(w); *q++=Shadda; *q=0;   p++;   wo=wn; continue; }  // Shadda -- 双字母 

//if (w == Sukun){   wo=w; continue; }   // 忽略 Sukun、Maddah
//if (w == Maddah){   wo=w; continue; }
//if (w == Alef_Up){   *q++='a'; *q++=':';  *q=0; wo=w; continue; }

// 长元音 3 个 
if (w == 'a' && wn==':'){ *q++=Fatha; *q++=Alef;  *q=0;   p++;   wo=wn; continue; }
if (w == 'i' && wn==':'){ *q++=Kasra; *q++=Yeh;  *q=0;    p++;   wo=wn; continue; }
if (w == 'u' && wn==':'){ *q++=Damma; *q++=Waw;  *q=0;    p++;   wo=wn; continue; }


// 软音 2 个 
if (w == 'a' && wn=='i'){ *q++=Fatha; *q++=Yeh;  *q++=Sukun;  *q=0;    p++;   wo=wn; continue; }  //   ai   <-->   Fatha + Yeh [+ Sukun]
if (w == 'a' && wn=='u'){ *q++=Fatha; *q++=Waw;  *q++=Sukun;  *q=0;    p++;   wo=wn; continue; }  //   au   <-->   Fatha + Waw [+ Sukun]

// 鼻音 3 个 
// Fathatan <--> en,  Dammatan <--> un, Kasratan <--> in    此时 wu[1] 不管是什么
if (w == 'e' && wn=='n'){ *q++=Fathatan;  *q=0;     p++; wo=wn; continue; }   
if (w == 'u' && wn=='n'){ *q++=Dammatan;  *q=0;     p++; wo=wn; continue; }   
if (w == 'i' && wn=='n'){ *q++=Kasratan;  *q=0;     p++; wo=wn; continue; }   



// 其余情况 1-1 对应  

*q++ = _sn_ar(w);  *q=0;  

wo=w;  
}  // while 


 
return szt; 
}




// 只用于词首 Alef 或冠词配音. 返回本程序处理的字符个数.  注意, ar、en 必须指向缓冲区当前的读写位置. 
  
int _ar_en_I(const wchar_t* ar, wchar_t*en){
if (!ar || !en) return 0; 
const wchar_t* p=ar;
wchar_t*q=en;
*q=0;

if (*p!=Alef && *p!=Hemz_Alef)  return 0;          // 必须以 Alef 开头 
 

int ir=0;

if (!be_ar_note(*(p + 1))) {*q++=ZSP; *q=0; ir++; }  // 注意, 词首的 ZSP 不映射 Sukun, 而映射 Alef 

if (*(p+1)!=Lam && *(p+2)!=Lam )  return ir; 


//if (*(p+1)!=Lam && !be_ar_note(*(p+1)) )  return 0; 
//if (*(p+1)!=Lam && *(p+1)!=Fatha )  return 0; 

//if (*(p+1)==Lam && be_ar_note(*(p+2)) && *(p+2)!=Sukun )  return ir;    // Lam 不带音符, 或者带 Sukun  
//if (*(p+2)==Lam && be_ar_note(*(p+3)) && *(p+3)!=Sukun  )  return ir; 

const wchar_t* r=p;
while (*r!=Lam) r++;
r++;  // r 指向 Lam 后面的字符
if (*r==Sukun) r++;       
else if (be_ar_note(*r)) return ir;  // Lam 后面不是字母, 则只允许 Sukun. 


wchar_t c=*r; 
if (be_ar_note(c)) return ir;   // 书写不规范

q=en; *q=0;  // 重新处理 Alef 
if (*(p+1)==Fatha){ *q++=_ar_sn(Fatha); *q=0; }  // 冠词开头是 Fatha 

if (be_ar_Moon(c)){ *q++=ZSP; *q++=_ar_sn(Lam); *q=0; }         //  Alef+Lam + 太阴字 <--> ZSP+l   
else if(be_ar_Sun(c)) { *q++=ZSP; *q=0; }                       //  Alef+Lam + 太阳字 <--> ZSP

// 因此, 首为 ZSP 或 _ar_en(Fatha)+ZSP, ZSP 不还原为 Sukun, 而还原为 Alef, 或 Alef+Lam, 视其后是否'l'而定. 

return r-p; 
}













// 必须有说明  ...... 


wchar_t* ar_en(const wchar_t* ws, wchar_t*szt){

if (!ws) return 0; 


const wchar_t* p=ws;
wchar_t* q=szt;  *q=0; 


wchar_t w[5]={0};  // 检查 5 位 w[0], w[1], w[2]=当前字符, w[3], w[4] 记录前 2 个字符 w[0], w[1] 而 w[3],w[4] 只用作临变量 

wchar_t c=0; 
int ic=0;   

while(*p){

w[2] = *p++;  
w[3] = *p;  
if (w[3] == 0) w[4]=0; 
else           w[4] = *(p+1); 


if (w[2] == ZSP) { MessageBox(0,"原文不允许ZSP!",0,0); continue; }
if (iswspace(w[2])) { *q++=0x20; *q=0;   w[0]=w[1]; w[1]=w[2];  continue; }



#if SPECIAL_MAP|1  // 个别特殊字符--多对字符配音方案 


// 冠词处理: 处理 Lam 

if (w[2]==Alef || w[2]==Hemz_Alef)
if (iswspace(w[1]))
if( w[3]==Lam || (w[3]==Fatha && w[4]==Lam) ) {	 

const wchar_t* r=p;
if (*r!=Lam) r++;
r++;  // r 指向 Lam 后面的字符
if (*r==Sukun) r++;    // Lam 后面不是字母, 则只允许 Sukun.     

ic=_ar_sn(w[2]);  assert(ic<MAX_SP);  // Alef or Hemz_Alef   
for(int i=0; i<ic; i++) *q++ =ZSP; 

*q=0; 

if (w[3] == Fatha){ *q++ = _ar_sn(w[3]); *q=0; }

if ( be_ar_Moon(*r) ) { *q++=_ar_sn(Lam); } 
else if( be_ar_Sun(*r) ) { for(int i=0; i<Lam_SP; i++) *q++=ZSP; } 
else MessageBoxW(0,r-1,0,0);  // qTrace("%X, %c",*r,*r); // assert(0); 

*q=0;

if (*(r-1)==Sukun){ *q++=ZSP; *q=0; }   

w[0]=*(r-2); w[1]=*(r-1); p=r;  // 刷新字符记录

continue; 
}



// 长元音 3 个  -- 要用到 w[5], 因为此时 Alef 不应当带音符  -- 反转换时应当注意 a、i、u 等等 
if (w[2] == Fatha && w[3]==Alef)if(!be_ar_note(w[4])){  *q++='a'; *q++=':';  *q=0;   p++;  w[0]=w[2]; w[1]=w[3];  continue; }
if (w[2] == Kasra && w[3]==Yeh)if(!be_ar_note(w[4])){ *q++='i'; *q++=':';  *q=0;    p++;   w[0]=w[2]; w[1]=w[3];  continue; }
if (w[2] == Damma && w[3]==Waw)if(!be_ar_note(w[4])){ *q++='u'; *q++=':';  *q=0;    p++;   w[0]=w[2]; w[1]=w[3];  continue; }


// 软音 2 个 -- 位3为静符或不是音符! 
if (w[2] == Fatha && w[3]==Yeh)if(w[4]==Sukun || !be_ar_note(w[4])){ *q++='a'; *q++='i';  *q=0;     p++;  w[0]=w[2]; w[1]=w[3];  continue; }  //   ai   <-->   Fatha + Yeh [+ Sukun]
if (w[2] == Fatha && w[3]==Waw)if(w[4]==Sukun || !be_ar_note(w[4])){ *q++='a'; *q++='u';  *q=0;     p++;  w[0]=w[2]; w[1]=w[3];  continue; }  //   au   <-->   Fatha + Waw [+ Sukun]

// 鼻音 3 个 
// Fathatan <--> en,  Dammatan <--> un, Kasratan <--> in      -- 反转换时应当注意 e、i、u 等等   
if (w[2] == Fathatan){ *q++='e'; *q++='n'; for(int i=0; i<Noon_SP; i++) *q++=ZSP;   *q=0;     w[0]=w[1]; w[1]=w[2];  continue; }   
if (w[2] == Dammatan){ *q++='u'; *q++='n'; for(int i=0; i<Noon_SP; i++) *q++=ZSP;   *q=0;     w[0]=w[1]; w[1]=w[2];  continue; }   
if (w[2] == Kasratan){ *q++='i'; *q++='n'; for(int i=0; i<Noon_SP; i++) *q++=ZSP;   *q=0;     w[0]=w[1]; w[1]=w[2];  continue; }   


if (w[2] == Shadda){ *q++=_ar_sn(w[1]);   *q=0;   w[0]=w[1]; w[1]=w[2]; continue; }   

 
 
#endif  // SPECIAL_MAP 



// 其余情况基本上是 1-1 对应  

c=_ar_sn(w[2]);

if (c>MAX_SP) *q++ = c;  
else  // 多个 ZSP 对应一个字符 
for (int i=0; i<c; i++) *q++=ZSP;

*q=0;  

w[0]=w[1]; w[1]=w[2]; 
 
}  // while 


return szt; 
}



wchar_t* en_ar(const wchar_t* ws, wchar_t*szt){

if (!ws) return 0; 


wchar_t w, wo=0, wn=0; 

const wchar_t* p=ws;  wchar_t *q=szt; 

int ic=0; 

while(*p){

w = *p++;  wn = *p; 

if (w!=ZSP && iswspace(w)) { *q++=0x20; *q=0; wo=w; continue; }


#if SPECIAL_MAP|1

if (w == ZSP) {
ic=1; 
while (*p==ZSP) { p++; ic++; }


if (ic % 2 == 0) *q++ = _sn_ar(ic);
else{  // qTrace("ic=%d",ic); // MessageBoxW(0,p,0,0); 
ic--; 

if (ic>0){
if( !be_ar_note( _sn_ar(wo) ) && be_ar_note( _sn_ar(wn) ) ) *q++=Sukun;   // w 前非音符, 先 Sukun 
*q++ = _sn_ar(ic); 
//if( be_ar_note( _sn_ar(wo) ) && !be_ar_note( _sn_ar(wn) ) ) *q++=Sukun;    // w 后非音符, 后 Sukun 
if( !be_ar_note( _sn_ar(wn) ) ) *q++=Sukun;    // w 后非音符, 后 Sukun  -- 此时前面一定还没有添加 Sukun 

}else  *q++=Sukun;

} 
*q=0; 


wo=*(p-1); 
continue; 
}


// 区分Teh、圆塔 
if (w == 't') {


// 双写 t ...... 
	MessageBoxW(0,p,0,0);



if (wn!=ZSP){ *q++=_sn_ar(w); *q=0;  wo=w; continue;  }



ic=1; 
while (*p==ZSP) { p++; ic++; }

if (ic % 2 == 0) *q++ = _sn_ar(ic);
else{
ic--; 

if (ic>0){
if( !be_ar_note( _sn_ar(wo) ) && be_ar_note( _sn_ar(*p) ) ) *q++=Sukun;   // w 前非音符, 先 Sukun 
*q++ = _sn_ar(ic); 
if( !be_ar_note( _sn_ar(*p) ) ) *q++=Sukun;    // w 后非音符, 后 Sukun  -- 此时前面一定还没有添加 Sukun 
}else{ *q++=_sn_ar(w); *q++=Sukun; }
 
} 
*q=0; 


wo=*(p-1); 
continue; 
}


if (w == wn){  *q++= _sn_ar(w); *q++=Shadda; *q=0;   p++;   wo=wn; continue; }  // Shadda -- 双字母 

// 长元音 3 个 
if (w == 'a'){
if ( wn==':'){ *q++=Fatha; *q++=Alef;  *q=0;   p++;   wo=wn; continue; }  // 如果有Sukun, 则下一轮再转换它
if ( wn=='i'){ *q++=Fatha; *q++=Yeh;  *q=0;    p++;   wo=wn; continue; }  //   ai   <-->   Fatha + Yeh [+ Sukun]
if ( wn=='u'){ *q++=Fatha; *q++=Waw;  *q=0;    p++;   wo=wn; continue; }  //   au   <-->   Fatha + Waw [+ Sukun]

*q++=Alef_Up; *q=0; wo=w; continue;  // 单独 'a' 对应 Alef_Up 

}

if (w == 'i' && wn==':'){ *q++=Kasra; *q++=Yeh;  *q=0;    p++;   wo=wn; continue; }
if (w == 'u' && wn==':'){ *q++=Damma; *q++=Waw;  *q=0;    p++;   wo=wn; continue; }


// 软音 2 个 


 
// 区分 Noon、鼻音  
if (w == 'n') {
if (wn!=ZSP){ *q++=_sn_ar(w); *q=0;  wo=w; continue;  }  

ic=1; 
while (*p==ZSP) { p++; ic++; }

if (ic % 2 == 0) *q++ = _sn_ar(ic);
else{
ic--; 

if (ic>0){
if( !be_ar_note( _sn_ar(wo) ) && be_ar_note( _sn_ar(*p) ) ) *q++=Sukun;   // w 前非音符, 先 Sukun 
*q++ = _sn_ar(ic); 
if( !be_ar_note( _sn_ar(*p) ) ) *q++=Sukun;    // w 后非音符, 后 Sukun  -- 此时前面一定还没有添加 Sukun 
}else{ *q++=_sn_ar(w); *q++=Sukun; }
 
} 
*q=0; 


wo=*(p-1); 
continue; 
}




/*
// 鼻音 3 个 
// Fathatan <--> en,  Dammatan <--> un, Kasratan <--> in    此时 wu[1] 不管是什么
if (w == 'e'){
if( wn=='n'){ *q++=Fathatan;  *q=0;     p++; wo=wn; continue; }  

//if(iswspace(wo)) *q++=Alef; 

if(be_ar_note(wo)){  *q++=Alef; }
// else qTrace("wo=0x%X", wo)

*q++=Fatha; 
*q=0;
wo=w; continue;  
}

if (w == 'u' && wn=='n'){ *q++=Dammatan;  *q=0;     p++; wo=wn; continue; }   
if (w == 'i' && wn=='n'){ *q++=Kasratan;  *q=0;     p++; wo=wn; continue; }   
*/


// 鼻音 3 个 
if (w == 'e' || w=='i' || w=='u'){

if( wn!='n'){ *q++=_sn_ar(w);  *q=0;  wo=w; continue; }  

if (*(p+1)!=ZSP){ *q++=_sn_ar(w);  *q++=_sn_ar(wn); *q=0;  p++; wo=wn; continue; }   // n+ZSP×20 才表示鼻音  

const wchar_t*r=p+1; 
ic=0; 
while (*r==ZSP){ r++; ic++; }  

if (ic==Noon_SP) {   // 不允许前后有静符
if(w=='e') *q++=Fathatan;
else if (w == 'i')  *q++=Kasratan;
else if (w == 'u')  *q++=Dammatan;
*q=0; 

wo=*(r-1); 
p=r; 
continue; 
}


// ic!=ZSP, 则ZSP段与n 无关, 交给下一轮处理. 
*q++=_sn_ar(w); *q++=_sn_ar(wn);   *q=0; 

p++; wo=wn; continue;
}  // if 






#endif   // SPECIAL_MAP



// 其余情况 1-1 对应  


*q++ = _sn_ar(w);  *q=0;  

wo=w;  
}  // while 


 
return szt; 
}






// 尚需解决的问题: 静符丢失、连读、冠词. 确保 1-1对应.  

int t_cx_ar(HWND hWnd){


HWND hEdit = GetDlgItem(hWnd,IDC_EDIT1);

if (!hEdit){

hEdit = AddControl( hWnd, L"Edit",WS_BORDER|WS_VSCROLL|ES_MULTILINE|ES_WANTRETURN,1); 
 
int h=16*2, w=0;  // 16*4  // lfHeight = GetDeviceCaps(hDC, LOGPIXELSY)*n/72 
HFONT hFont =     // (HFONT)GetStockObject(ANSI_VAR_FONT); 
CreateFont(h, w,  0, 0, FW_NORMAL, 0, 0, 0, ARABIC_CHARSET, 0, 0, 0, 0,  "Traditional Arabic");  // "Fixedsys Excelsior 3.01" // "宋体"
SendMessage(hEdit,WM_SETFONT,(long)hFont,0); 
SendMessage(hEdit,WM_SETTEXT,0,0);

}  // if (!hEdit) 


wchar_t szw[512], szt[512]; 

SendMessageW(hEdit,WM_GETTEXT,128,(long)szw);


// enumWords(szw,hEdit);  return 0;  



ar_en(szw, szt); 

SendMessageW(hEdit,EM_REPLACESEL,0,(long)L"\r\n");
SendMessageW(hEdit,EM_REPLACESEL,0,(long)szt);



en_ar(szt,szw); 
SendMessageW(hEdit,EM_REPLACESEL,0,(long)L"\r\n");
SendMessageW(hEdit,EM_REPLACESEL,0,(long)szw);


return 0; 
}






// 划分单词, 逐个处理 -- 处理冠词配音、连读配音  

int enumWords(wchar_t* ws, HWND hEdit){
if (!ws) return 0; 


SendMessageW(hEdit, EM_REPLACESEL,0,(long)L"\r\n"); 


wchar_t c, szt[64],  *p=ws, *q=0, *r=0;
int ic=0; 
while (*p){

while (iswspace(*p)) p++;  
r=q=p; 

while (!iswspace(*r)){ 
if(*r==0) break; 
r++; 
}

if (*r==0) break; 

c=*r;
#if PROCESS_WORD|1 // 处理单词 ...... 
*r=0; ic++; 
swprintf(szt, L"%d\t %s \r\n", ic, q);
SendMessageW(hEdit, EM_REPLACESEL,0,(long)szt); 

#endif  // PROCESS_WORD  // 处理单词  
*r=c; 

p=r;
}  // while(*p) 







return 0; 
}





void t_npc(HWND hEdit){

//wchar_t zt[80+64] = {'a',ZSP, 'b',  SOH, STX, ETX, EOT,ENQ,ACK,BELL,'c','.','.','.',0,};
wchar_t zt[80+64] = {'a',ZSP, 'b', 160,'c','.','.','.',0,};  // 0x3000

#if BLANKS

wchar_t*p = wcschr(zt, '.');  
// 02B0-02FF
for (int i = 0x2b0; i <= 0x2ff; i++){
	*p++=i; 
}
*p++='d';
*p=0;  

#endif   // 0

MessageBoxW(0,zt,0,0); 

SendMessageW(hEdit,EM_REPLACESEL,0,(long)zt); 
}