﻿

#pragma warning(disable:4996) 


#ifndef _ARABIC_H_
#define _ARABIC_H_    //#endif  // _ARABIC_H_ //

// 结构仅在ARABIC.CPP中实现
#ifdef  _ARABIC_CPP_    // #endif  // _ARABIC_CPP_ //
#define ARABIC_EXTERN   
#else 
#define ARABIC_EXTERN extern 
#endif  // _ARABIC_CPP_ //


#include <Windows.h>
#include <stdio.h>


bool isArabic(WCHAR c);   




#define ZSP          0xFEFF                // 零宽度无中断空格

//688-767 (02B0-02FF), 80个	空白修饰字母	Spacing Modifiers  --- 不是空格 

// 需要一些非打印字符 1--31  没有什么用处. 因为都要显示为方块   

// 0	00	空               NULL
#define  SOH  1  // 1	01	头标开始         SOH    start of heading
#define  STX  2  // 2	02	正文开始         STX
#define  ETX  3  // 3	03	正文结束         ETX
#define  EOT  4  // 4	04	传输结束         EOT  
#define  ENQ  5  // 5	05	查询  ENQ  enquiry  
#define  ACK  6  // 6	06	确认  ACK
#define  BELL 7  // 7	07	震铃  ELL

// 8	08	backspace     BS
// 9	09	水平制表符    HT
// 10	0A	换行/新行     LF
// 11	0B	竖直制表符    VT
// 12	0C	换页/新页     FF
// 13	0D	回车          CR
// 14	0E	移出          SO
// 15	0F	移入          SI
// 16	10	数据链路转意  DLE
// 17	11	设备控制 1    DC1
// 18	12	设备控制 2    DC2          
// 19	13	设备控制 3    DC3
// 20	14	设备控制 4    DC4
// 21	15	反确认        NAK
// 22	16	同步空闲      SYN   synchronous idle 
// 23	17	传输块结束    ETB
// 24	18	取消          CAN
// 25	19	媒体结束      EM
// 26	1A	替换          SUB
// 27	1B	转意          ESC   escape
// 28	1C	文件分隔符    FS
// 29	1D	组分隔符      GS
// 30	1E	记录分隔符    RS
// 31	1F	单元分隔符    US


// 最终方案, 不得不通过 ZS 表示 Sukun, ZS+ZS 表示 Alef 等等. 

// 返回 n: 用 n 个 ZSP 表示字符 ar  

// 处理 1 对多的问题 





enum AR_SP{

// 如果要表示 静符的 Alef 怎么办呢? 只有偶数才表示字符  

// 是奇数, 则后跟音符时 Sukun 在前, 前有音符时 Sukun 在后. 前后都是音符时忽略 Sukun.  

 
Sukun_SP     = 1,   
Alef_SP      = 2,         
Alef_Up_SP   = 4,  // a+ZSP <--> Alef_Up 
Hemz_Alef_SP = 6,  //
Alef_Hemz_SP = 8,  //
Hemz_SP      = 10,       //

Shadda_SP    = 12,     //
Maddah_SP    = 14,     //
Lam_SP       = 16,        

// 18个以上的 ZSP具有特殊功能, 表示字符的后缀. 例如  ت  = t,   而  ة= t+ZSP×18

Teh_SP  = 18,        // Teh = t, 圆塔 = t+ZSP,        
Noon_SP = 20,        // n+ZSP×20 表示鼻音 

MAX_SP=31,     
};




// 常用字母  

enum Arabic_Character {

	Hemz = 0x0621,  // HEMZ

	Hemz_Alef =   0x0623,                     // HEMZ_ALEF, Alef上 带 Hemz
 
    Alef_Hemz =   0x625,



	Hemz_Waw =    0x0624,                     // HEMZ_Waw, Waw上 带 Hemz
	
	Alef = 0x0627,               // ALEF 
	Beh  = 0x0628,               // BEH 
	Teh_Marbuta = 0x0629,        // TEH_MARBUTA 园塔. 
	Teh  = 0x062A,               // TEH  
	Theh = 0x62B, 
	Jeem = 0x62C, 
	Hah  = 0x62D,
	Khah = 0x62E,
	Dal  = 0x62F, 
	Thal = 0x630,
	Reh  = 0x631,
	Zain = 0x632,
	Seen = 0x633, 
	Sheen= 0x634, 
	Sad  = 0x635, 
	Dad  = 0x636, 
	Tah  = 0x637, 
	Zah  = 0x638, 
	Ain  = 0x639,
	Ghain= 0x63A,                // GHAIN 


	Feh  = 0x641,                // FEH          
	Qaf  = 0x642,
	Kaf  = 0x643,
	Lam  = 0x644, 
	Meem = 0x645, 
	Noon = 0x646,
	Heh  = 0x647,
	Waw  = 0x648,
	Yeh  = 0x649,                   // Alef_Maksura 

Hemz_Yeh = 0x626,


	Yeh_ = 0x64A,                   // 真正的 Yeh 

// 接下来是音符 ...... 

//	Hemz_Up = 0x654,   // 音标有定义 
//	Hemz_Lo = 0x655, 
};



// 常用音标  

enum Arabic_Note{

Fathatan=0x064B,    
Dammatan=0x064C,         
Kasratan=0x064D,   

Fatha=0x064E,   
Damma=0x064F,       
Kasra=0x0650,   


Shadda=0x0651,       
Sukun=0x0652, 

Maddah=0x0653,   //  (上)Maddah


Hemz_Up=0x0654,   //  上标 Hemz
Hemz_Lo=0x0655,   //  下标 Hemz



Alef_Up=0x0670,   //  上标 Alef



// 长元音 3 个 

//   a:   <-->   Fatha + Alef
//   i:   <-->   Kasra + Yeh [+ Sukun]
//   u:   <-->   Damma + Waw

// 软音 2 个 

//   ai   <-->   Fatha + Yeh [+ Sukun]
//   au   <-->   Fatha + Waw [+ Sukun]


};





// 字符属性判断 ......
 
// Arabic 编码范围  

// Arabic (0600–06FF)
#define  ARH           0x0600                 // ARH  阿拉伯语数字标记  阿拉伯语字母开始点   
#define  ARE           0x06FF                 // ARE  带竖翻V的 Heh  阿拉伯语字母开始点   阿拉伯语字母结束点 
#define  HEH_V         ARE 

// Arabic Supplement (0750–077F)
#define  ARSH          0x0750                  // ARSH  Teh_ddd 带下水平三点的Teh  阿拉伯语增补开始点   
#define  Teh_DDD       ARSH
#define  ARSE          0x077F                  // ARSE  Kaf_ddd 带上两点的Kaf      阿拉伯语增补结束点   
#define  KAF_DD        ARSE 


// Arabic Presentation Forms-A (FB50–FDFF)
#define  ARFAH         0xFB50                  // ARFAH  Alef_Wasla 独立形示   阿拉伯语变形显现形式A开始点   
#define  ALEF_WASLA    ARFAH
//#define  ARFAE         0xFDFD                  // ﷽   特思米 阿拉伯语连字  其后两个字符好像是空格   
#define  ARFAE         0xFDFF                  // ARFAE 好像是空格 阿拉伯语变形显现形式A结束点   


// Arabic Presentation Forms-B (FE70–FEFF)
#define  ARFBH         0xFE70                  // ARFBH  Fathatan 独立形示   阿拉伯语变形显现形式B开始点 
#define  FATHATAN      ARFBH                  
#define  ARFBE         0xFEFF                  // ARFBE  等宽无中断空格  阿拉伯语变形显现形式B结束点   



  


int ar_Alphabet(HWND hWnd);   // iswspace    iswalpha       isalnum  iswalnum ...... 共 14 个属性函数 
 
// 试验结果:  
// iswdigit 较全 310 个, 其中 Arabic 20 个 
// iswspace 25 个,   Arabic 0 个  

// 基本阿语 256 个
// iswspace   0   个   
// iswdigit   20  个   
// iswalpha   152 个   
// iswpunct   12  个   
// 其余       72  个, 包括音符、上下标、字母变形、分节号等等, 其中 45 是音符  





// 月亮字母 14 个

inline bool be_ar_Moon( wchar_t w ){ 
if (w==Alef || w==Hemz_Alef)  return true; 
if (w==Beh)  return true; 
if (w==Jeem)  return true; 
if (w==Hah)  return true; 
if (w==Khah)  return true; 
if (w==Ain)  return true; 
if (w==Ghain)  return true; 
if (w==Feh)  return true; 
if (w==Qaf)  return true; 
if (w==Kaf)  return true; 
if (w==Meem)  return true; 
if (w==Heh)  return true; 
if (w==Waw)  return true; 
if (w==Yeh || w==Yeh_)  return true; 
 
return false; 
}


// 太阳字母 14 个

inline bool be_ar_Sun( wchar_t w ){ 
if (w==Teh || w==Teh_Marbuta)  return true; 
if (w==Theh)  return true; 
if (w==Dal)  return true; 
if (w==Thal)  return true; 
if (w==Reh)  return true; 
if (w==Zain)  return true; 
if (w==Seen)  return true; 
if (w==Sheen)  return true; 
if (w==Sad)  return true; 
if (w==Dad)  return true; 
if (w==Tah)  return true; 
if (w==Zah)  return true; 
if (w==Lam)  return true; 
if (w==Noon) return true; 
 
return false; 
}



// AR_ADH  的子集和, 重新排序. 音符, 特点为非独立, 例如带有虚圆标志   54+14=68个
 
// 与 be_ar_adh 相同 
 
inline bool be_ar_note(wchar_t w){ 

// Arabic (0600–06FF)   6 段 54 个  基本音符、基本音符变形、停顿符... 

if(0x610<=w && w<=0x61A) return true;     // 1. [依附标记] 11 个
if(0x64B<=w && w<=0x65F) return true;     // 2. [依附标记] 21 个
if(0x670==w ) return true;                // 3. [依附标记]  1 个
if(0x6D6<=w && w<=0x6DC) return true;     // 4. [依附标记]  7 个   停顿等标志 
if(0x6DF<=w && w<=0x6E8) return true;     // 5. [依附标记]  10 个  高低字符等 
if(0x6EA<=w && w<=0x6ED) return true;     // 6. [依附标记]  4 个   高低字符等 
 
// Arabic Supplement (0750–077F)  0 段 0 个 

// Arabic Presentation Forms-A (FB50–FDFF)  1 段 6 个   符合音符  Fatha+Shadda 等等

if (0xFC5E <= w && w <= 0xFC63) return true;   // 1.  [依附标记]     
 

// Arabic Presentation Forms-B (FE70–FEFF) 8 段 8 个  基本音符 

if (0xFE70 == w) return true;        // 1. [依附标记] 1 个 
if (0xFE72 == w) return true;        // 2. [依附标记] 1 个 
if (0xFE74 == w) return true;        // 3. [依附标记] 1 个 
if (0xFE76 == w) return true;        // 4. [依附标记] 1 个 
if (0xFE78 == w) return true;        // 5. [依附标记] 1 个 
if (0xFE7A == w) return true;        // 6. [依附标记] 1 个 
if (0xFE7C == w) return true;        // 7. [依附标记] 1 个 
if (0xFE7E == w) return true;        // 8. [依附标记] 1 个 

      
return false;  
}








int t_cx_ar(HWND hWnd); 
int enumWords(wchar_t* ws, HWND hEdit); 


void t_npc(HWND hEdit); 


#endif  // _ARABIC_H_ //






